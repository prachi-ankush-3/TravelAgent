import React from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Fingerprint, ArrowRight, ArrowLeft } from 'lucide-react';
import { signup } from '../services/authService';
import { getDashboardPath } from '../services/uiStorage';

export default function Signup() {
  const navigate = useNavigate();
  const [username, setUsername] = React.useState('');
  const [email, setEmail] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [confirmPassword, setConfirmPassword] = React.useState('');
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState('');

  const handleSignup = async (e) => {
    e.preventDefault();

    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }

    setLoading(true);
    setError('');

    try {
      await signup({ username, email, password });
      navigate(getDashboardPath());
    } catch (err) {
      const message = err?.response?.data?.detail || err?.message || 'Signup failed.';
      setError(message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="layout-container auth-bg-image" style={{ position: 'relative', justifyContent: 'center', alignItems: 'center' }}>
      <div style={{ position: 'absolute', top: '30px', left: '40px', zIndex: 20 }}>
        <button onClick={() => navigate('/')} style={{ background: 'transparent', border: 'none', color: 'white', display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', fontSize: '14px', fontWeight: 600 }}>
          <ArrowLeft size={18} /> Back to Home
        </button>
      </div>
      <div className="orb orb-blue" style={{ top: '5%', right: '15%', width: '400px', height: '400px' }} />
      <div className="orb orb-orange" style={{ bottom: '10%', left: '10%', width: '300px', height: '300px' }} />
      
      <motion.div 
        className="glass-panel"
        style={{ padding: '40px', width: '100%', maxWidth: '420px', zIndex: 10 }}
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div style={{ textAlign: 'center', marginBottom: '32px' }}>
          <motion.div
            className="animate-glow"
            style={{ display: 'inline-flex', padding: '16px', borderRadius: '50%', background: 'var(--glass-bg)', border: '1px solid var(--glass-border)', marginBottom: '16px' }}
          >
            <Fingerprint size={32} color="var(--accent-orange)" />
          </motion.div>
          <h2 className="gradient-text" style={{ fontSize: '28px', fontWeight: 900, marginBottom: '8px' }}>Create Your Travel Identity</h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '14px' }}>
            Progressive AI memory will adapt to your travel style.
          </p>
        </div>

        <form onSubmit={handleSignup} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <div>
            <label style={{ display: 'block', marginBottom: '8px', fontSize: '14px', color: 'var(--text-muted)' }}>Username</label>
            <input type="text" className="ai-input" placeholder="traveler123" required value={username} onChange={(e) => setUsername(e.target.value)} />
          </div>
          <div>
            <label style={{ display: 'block', marginBottom: '8px', fontSize: '14px', color: 'var(--text-muted)' }}>Email Address</label>
            <input type="email" className="ai-input" placeholder="traveler@example.com" required value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div>
            <label style={{ display: 'block', marginBottom: '8px', fontSize: '14px', color: 'var(--text-muted)' }}>Password</label>
            <input type="password" className="ai-input" placeholder="••••••••" required value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          <div>
            <label style={{ display: 'block', marginBottom: '8px', fontSize: '14px', color: 'var(--text-muted)' }}>Confirm Password</label>
            <input type="password" className="ai-input" placeholder="••••••••" required value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} />
          </div>
          {error ? (
            <div style={{ color: '#FCA5A5', fontSize: '14px', lineHeight: 1.4 }}>
              {error}
            </div>
          ) : null}
          
          <button type="submit" className="ai-btn" style={{ marginTop: '8px' }} disabled={loading}>
            {loading ? 'Creating account...' : <>Enter Workspace <ArrowRight size={18} /></>}
          </button>
        </form>

        <div style={{ marginTop: '24px', textAlign: 'center', fontSize: '14px', color: 'var(--text-muted)' }}>
          Already have an identity? <Link to="/login" style={{ color: 'var(--text-main)', textDecoration: 'none', borderBottom: '1px solid var(--accent-orange)' }}>Enter Workspace</Link>
        </div>
      </motion.div>
    </div>
  );
}
