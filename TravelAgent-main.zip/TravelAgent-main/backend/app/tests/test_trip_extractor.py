from __future__ import annotations

from app.agents.booking.trip_extractor import extract_trip_details_from_message, parse_route_from_message


def test_parse_route_from_pune_to_nashik() -> None:
	source, destination = parse_route_from_message("book bus from pune to nashik")
	assert source == "Pune"
	assert destination == "Nashik"


def test_parse_route_without_from_keyword() -> None:
	source, destination = parse_route_from_message("mumbai to pune tomorrow")
	assert source == "Mumbai"
	assert destination == "Pune"


def test_extract_trip_details_includes_travel_date() -> None:
	details = extract_trip_details_from_message("book bus from pune to nashik tomorrow")
	assert details["source"] == "Pune"
	assert details["destination"] == "Nashik"
	assert details.get("travel_date")
