"""Workflow execution engine for orchestrator plans.

This module takes an orchestrator plan and executes agents sequentially.
Agents communicate through shared session state (GlobalTravelState).
"""
from __future__ import annotations

import importlib
import inspect
from typing import Any, Dict, List, Tuple

from app.state.session_manager import session_manager
from app.state.memory_handler import get_snapshot


class WorkflowManager:
    """Executes orchestrator-selected agents one-by-one for a session."""

    _AGENT_CLASS_MAP: Dict[str, Tuple[str, str]] = {
        "ExploreAgent": ("app.agents.explore.explore_agent", "ExploreAgent"),
        "HotelAgent": ("app.agents.hotel.hotel_agent", "HotelAgent"),
        "BudgetAgent": ("app.agents.budget.budget_agent", "BudgetAgent"),
        "BookingAgent": ("app.agents.booking.booking_agent", "BookingAgent"),
        "ItineraryAgent": ("app.agents.itinerary.itinerary_agent", "ItineraryAgent"),
    }

    def _resolve_agent_class(self, agent_name: str):
        """Resolve agent class from configured module path and class name."""
        target = self._AGENT_CLASS_MAP.get(agent_name)
        if not target:
            raise ValueError(f"Unknown agent in plan: {agent_name}")

        module_path, class_name = target
        module = importlib.import_module(module_path)
        try:
            return getattr(module, class_name)
        except AttributeError as exc:
            raise RuntimeError(f"Agent class '{class_name}' not found in {module_path}") from exc

    def _execute_agent(self, agent_name: str, session_id: str) -> Dict[str, Any]:
        """Execute a single agent with the best supported calling convention."""
        AgentClass = self._resolve_agent_class(agent_name)
        agent = AgentClass()

        run_fn = getattr(agent, "run", None)
        if run_fn is None or not callable(run_fn):
            raise RuntimeError(f"{agent_name} has no callable run(...) method")

        state = session_manager.get_or_create(session_id)
        params = list(inspect.signature(run_fn).parameters.values())

        # Support both run(session_id) and run(state).
        if len(params) == 1:
            param_name = params[0].name.lower()
            if "session" in param_name or param_name in {"sid", "session_id"}:
                result = run_fn(session_id)
            else:
                result = run_fn(state)
        else:
            # Fallback to session_id for unknown signatures.
            result = run_fn(session_id)

        return {"agent": agent_name, "status": "completed", "result": result}

    def execute_plan(self, plan: Dict[str, Any] | List[str], session_id: str) -> Dict[str, Any]:
        """Execute agents in order and return execution summary + final state."""
        if isinstance(plan, dict):
            agents_to_run = list(plan.get("agents_to_run", []))
        else:
            agents_to_run = list(plan or [])

        execution_log: List[Dict[str, Any]] = []

        for agent_name in agents_to_run:
            try:
                execution_log.append(self._execute_agent(agent_name, session_id))
            except Exception as exc:
                execution_log.append(
                    {
                        "agent": agent_name,
                        "status": "failed",
                        "error": str(exc),
                    }
                )
                # Continue execution so downstream behavior is visible and debuggable.

        return {
            "agents_requested": agents_to_run,
            "execution_log": execution_log,
            "final_state": get_snapshot(session_id),
        }


def execute_orchestrator_plan(plan: Dict[str, Any] | List[str], session_id: str) -> Dict[str, Any]:
    """Convenience helper used by API/CLI entrypoints."""
    return WorkflowManager().execute_plan(plan=plan, session_id=session_id)
