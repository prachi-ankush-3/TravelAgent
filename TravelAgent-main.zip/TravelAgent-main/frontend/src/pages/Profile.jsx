import React from 'react';
import { motion } from 'framer-motion';
import { User, BrainCircuit, Edit3, MapPin, Calendar, Compass } from 'lucide-react';
import Sidebar from '../components/Sidebar';
import { getCurrentProfile, updateCurrentProfile } from '../services/authService';

const editableFields = [
  { key: 'username', label: 'Username', placeholder: 'traveler123' },
  { key: 'full_name', label: 'Full Name', placeholder: 'Your name' },
  { key: 'age', label: 'Age', placeholder: '25', type: 'number' },
  { key: 'mobile', label: 'Mobile No', placeholder: '9876543210' },
  { key: 'gender', label: 'Gender', placeholder: 'Male / Female / Other' },
];

export default function Profile() {
  const [loading, setLoading] = React.useState(true);
  const [saving, setSaving] = React.useState(false);
  const [error, setError] = React.useState('');
  const [profile, setProfile] = React.useState({});

  React.useEffect(() => {
    let mounted = true;

    async function loadProfile() {
      try {
        const data = await getCurrentProfile();
        if (!mounted) {
          return;
        }
        setProfile(data.profile || {});
      } catch (err) {
        if (mounted) {
          setError(err?.response?.data?.detail || err?.message || 'Failed to load profile.');
        }
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    }

    loadProfile();
    return () => {
      mounted = false;
    };
  }, []);

  const displayName = profile.username || profile.full_name || 'Traveler';
  const email = profile.email || 'No email loaded';

  const handleChange = (key, value) => {
    setProfile((current) => ({ ...current, [key]: value }));
  };

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError('');

    try {
      const payload = editableFields.reduce((acc, field) => {
        if (profile[field.key] !== undefined && profile[field.key] !== null && profile[field.key] !== '') {
          acc[field.key] = field.key === 'age' ? Number(profile[field.key]) : profile[field.key];
        }
        return acc;
      }, {});
      const response = await updateCurrentProfile(payload);
      setProfile((current) => ({ ...current, ...(response.profile || {}) }));
    } catch (err) {
      setError(err?.response?.data?.detail || err?.message || 'Failed to save profile.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="layout-container">
      <Sidebar />
      <div style={{ flex: 1, padding: '40px', overflowY: 'auto' }}>
        <h2 style={{ fontSize: '32px', fontWeight: 600, marginBottom: '40px', color: 'white' }}>Traveler Identity</h2>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 380px', gap: '32px' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
            <motion.form
              onSubmit={handleSave}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="glass-panel"
              style={{ padding: '32px' }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '24px', marginBottom: '24px' }}>
                <div style={{ width: '80px', height: '80px', borderRadius: '50%', background: 'var(--glass-bg)', border: '2px solid var(--glass-border)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <User size={40} color="var(--text-muted)" />
                </div>
                <div style={{ flex: 1 }}>
                  <h3 style={{ fontSize: '24px', fontWeight: 600, color: 'white', marginBottom: '4px' }}>{loading ? 'Loading...' : displayName}</h3>
                  <div style={{ color: 'var(--text-muted)', fontSize: '14px' }}>{loading ? '' : email}</div>
                </div>
              </div>

              {error ? <div style={{ color: '#FCA5A5', marginBottom: '16px', fontSize: '14px' }}>{error}</div> : null}

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                {editableFields.map((field) => (
                  <label key={field.key} style={{ display: 'flex', flexDirection: 'column', gap: '8px', color: 'var(--text-muted)', fontSize: '14px' }}>
                    {field.label}
                    <input
                      type={field.type || 'text'}
                      className="ai-input"
                      placeholder={field.placeholder}
                      value={profile[field.key] ?? ''}
                      onChange={(event) => handleChange(field.key, event.target.value)}
                    />
                  </label>
                ))}
              </div>

              <button type="submit" className="ai-btn secondary" style={{ marginTop: '24px', padding: '10px 16px' }} disabled={saving || loading}>
                <Edit3 size={16} /> {saving ? 'Saving...' : 'Save Profile'}
              </button>
            </motion.form>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '16px' }}>
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="glass-panel" style={{ padding: '24px', textAlign: 'center' }}>
                <MapPin size={24} color="var(--accent-orange)" style={{ margin: '0 auto 12px auto' }} />
                <div style={{ fontSize: '24px', fontWeight: 700, color: 'white' }}>{profile.cities_visited ?? 0}</div>
                <div style={{ fontSize: '12px', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Cities Visited</div>
              </motion.div>
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="glass-panel" style={{ padding: '24px', textAlign: 'center' }}>
                <Compass size={24} color="#3B82F6" style={{ margin: '0 auto 12px auto' }} />
                <div style={{ fontSize: '24px', fontWeight: 700, color: 'white' }}>{profile.km_traveled ?? 0}</div>
                <div style={{ fontSize: '12px', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Km Traveled</div>
              </motion.div>
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }} className="glass-panel" style={{ padding: '24px', textAlign: 'center' }}>
                <Calendar size={24} color="#10B981" style={{ margin: '0 auto 12px auto' }} />
                <div style={{ fontSize: '24px', fontWeight: 700, color: 'white' }}>{profile.upcoming_trips ?? 0}</div>
                <div style={{ fontSize: '12px', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Upcoming Trips</div>
              </motion.div>
            </div>
          </div>

          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 }} className="glass-panel" style={{ padding: '32px', background: 'rgba(255,106,0,0.02)', border: '1px solid rgba(255,106,0,0.2)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '24px' }}>
              <div className="animate-glow" style={{ padding: '8px', background: 'var(--glass-bg)', borderRadius: '50%', border: '1px solid var(--accent-orange)' }}>
                <BrainCircuit size={20} color="var(--accent-orange)" />
              </div>
              <h3 style={{ fontSize: '20px', fontWeight: 600, color: 'white' }}>AI Preferences</h3>
            </div>
            <p style={{ fontSize: '14px', color: 'var(--text-muted)', marginBottom: '32px', lineHeight: 1.5 }}>
              These preferences are read from and saved to Supabase with no hardcoded values.
            </p>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              {[
                ['Preferred Seat', profile.preferred_seat],
                ['Preferred Travel', profile.preferred_travel],
                ['Favorite Operator', profile.favorite_operator],
                ['Travel Style', profile.travel_style],
              ].map(([label, value]) => (
                <div key={label}>
                  <div style={{ fontSize: '12px', color: 'var(--text-muted)', textTransform: 'uppercase', marginBottom: '4px' }}>{label}</div>
                  <div style={{ fontSize: '16px', color: 'white', fontWeight: 500 }}>{value || 'Not set'}</div>
                  <div style={{ height: '1px', background: 'var(--glass-border)', marginTop: '12px' }} />
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
