import React from 'react';

export default function TicketCard({ ticket }) {
  if (!ticket) return null;
  const operator = ticket.get ? ticket.get('operator') || ticket.operator : ticket.operator || 'Trusted Operator';
  const bookingId = ticket.get ? ticket.get('booking_id') || ticket.booking_id : ticket.booking_id;
  const seat = ticket.get ? ticket.get('seat_no') || ticket.seat_no : ticket.seat_no;
  const from = ticket.get ? ticket.get('source') || ticket.source : ticket.source;
  const to = ticket.get ? ticket.get('destination') || ticket.destination : ticket.destination;
  const dep = ticket.get ? ticket.get('departure_time') || ticket.departure_time : ticket.departure_time;
  const arr = ticket.get ? ticket.get('arrival_time') || ticket.arrival_time : ticket.arrival_time;

  return (
    <div style={{ borderRadius: 12, padding: 16, background: 'linear-gradient(180deg, rgba(255,255,255,0.03), rgba(0,0,0,0.2))', color: 'white', maxWidth: 420 }}>
      <div style={{ fontSize: 12, color: 'var(--accent-orange)', fontWeight: 700, marginBottom: 8 }}>TravAgent AI Ticket</div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <div style={{ fontSize: 18, fontWeight: 700 }}>{operator}</div>
          <div style={{ fontSize: 13, color: 'var(--text-muted)' }}>{from} → {to}</div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: 14, fontWeight: 700 }}>Seat {seat}</div>
          <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>Booking ID: {bookingId}</div>
        </div>
      </div>
      <div style={{ marginTop: 12, fontSize: 13, color: 'var(--text-muted)' }}>{dep} → {arr}</div>
      <div style={{ marginTop: 12, fontSize: 13 }}>Optimized for comfort and budget.</div>
    </div>
  );
}
