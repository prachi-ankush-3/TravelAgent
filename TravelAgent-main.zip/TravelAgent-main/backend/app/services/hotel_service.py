"""HotelService — dataset layer for hotel lookups.

Loads backend/datasets/hotels.json and returns hotels for a destination city.
"""
from __future__ import annotations

from pathlib import Path
import json
from typing import Any, Dict, List


_CACHE: Dict[str, List[Dict[str, Any]]] = {}


def _load_dataset() -> Dict[str, List[Dict[str, Any]]]:
    repo_root = Path(__file__).resolve().parents[2]
    dataset_path = repo_root / "datasets" / "hotels.json"
    if not dataset_path.exists():
        return {}
    try:
        with dataset_path.open("r", encoding="utf-8") as file_handle:
            return json.load(file_handle)
    except Exception:
        return {}


def get_hotels(city: str) -> List[Dict[str, Any]]:
    """Return hotels for `city` using case-insensitive lookup."""
    if not _CACHE:
        data = _load_dataset()
        for key, value in data.items():
            _CACHE[key.lower()] = value

    return list(_CACHE.get((city or "").lower(), []))