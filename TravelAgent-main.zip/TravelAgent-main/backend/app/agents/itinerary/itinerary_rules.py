"""Rules and defaults for deterministic itinerary planning."""
from __future__ import annotations

from typing import Any, Dict, List

MAX_ACTIVITIES_PER_DAY = 3
MIN_ACTIVITIES_PER_DAY = 1
NEARBY_CLUSTER_THRESHOLD_KM = 10.0

TIME_RULES: Dict[str, str] = {
    "beach": "Evening",
    "fort": "Morning",
    "historical": "Morning",
    "museum": "Morning",
    "shopping": "Evening",
    "food": "Afternoon",
    "adventure": "Morning",
    "nature": "Morning",
    "nightlife": "Night",
    "scenic": "Evening",
}

CATEGORY_FAMILIES: Dict[str, str] = {
    "beach": "coastal",
    "scenic": "coastal",
    "fort": "heritage",
    "historical": "heritage",
    "museum": "heritage",
    "shopping": "urban",
    "food": "urban",
    "nightlife": "urban",
    "adventure": "outdoor",
    "nature": "outdoor",
}

CATEGORY_RULES: Dict[str, Dict[str, Any]] = {
    "beach": {"slot": "Evening", "estimated_cost": 250},
    "fort": {"slot": "Morning", "estimated_cost": 200},
    "historical": {"slot": "Morning", "estimated_cost": 200},
    "museum": {"slot": "Morning", "estimated_cost": 180},
    "shopping": {"slot": "Afternoon", "estimated_cost": 400},
    "food": {"slot": "Afternoon", "estimated_cost": 500},
    "adventure": {"slot": "Morning", "estimated_cost": 600},
    "nature": {"slot": "Morning", "estimated_cost": 250},
    "nightlife": {"slot": "Evening", "estimated_cost": 700},
    "scenic": {"slot": "Morning", "estimated_cost": 150},
    "default": {"slot": "Afternoon", "estimated_cost": 300},
}

DEFAULT_SLOT_ORDER = ["Morning", "Afternoon", "Evening"]


def normalize_category(activity: Dict[str, Any]) -> str:
    """Return a stable lower-case category for a place/activity."""
    for key in ("category", "type", "kind"):
        value = activity.get(key)
        if value:
            return str(value).strip().lower()

    name = str(activity.get("name", "")).lower()
    for category in CATEGORY_RULES:
        if category != "default" and category in name:
            return category
    return "default"


def preferred_slots(activity: Dict[str, Any]) -> List[str]:
    """Return preferred time slots for a place/activity."""
    category = normalize_category(activity)
    preferred = TIME_RULES.get(category)
    if preferred:
        return [preferred]
    return [CATEGORY_RULES["default"]["slot"]]


def estimated_cost(activity: Dict[str, Any]) -> float:
    """Estimate a rough INR cost for an activity."""
    category = normalize_category(activity)
    rule = CATEGORY_RULES.get(category, CATEGORY_RULES["default"])

    explicit_cost = activity.get("estimated_cost") or activity.get("cost")
    if isinstance(explicit_cost, (int, float)):
        return float(explicit_cost)

    rating = activity.get("rating")
    premium_multiplier = 1.0
    if isinstance(rating, (int, float)):
        if rating >= 4.7:
            premium_multiplier = 1.25
        elif rating >= 4.3:
            premium_multiplier = 1.1

    return float(rule["estimated_cost"]) * premium_multiplier


def best_time_for(activity: Dict[str, Any]) -> str:
    """Return the most suitable time label for an activity."""
    explicit = activity.get("best_time")
    if isinstance(explicit, str) and explicit.strip():
        return explicit.strip().title()

    category = normalize_category(activity)
    return TIME_RULES.get(category, CATEGORY_RULES["default"]["slot"])


def category_family(activity: Dict[str, Any]) -> str:
    """Return a broad family for cluster compatibility."""
    category = normalize_category(activity)
    return CATEGORY_FAMILIES.get(category, category)


def hotel_nearby_tokens(hotel: Dict[str, Any] | None) -> List[str]:
    """Extract nearby-place tokens from a hotel recommendation."""
    if not hotel:
        return []

    tokens: List[str] = []
    for key in ("nearby_places", "location", "preferred_area"):
        value = hotel.get(key)
        if isinstance(value, list):
            tokens.extend(str(item).strip().lower() for item in value if item)
        elif isinstance(value, str) and value:
            tokens.append(value.strip().lower())

    return tokens