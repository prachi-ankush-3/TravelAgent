import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Sparkles, Star, Fuel, Clock3, Armchair } from 'lucide-react';

function formatPrice(price) {
	if (price === null || price === undefined || price === '') return '—';
	const value = Number(price);
	if (Number.isNaN(value)) return String(price);
	return `₹${Math.round(value).toLocaleString('en-IN')}`;
}

export default function RecommendationCard({ bus, onSelect, selected = false, loading = false }) {
	if (!bus) return null;
	const amenities = Array.isArray(bus.amenities) ? bus.amenities.slice(0, 3) : [];

	return (
		<motion.div
			initial={{ opacity: 0, y: 12 }}
			animate={{ opacity: 1, y: 0 }}
			style={{
				position: 'relative',
				padding: '18px',
				borderRadius: '22px',
				border: `1px solid ${selected ? 'rgba(255,106,0,0.6)' : 'var(--glass-border)'}`,
				background: selected
					? 'linear-gradient(180deg, rgba(255,106,0,0.16), rgba(9,10,16,0.92))'
					: 'linear-gradient(180deg, rgba(255,255,255,0.05), rgba(255,255,255,0.02))',
				boxShadow: selected ? '0 0 0 1px rgba(255,106,0,0.12), 0 30px 60px rgba(0,0,0,0.35)' : '0 20px 40px rgba(0,0,0,0.2)',
				display: 'flex',
				flexDirection: 'column',
				gap: '14px',
				minHeight: '290px',
			}}
		>
			<div style={{ display: 'flex', justifyContent: 'space-between', gap: '10px', alignItems: 'flex-start' }}>
				<div>
					<div style={{ display: 'inline-flex', alignItems: 'center', gap: '6px', padding: '6px 10px', borderRadius: '999px', background: 'rgba(255,106,0,0.14)', color: 'var(--accent-orange)', fontSize: '11px', fontWeight: 800, letterSpacing: '0.08em', textTransform: 'uppercase' }}>
						<Sparkles size={12} /> {bus.rank_label || 'AI Pick'}
					</div>
					<div style={{ marginTop: '12px', fontSize: '18px', fontWeight: 800, color: 'white' }}>{bus.operator || 'Trusted Operator'}</div>
					<div style={{ marginTop: '4px', color: 'var(--text-muted)', fontSize: '13px' }}>{bus.headline || 'Matched to your trip'}</div>
				</div>
				<div style={{ textAlign: 'right' }}>
					<div style={{ fontSize: '28px', fontWeight: 900, color: 'white' }}>{formatPrice(bus.price)}</div>
					<div style={{ color: 'var(--text-muted)', fontSize: '12px' }}>Fare estimate</div>
				</div>
			</div>

			<div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, minmax(0, 1fr))', gap: '10px' }}>
				<div style={{ padding: '10px 12px', borderRadius: '14px', background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.04)' }}>
					<div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--text-muted)', fontSize: '11px' }}><Clock3 size={12} /> Departure</div>
					<div style={{ marginTop: '5px', color: 'white', fontWeight: 700, fontSize: '13px' }}>{bus.departure_time || '—'}</div>
				</div>
				<div style={{ padding: '10px 12px', borderRadius: '14px', background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.04)' }}>
					<div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--text-muted)', fontSize: '11px' }}><Star size={12} /> Rating</div>
					<div style={{ marginTop: '5px', color: 'white', fontWeight: 700, fontSize: '13px' }}>{Number(bus.rating || 0).toFixed(1)}</div>
				</div>
				<div style={{ padding: '10px 12px', borderRadius: '14px', background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.04)' }}>
					<div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--text-muted)', fontSize: '11px' }}><Armchair size={12} /> Seats</div>
					<div style={{ marginTop: '5px', color: 'white', fontWeight: 700, fontSize: '13px' }}>{bus.available_seats || '—'} available</div>
				</div>
			</div>

			<div style={{ padding: '14px', borderRadius: '16px', background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.04)', color: 'var(--text-muted)', fontSize: '13px', lineHeight: 1.6 }}>
				<div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px', color: 'var(--accent-orange)', fontWeight: 700 }}>
					<Fuel size={14} /> AI reasoning
				</div>
				{bus.reason || 'This bus is a strong match for the route and your preferences.'}
			</div>

			{amenities.length > 0 && (
				<div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
					{amenities.map((item) => (
						<span key={item} style={{ padding: '7px 10px', borderRadius: '999px', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.05)', color: 'white', fontSize: '11px' }}>{item}</span>
					))}
				</div>
			)}

			<button
				onClick={() => onSelect?.(bus)}
				disabled={loading}
				style={{
					marginTop: 'auto',
					padding: '12px 14px',
					borderRadius: '14px',
					border: 'none',
					cursor: loading ? 'wait' : 'pointer',
					fontWeight: 800,
					fontSize: '14px',
					background: selected ? 'linear-gradient(135deg, #ff9a3c, #ff6a00)' : 'rgba(255,255,255,0.08)',
					color: selected ? 'black' : 'white',
				}}
			>
				{selected ? 'Selected' : 'Choose this bus'} <ArrowRight size={16} style={{ display: 'inline', verticalAlign: 'middle', marginLeft: '4px' }} />
			</button>
		</motion.div>
	);
}
