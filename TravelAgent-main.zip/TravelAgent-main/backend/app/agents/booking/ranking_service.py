"""Bus ranking engine with weighted multi-factor scoring."""
from __future__ import annotations

from typing import Any, Dict, Iterable, List


DEFAULT_WEIGHTS = {
    "price": 0.25,
    "rating": 0.25,
    "comfort": 0.20,
    "amenities": 0.10,
    "cancellation": 0.10,
    "seat_availability": 0.10,
}


def _safe_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _has_any(items: Iterable[str], wants: Iterable[str]) -> bool:
    a = {str(x).strip().lower() for x in items if x is not None}
    b = {str(x).strip().lower() for x in wants if x is not None}
    return bool(a.intersection(b))


def rank_buses(
    buses: List[Dict[str, Any]],
    budget: float | None = None,
    preferences: Dict[str, Any] | None = None,
) -> List[Dict[str, Any]]:
    """Return ranked buses with a `final_score` field, descending by score."""
    if not buses:
        return []

    preferences = preferences or {}
    prices = [_safe_float(bus.get("price_min"), 0.0) for bus in buses if bus.get("price_min") is not None]
    ratings = [_safe_float(bus.get("rating"), 0.0) for bus in buses if bus.get("rating") is not None]
    seats = [_safe_float(bus.get("available_seats"), 0.0) for bus in buses if bus.get("available_seats") is not None]

    min_price = min(prices) if prices else 0.0
    max_price = max(prices) if prices else 1.0
    max_rating = max(ratings) if ratings else 5.0
    max_seats = max(seats) if seats else 1.0

    comfortable_trip = bool(preferences.get("comfort_priority"))
    cheapest_trip = bool(preferences.get("cheapest_priority"))
    safe_trip = bool(preferences.get("safety_priority"))
    preferred_operator = str(preferences.get("preferred_operator") or "").strip().lower()
    preferred_bus_type = str(preferences.get("preferred_bus_type") or "").strip().lower()

    weights = dict(DEFAULT_WEIGHTS)
    if cheapest_trip:
        weights["price"] = 0.40
        weights["rating"] = 0.20
        weights["comfort"] = 0.15
    if comfortable_trip:
        weights["comfort"] = 0.30
        weights["amenities"] = 0.15
        weights["price"] = 0.20
    if safe_trip:
        weights["rating"] = 0.35
        weights["cancellation"] = 0.15

    ranked: List[Dict[str, Any]] = []
    for bus in buses:
        price = _safe_float(bus.get("price_min"), max_price)
        rating = _safe_float(bus.get("rating"), 0.0)
        comfort = _safe_float(bus.get("comfort_score"), 0.0)
        cancellation = _safe_float(bus.get("cancellation_score"), 0.0)
        available = _safe_float(bus.get("available_seats"), 0.0)
        amenities = bus.get("amenities") or []

        # Lower price is better; normalize to [0,1].
        if max_price <= min_price:
            price_score = 1.0
        else:
            price_score = 1.0 - ((price - min_price) / (max_price - min_price))

        if budget and budget > 0:
            if price > budget:
                price_score *= 0.5
            elif price <= budget * 0.85:
                price_score = min(price_score + 0.15, 1.0)

        rating_score = min(max(rating / max(max_rating, 1.0), 0.0), 1.0)
        comfort_score = min(max(comfort / 10.0, 0.0), 1.0)
        cancellation_score = min(max(cancellation / 10.0, 0.0), 1.0)
        seat_score = min(max(available / max(max_seats, 1.0), 0.0), 1.0)
        bus_type = str(bus.get("bus_type") or bus.get("type") or "").strip().lower()
        operator = str(bus.get("operator") or bus.get("operator_name") or bus.get("travels") or bus.get("name") or "").strip().lower()
        memory_match_score = 0.0
        if preferred_bus_type and preferred_bus_type in bus_type:
            memory_match_score += 0.25
        if preferred_operator and preferred_operator in operator:
            memory_match_score += 0.25

        amenity_targets = []
        if preferences.get("sleeper"):
            amenity_targets.extend(["blanket", "pillow"])
        if preferences.get("comfort_priority"):
            amenity_targets.extend(["usb", "charging", "water bottle"])
        amenity_score = 1.0 if _has_any(amenities, amenity_targets) else 0.5

        final_score = (
            price_score * weights["price"]
            + rating_score * weights["rating"]
            + comfort_score * weights["comfort"]
            + amenity_score * weights["amenities"]
            + cancellation_score * weights["cancellation"]
            + seat_score * weights["seat_availability"]
            + memory_match_score
        )

        ranked_bus = dict(bus)
        ranked_bus["score_breakdown"] = {
            "price_score": round(price_score, 4),
            "rating_score": round(rating_score, 4),
            "comfort_score": round(comfort_score, 4),
            "amenity_score": round(amenity_score, 4),
            "cancellation_score": round(cancellation_score, 4),
            "seat_score": round(seat_score, 4),
            "memory_match_score": round(memory_match_score, 4),
        }
        ranked_bus["final_score"] = round(final_score, 6)
        ranked.append(ranked_bus)

    return sorted(ranked, key=lambda bus: bus.get("final_score", 0.0), reverse=True)
