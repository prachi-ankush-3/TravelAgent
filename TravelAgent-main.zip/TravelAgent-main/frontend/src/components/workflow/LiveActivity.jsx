import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle2, Loader2, Circle } from 'lucide-react';

const WORKFLOW_STEPS = [
  'Understanding Request',
  'Searching Buses',
  'Recommendations',
  'Bus Selection',
  'Seat Confirmation',
  'Payment',
];

function normalizeStepLabel(step = '') {
  return step.toLowerCase().replace(/[^a-z]/g, '');
}

function matchStep(workflowStep, canonical) {
  const a = normalizeStepLabel(workflowStep);
  const b = normalizeStepLabel(canonical);
  return a.includes(b.slice(0, 6)) || b.includes(a.slice(0, 6));
}

export default function LiveActivity({ workflow = [] }) {
  // Build display steps by merging workflow data with canonical list
  const displaySteps = WORKFLOW_STEPS.map((label) => {
    const match = workflow.find((w) => matchStep(w.step || w.label || '', label));
    if (match) {
      return { label, status: match.status || 'pending' };
    }
    // Determine fallback status from position relative to completed steps
    return { label, status: 'pending' };
  });

  // If no workflow data, show empty state
  const hasWorkflow = workflow.length > 0;

  return (
    <aside className="thinking-panel">
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '6px' }}>
        <motion.div
          animate={{ rotate: hasWorkflow ? 360 : 0 }}
          transition={{ duration: 4, repeat: hasWorkflow ? Infinity : 0, ease: 'linear' }}
          style={{
            width: '28px', height: '28px', borderRadius: '50%',
            background: 'rgba(255,154,60,0.15)',
            border: '1px solid rgba(255,154,60,0.35)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}
        >
          <span style={{ fontSize: '13px' }}>✦</span>
        </motion.div>
        <div>
          <div style={{ fontSize: '15px', fontWeight: 700, color: 'white', lineHeight: 1.2 }}>TravAgent Thinking</div>
          <div style={{ fontSize: '10px', color: 'var(--text-muted)', letterSpacing: '0.12em', textTransform: 'uppercase' }}>AI Logic Steps</div>
        </div>
      </div>

      <div style={{ height: '1px', background: 'var(--glass-border)', margin: '14px 0 20px' }} />

      {/* Steps Timeline */}
      <div style={{ position: 'relative' }}>
        {/* Vertical line */}
        <div style={{
          position: 'absolute',
          left: '11px',
          top: '12px',
          bottom: '12px',
          width: '2px',
          background: 'linear-gradient(to bottom, rgba(255,154,60,0.3), rgba(255,255,255,0.06))',
          zIndex: 0,
        }} />

        <div style={{ display: 'flex', flexDirection: 'column', gap: '0', position: 'relative', zIndex: 1 }}>
          <AnimatePresence>
            {displaySteps.map((item, index) => {
              const isCompleted = item.status === 'completed';
              const isActive = item.status === 'processing' || item.status === 'active';
              const isPending = !isCompleted && !isActive;

              return (
                <motion.div
                  key={item.label}
                  initial={{ opacity: 0, x: 16 }}
                  animate={{ opacity: isPending ? 0.45 : 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  style={{ display: 'flex', gap: '14px', alignItems: 'flex-start', padding: '10px 0' }}
                >
                  {/* Step indicator */}
                  <div style={{
                    width: '24px', height: '24px', borderRadius: '50%', flexShrink: 0,
                    background: isCompleted
                      ? 'rgba(16, 185, 129, 0.15)'
                      : isActive
                        ? 'rgba(255,154,60,0.18)'
                        : 'rgba(255,255,255,0.04)',
                    border: `1.5px solid ${isCompleted ? '#10B981' : isActive ? 'var(--accent-orange)' : 'rgba(255,255,255,0.15)'}`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    {isCompleted ? (
                      <CheckCircle2 size={13} color="#10B981" fill="rgba(16,185,129,0.2)" />
                    ) : isActive ? (
                      <motion.div animate={{ rotate: 360 }} transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}>
                        <Loader2 size={13} color="var(--accent-orange)" />
                      </motion.div>
                    ) : (
                      <div style={{ width: '7px', height: '7px', borderRadius: '50%', background: 'rgba(255,255,255,0.2)' }} />
                    )}
                  </div>

                  {/* Step label */}
                  <div style={{ paddingTop: '2px' }}>
                    <div style={{
                      fontSize: '13px',
                      fontWeight: isActive ? 700 : isCompleted ? 600 : 500,
                      color: isActive ? 'white' : isCompleted ? 'var(--text-main)' : 'var(--text-muted)',
                      lineHeight: 1.3,
                    }}>
                      {item.label}
                    </div>
                    <div style={{
                      marginTop: '2px',
                      fontSize: '10px',
                      letterSpacing: '0.1em',
                      textTransform: 'uppercase',
                      color: isCompleted ? '#10B981' : isActive ? 'var(--accent-orange)' : 'transparent',
                      fontWeight: 600,
                    }}>
                      {isCompleted ? 'Completed' : isActive ? 'Active' : 'Pending'}
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      </div>
    </aside>
  );
}
