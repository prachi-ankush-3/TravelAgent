"""Optional LLM-based beautification for already-structured itineraries."""
from __future__ import annotations

import json
from typing import Any, Dict, Optional

import httpx

from app.core.config import (
    ENABLE_ITINERARY_BEAUTIFICATION,
    LM_STUDIO_CHAT_ENDPOINT,
    LM_STUDIO_MODEL,
    LLM_MAX_TOKENS,
    LLM_REQUEST_TIMEOUT,
    LLM_TEMPERATURE,
)
from app.core.prompts import ITINERARY_BEAUTIFICATION_SYSTEM_PROMPT


def beautify_itinerary(
    structured_itinerary: Dict[str, Any],
    *,
    destination: str | None = None,
    enabled: bool | None = None,
) -> Optional[str]:
    """Turn a structured itinerary into a friendly travel guide.

    The function is optional and safe-by-default: if beautification is disabled
    or the LLM call fails, it returns None and the deterministic itinerary stays
    unchanged.
    """
    should_beautify = ENABLE_ITINERARY_BEAUTIFICATION if enabled is None else enabled
    fallback = render_itinerary_guide(structured_itinerary, destination=destination)
    if not should_beautify:
        return fallback

    payload = {
        "model": LM_STUDIO_MODEL,
        "messages": [
            {"role": "system", "content": ITINERARY_BEAUTIFICATION_SYSTEM_PROMPT},
            {
                "role": "user",
                "content": json.dumps(
                    {
                        "destination": destination,
                        "itinerary": structured_itinerary,
                    },
                    ensure_ascii=False,
                    default=str,
                ),
            },
        ],
        "max_tokens": LLM_MAX_TOKENS,
        "temperature": LLM_TEMPERATURE,
    }

    try:
        with httpx.Client(timeout=LLM_REQUEST_TIMEOUT) as client:
            response = client.post(LM_STUDIO_CHAT_ENDPOINT, json=payload)
            response.raise_for_status()

        llm_data = response.json()
        text = llm_data["choices"][0]["message"]["content"].strip()
        if text.startswith("```"):
            text = text.split("```")[1]
            if text.startswith("json"):
                text = text[4:]
            text = text.strip()
        return text or None
    except Exception:
        return fallback


def render_itinerary_guide(
    structured_itinerary: Dict[str, Any],
    *,
    destination: str | None = None,
) -> str:
    """Create a friendly textual guide directly from structured itinerary data."""
    days = structured_itinerary if isinstance(structured_itinerary, dict) else {}
    day_keys = sorted(
        [key for key in days.keys() if str(key).lower().startswith("day ")],
        key=lambda value: int(str(value).split()[1]) if str(value).split()[1].isdigit() else 0,
    )

    guide_parts: list[str] = []
    intro_destination = destination or "your destination"
    guide_parts.append(f"Here is your planned trip to {intro_destination}:")

    for day_key in day_keys:
        day = days.get(day_key, {})
        morning = day.get("Morning", []) if isinstance(day, dict) else []
        afternoon = day.get("Afternoon", []) if isinstance(day, dict) else []
        evening = day.get("Evening", []) if isinstance(day, dict) else []

        segments: list[str] = []
        if morning:
            segments.append(f"morning: {', '.join(_pretty_activities(morning))}")
        if afternoon:
            segments.append(f"afternoon: {', '.join(_pretty_activities(afternoon))}")
        if evening:
            segments.append(f"evening: {', '.join(_pretty_activities(evening))}")

        if segments:
            guide_parts.append(f"{day_key}: {', '.join(segments).capitalize()}.")
        else:
            guide_parts.append(f"{day_key}: Keep the day flexible and enjoy a relaxed pace.")

    return "\n".join(guide_parts)


def _pretty_activities(items: list[str]) -> list[str]:
    """Convert raw activity labels into friendlier travel-guide phrases."""
    pretty: list[str] = []
    for item in items:
        label = str(item).strip()
        if label.lower().startswith("check-in at "):
            hotel_name = label[len("Check-in at "):].strip()
            pretty.append(f"check in at {hotel_name}")
        else:
            pretty.append(label)
    return pretty