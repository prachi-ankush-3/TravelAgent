import React from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { X, ArrowRight } from 'lucide-react';

function formatPrice(price) {
	if (price === null || price === undefined || price === '') return '—';
	const value = Number(price);
	if (Number.isNaN(value)) return String(price);
	return `₹${Math.round(value).toLocaleString('en-IN')}`;
}

export default function AllBusesModal({ open, buses = [], loading = false, onClose, onSelectBus }) {
	return (
		<AnimatePresence>
			{open && (
				<motion.div
					initial={{ opacity: 0 }}
					animate={{ opacity: 1 }}
					exit={{ opacity: 0 }}
					style={{ position: 'fixed', inset: 0, background: 'rgba(5, 8, 14, 0.78)', backdropFilter: 'blur(18px)', zIndex: 80, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '24px' }}
				>
					<motion.div
						initial={{ y: 18, scale: 0.98 }}
						animate={{ y: 0, scale: 1 }}
						exit={{ y: 18, scale: 0.98 }}
						style={{ width: 'min(1100px, 100%)', maxHeight: '88vh', overflow: 'auto', background: 'linear-gradient(180deg, rgba(13,16,24,0.98), rgba(8,10,16,0.98))', borderRadius: '28px', border: '1px solid rgba(255,255,255,0.08)', boxShadow: '0 30px 80px rgba(0,0,0,0.5)', padding: '22px' }}
					>
						<div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '16px' }}>
							<div>
								<div style={{ color: 'var(--accent-orange)', fontSize: '11px', fontWeight: 800, letterSpacing: '0.1em', textTransform: 'uppercase' }}>Available buses</div>
								<div style={{ marginTop: '6px', color: 'white', fontSize: '20px', fontWeight: 800 }}>Every option ranked by the AI</div>
							</div>
							<button onClick={onClose} style={{ width: '40px', height: '40px', borderRadius: '12px', border: '1px solid rgba(255,255,255,0.08)', background: 'rgba(255,255,255,0.04)', color: 'white', cursor: 'pointer' }}>
								<X size={18} />
							</button>
						</div>

						<div style={{ marginTop: '18px', display: 'grid', gap: '12px' }}>
							{buses.map((bus, index) => (
								<div key={bus.bus_id || bus.id || index} style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr auto', gap: '14px', alignItems: 'center', padding: '14px 16px', borderRadius: '18px', background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.05)' }}>
									<div>
										<div style={{ color: 'white', fontWeight: 800 }}>{bus.operator || 'Trusted Operator'}</div>
										<div style={{ marginTop: '4px', color: 'var(--text-muted)', fontSize: '13px' }}>{bus.rank_label || 'Smart Match'} · {bus.headline || 'AI matched'}</div>
										<div style={{ marginTop: '8px', color: 'var(--text-muted)', fontSize: '12px', lineHeight: 1.5 }}>{bus.reason || 'Matched to your route and preferences.'}</div>
									</div>
									<div style={{ color: 'white', fontSize: '14px' }}>
										<div>Departure: <strong>{bus.departure_time || '—'}</strong></div>
										<div style={{ marginTop: '4px' }}>Rating: <strong>{Number(bus.rating || 0).toFixed(1)}</strong></div>
										<div style={{ marginTop: '4px' }}>Price: <strong>{formatPrice(bus.price)}</strong></div>
									</div>
									<button disabled={loading} onClick={() => onSelectBus?.(bus)} style={{ padding: '12px 14px', borderRadius: '14px', border: 'none', background: 'linear-gradient(135deg, #ff9a3c, #ff6a00)', color: 'black', fontWeight: 800, cursor: loading ? 'wait' : 'pointer', display: 'inline-flex', alignItems: 'center', gap: '8px' }}>
										Choose <ArrowRight size={16} />
									</button>
								</div>
							))}
						</div>
					</motion.div>
				</motion.div>
			)}
		</AnimatePresence>
	);
}
