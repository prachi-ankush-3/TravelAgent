import React from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { BusFront, BrainCircuit, ArrowRight, ArrowLeft } from 'lucide-react';
import { login } from '../services/authService';
import { getDashboardPath } from '../services/uiStorage';

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState('');

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      await login({ email, password });
      navigate(getDashboardPath());
    } catch (err) {
      const message = err?.response?.data?.detail || err?.message || 'Login failed.';
      setError(message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="layout-container auth-bg-image" style={{ position: 'relative', justifyContent: 'center', alignItems: 'center' }}>
      <div style={{ position: 'absolute', top: '30px', left: '40px', zIndex: 20 }}>
        <button onClick={() => navigate('/')} style={{ background: 'transparent', border: 'none', color: 'white', display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', fontSize: '14px', fontWeight: 600 }}>
          <ArrowLeft size={18} /> Back to Home
        </button>
      </div>
      <div className="orb orb-orange" style={{ top: '10%', left: '15%', width: '300px', height: '300px' }} />
      <div className="orb orb-blue" style={{ bottom: '15%', right: '10%', width: '400px', height: '400px' }} />
      
      <motion.div 
        className="glass-panel"
        style={{ padding: '40px', width: '100%', maxWidth: '420px', zIndex: 10 }}
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div style={{ textAlign: 'center', marginBottom: '32px' }}>
          <motion.div
            className="animate-glow"
            style={{ display: 'inline-flex', padding: '16px', borderRadius: '50%', background: 'var(--glass-bg)', border: '1px solid var(--glass-border)', marginBottom: '16px' }}
          >
            <BrainCircuit size={32} color="var(--accent-orange)" />
          </motion.div>
          <h2 className="gradient-text" style={{ fontSize: '28px', fontWeight: 900, marginBottom: '8px' }}>Welcome Back</h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '14px' }}>
            <span style={{ color: 'var(--accent-orange)' }}>AI remembers your travel preferences</span> for a seamless booking experience.
          </p>
        </div>

        <form onSubmit={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          <div>
            <label style={{ display: 'block', marginBottom: '8px', fontSize: '14px', color: 'var(--text-muted)' }}>Email Address</label>
            <input type="email" className="ai-input" placeholder="traveler@example.com" required value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div>
            <label style={{ display: 'block', marginBottom: '8px', fontSize: '14px', color: 'var(--text-muted)' }}>Password</label>
            <input type="password" className="ai-input" placeholder="••••••••" required value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          {error ? (
            <div style={{ color: '#FCA5A5', fontSize: '14px', lineHeight: 1.4 }}>
              {error}
            </div>
          ) : null}
          
          <button type="submit" className="ai-btn" style={{ marginTop: '8px' }} disabled={loading}>
            {loading ? 'Signing in...' : <>Enter Workspace <ArrowRight size={18} /></>}
          </button>
        </form>

        <div style={{ marginTop: '24px', textAlign: 'center', fontSize: '14px', color: 'var(--text-muted)' }}>
          New to TravAgent? <Link to="/signup" style={{ color: 'var(--text-main)', textDecoration: 'none', borderBottom: '1px solid var(--accent-orange)' }}>Create Your Travel Identity</Link>
        </div>
      </motion.div>
      
      {/* Background cinematic bus */}
      <motion.div
         style={{ position: 'absolute', bottom: '5%', left: '0', color: 'rgba(255,255,255,0.1)', zIndex: 0 }}
         animate={{ x: ['-20vw', '120vw'] }}
         transition={{ duration: 15, repeat: Infinity, ease: 'linear' }}
      >
         <BusFront size={120} />
      </motion.div>
    </div>
  );
}
