# app/state/session_manager.py
# SessionManager — tracks all active GlobalTravelState instances.
#
# Each user gets a unique session_id (UUID4).
# The manager stores {session_id: GlobalTravelState} in an in-memory dict.
# For production, swap the dict with Redis or a DB-backed store.

from __future__ import annotations
import uuid
from typing import Dict, Optional

from app.core.logger import get_logger
from app.state.global_state import GlobalTravelState

log = get_logger(__name__)


class SessionManager:
    """
    Registry of active travel sessions.

    Usage:
        manager = SessionManager()
        session_id = manager.create_session()          # → "3f2a-..."
        state = manager.get_session(session_id)        # → GlobalTravelState
        manager.delete_session(session_id)             # cleanup
    """

    def __init__(self) -> None:
        self._sessions: Dict[str, GlobalTravelState] = {}
        log.info("[SessionManager] Initialised")

    # ── CRUD ──────────────────────────────────────────────────────────────────

    def create_session(self, session_id: Optional[str] = None) -> str:
        """
        Create a new session and return its ID.
        Pass a custom session_id for testing; leave None for auto-UUID.
        """
        sid = session_id or str(uuid.uuid4())
        self._sessions[sid] = GlobalTravelState(session_id=sid)
        log.info(f"[SessionManager] Created session → {sid}")
        return sid

    def get_session(self, session_id: str) -> GlobalTravelState:
        """
        Retrieve an existing session.
        Raises KeyError if the session_id is unknown.
        """
        if session_id not in self._sessions:
            raise KeyError(f"Session '{session_id}' not found. Call create_session() first.")
        return self._sessions[session_id]

    def get_or_create(self, session_id: str) -> GlobalTravelState:
        """Return existing session or create one with the given ID."""
        if session_id not in self._sessions:
            self.create_session(session_id=session_id)
        return self._sessions[session_id]

    def delete_session(self, session_id: str) -> None:
        """Remove a session from memory (call after plan is delivered)."""
        if session_id in self._sessions:
            del self._sessions[session_id]
            log.info(f"[SessionManager] Deleted session → {session_id}")
        else:
            log.warning(f"[SessionManager] Tried to delete unknown session: {session_id}")

    def list_sessions(self) -> list[str]:
        """Return all active session IDs (useful for debugging)."""
        return list(self._sessions.keys())

    def session_count(self) -> int:
        return len(self._sessions)

    def __repr__(self) -> str:
        return f"<SessionManager active_sessions={self.session_count()}>"


# ── Module-level singleton ─────────────────────────────────────────────────────
# Import this anywhere in the project to access the shared manager.
session_manager = SessionManager()
