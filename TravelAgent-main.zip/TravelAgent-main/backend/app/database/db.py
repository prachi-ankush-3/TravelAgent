"""Supabase integration helpers for authentication and database access."""

from __future__ import annotations

from typing import Any, Dict, Optional

import httpx

from app.core.config import SUPABASE_ANON_KEY, SUPABASE_SERVICE_KEY, SUPABASE_URL


class SupabaseError(RuntimeError):
	"""Raised when a Supabase request fails."""


def _require_supabase_config() -> None:
	if not SUPABASE_URL:
		raise SupabaseError("SUPABASE_URL is not configured.")
	if not SUPABASE_SERVICE_KEY:
		raise SupabaseError("SUPABASE_SERVICE_KEY is not configured.")


def _auth_headers(api_key: Optional[str] = None) -> Dict[str, str]:
	key = api_key or SUPABASE_SERVICE_KEY
	return {
		"apikey": key,
		"Authorization": f"Bearer {key}",
		"Content-Type": "application/json",
	}


async def _supabase_request(
	method: str,
	path: str,
	*,
	json: Optional[Any] = None,
	params: Optional[Dict[str, Any]] = None,
	api_key: Optional[str] = None,
	headers: Optional[Dict[str, str]] = None,
) -> Any:
	_require_supabase_config()
	url = f"{SUPABASE_URL.rstrip('/')}/{path.lstrip('/')}"
	request_headers = _auth_headers(api_key)
	if headers:
		request_headers.update(headers)
	async with httpx.AsyncClient(timeout=30) as client:
		response = await client.request(
			method=method,
			url=url,
			headers=request_headers,
			json=json,
			params=params,
		)

	if response.status_code >= 400:
		try:
			detail: Any = response.json()
		except Exception:
			detail = response.text
		raise SupabaseError(f"Supabase request failed ({response.status_code}): {detail}")

	if response.content:
		return response.json()
	return {}


async def create_user(
	*,
	email: str,
	password: str,
	username: Optional[str] = None,
) -> Dict[str, Any]:
	payload: Dict[str, Any] = {
		"email": email,
		"password": password,
		"email_confirm": True,
	}
	if username:
		payload["user_metadata"] = {"username": username}
	return await _supabase_request("POST", "/auth/v1/admin/users", json=payload)


async def upsert_profile(
	*,
	user_id: str,
	email: str,
	username: Optional[str] = None,
	full_name: Optional[str] = None,
	age: Optional[int] = None,
	mobile: Optional[str] = None,
	gender: Optional[str] = None,
	booking_preferences: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
	row: Dict[str, Any] = {
		"id": user_id,
		"email": email,
	}
	resolved_name = full_name or username
	if resolved_name:
		row["full_name"] = resolved_name
	if age is not None:
		row["age"] = age
	if mobile:
		row["mobile"] = mobile
	if gender:
		row["gender"] = gender
	if booking_preferences is not None:
		row["booking_preferences"] = booking_preferences
	return await _supabase_request(
		"POST",
		"/rest/v1/profiles",
		json=[row],
		params={"on_conflict": "id"},
		headers={"Prefer": "resolution=merge-duplicates,return=representation"},
	)


async def get_profile(user_id: str) -> Dict[str, Any]:
	profiles = await _supabase_request(
		"GET",
		"/rest/v1/profiles",
		params={"select": "*", "id": f"eq.{user_id}", "limit": "1"},
	)
	if isinstance(profiles, list) and profiles:
		first_row = profiles[0]
		return first_row if isinstance(first_row, dict) else {}
	return {}


async def sign_in(
	*,
	email: str,
	password: str,
) -> Dict[str, Any]:
	api_key = SUPABASE_ANON_KEY or SUPABASE_SERVICE_KEY
	return await _supabase_request(
		"POST",
		"/auth/v1/token",
		json={"email": email, "password": password},
		params={"grant_type": "password"},
		api_key=api_key,
	)


async def get_user(access_token: str) -> Dict[str, Any]:
	_require_supabase_config()
	url = f"{SUPABASE_URL.rstrip('/')}/auth/v1/user"
	headers = _auth_headers(SUPABASE_ANON_KEY or SUPABASE_SERVICE_KEY)
	headers["Authorization"] = f"Bearer {access_token}"
	async with httpx.AsyncClient(timeout=30) as client:
		response = await client.get(url, headers=headers)

	if response.status_code >= 400:
		try:
			detail: Any = response.json()
		except Exception:
			detail = response.text
		raise SupabaseError(f"Supabase request failed ({response.status_code}): {detail}")

	return response.json()
