import React from 'react';
import { motion } from 'framer-motion';
import { MapPin, Calendar, IndianRupee, Clock, Navigation, BedDouble, Info, CheckCircle2 } from 'lucide-react';

export default function PlannerResults({ results }) {
  if (!results || !results.state_snapshot) return null;

  const state = results.state_snapshot;
  const { origin, destination, travel_date, budget, travel_style, daily_schedule, itinerary } = state;

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <motion.div 
      className="planner-results"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      style={{ maxWidth: '800px', margin: '0 auto', width: '100%', paddingBottom: '60px' }}
    >
      {/* Overview Header */}
      <motion.div variants={itemVariants} style={{ 
        background: 'var(--glass-bg)', 
        border: '1px solid var(--glass-border)', 
        borderRadius: '24px',
        padding: '32px',
        marginBottom: '32px',
        position: 'relative',
        overflow: 'hidden'
      }}>
        {/* Decorative background glow */}
        <div style={{ position: 'absolute', top: -100, right: -100, width: 300, height: 300, background: 'radial-gradient(circle, var(--accent-orange-glow) 0%, transparent 70%)', opacity: 0.5, pointerEvents: 'none' }} />

        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '24px', position: 'relative', zIndex: 1 }}>
          <div>
            <h2 style={{ fontSize: '36px', fontWeight: 900, color: 'white', marginBottom: '8px', letterSpacing: '-1px' }}>
              {destination || 'Your Destination'}
            </h2>
            <div style={{ display: 'flex', alignItems: 'center', gap: '16px', color: 'var(--text-muted)' }}>
              {origin && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <Navigation size={16} color="var(--accent-orange)" />
                  <span>From {origin}</span>
                </div>
              )}
              {travel_date && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <Calendar size={16} color="var(--accent-orange)" />
                  <span>{travel_date}</span>
                </div>
              )}
            </div>
          </div>
          
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: '12px', textTransform: 'uppercase', letterSpacing: '1px', color: 'var(--text-muted)', marginBottom: '4px' }}>
              Est. Budget
            </div>
            <div style={{ fontSize: '28px', fontWeight: 800, color: 'var(--accent-orange)', display: 'flex', alignItems: 'center', gap: '4px' }}>
              <IndianRupee size={24} />
              {budget ? budget.toLocaleString() : 'Flexible'}
            </div>
          </div>
        </div>

        {travel_style && (
          <div style={{ marginTop: '24px', display: 'inline-flex', alignItems: 'center', gap: '8px', padding: '8px 16px', background: 'rgba(255,255,255,0.05)', borderRadius: '99px', fontSize: '14px', color: 'white', border: '1px solid rgba(255,255,255,0.1)' }}>
            <Info size={16} color="var(--accent-orange)" />
            Travel Style: <span style={{ textTransform: 'capitalize', fontWeight: 600 }}>{travel_style}</span>
          </div>
        )}
      </motion.div>

      {/* Daily Schedule */}
      {daily_schedule && Object.keys(daily_schedule).length > 0 ? (
        <motion.div variants={itemVariants}>
          <h3 style={{ fontSize: '24px', fontWeight: 800, color: 'white', marginBottom: '24px', paddingLeft: '8px' }}>
            Day-by-Day Itinerary
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
            {Object.entries(daily_schedule).map(([dayKey, rawDayData], index) => {
              const data = Array.isArray(rawDayData) ? (typeof rawDayData[0] === 'object' ? rawDayData[0] : null) : rawDayData;
              const isRichFormat = data && typeof data === 'object' && !Array.isArray(data);
              
              const dayActivities = isRichFormat ? (data.activities || []) : (Array.isArray(rawDayData) ? rawDayData : []);
              const hotel = isRichFormat ? data.hotel : null;
              const spend = isRichFormat ? data.estimated_spend : null;

              return (
                <motion.div 
                  key={dayKey}
                  variants={itemVariants}
                  style={{ 
                    background: 'rgba(255,255,255,0.02)', 
                    border: '1px solid rgba(255,255,255,0.05)', 
                    borderRadius: '20px',
                    padding: '24px'
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '20px', paddingBottom: '16px', borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                      <div style={{ width: '32px', height: '32px', borderRadius: '10px', background: 'var(--accent-orange)', color: 'black', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: '14px' }}>
                        {index + 1}
                      </div>
                      <h4 style={{ fontSize: '20px', fontWeight: 700, color: 'white' }}>{dayKey}</h4>
                    </div>
                    {spend && spend.estimated_total > 0 && (
                      <div style={{ fontSize: '14px', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '4px' }}>
                        Est. Day Spend: <span style={{ color: 'white', fontWeight: 600 }}>₹{spend.estimated_total}</span>
                      </div>
                    )}
                  </div>

                  {/* Hotel info for the day */}
                  {hotel && hotel.name && (
                    <div style={{ marginBottom: '20px', display: 'flex', alignItems: 'center', gap: '12px', background: 'rgba(29, 209, 161, 0.05)', border: '1px solid rgba(29, 209, 161, 0.2)', padding: '12px 16px', borderRadius: '12px' }}>
                      <BedDouble size={20} color="#1dd1a1" />
                      <div>
                        <div style={{ fontSize: '15px', color: 'white', fontWeight: 600 }}>{hotel.name}</div>
                        <div style={{ fontSize: '13px', color: 'var(--text-muted)' }}>{hotel.location || 'Accommodation'} • ₹{hotel.price_per_night || 0}/night</div>
                      </div>
                    </div>
                  )}

                  {/* Activities list */}
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                    {dayActivities.length > 0 ? dayActivities.map((act, actIdx) => {
                      const isRichAct = typeof act === 'object';
                      const actTime = isRichAct ? (act.slot || act.time || 'Anytime') : 'Anytime';
                      const actName = isRichAct ? (act.name || act.activity || JSON.stringify(act)) : act;
                      const actDesc = isRichAct ? act.description : null;
                      const actCost = isRichAct ? act.estimated_cost : null;

                      return (
                        <div key={actIdx} style={{ display: 'flex', alignItems: 'flex-start', gap: '16px' }}>
                          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: '4px', width: '70px', flexShrink: 0, marginTop: '2px' }}>
                            <div style={{ fontSize: '13px', fontWeight: 600, color: 'var(--accent-orange)' }}>
                              {actTime}
                            </div>
                          </div>
                          <div style={{ flex: 1, background: 'var(--glass-bg)', padding: '16px', borderRadius: '16px', border: '1px solid var(--glass-border)' }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '12px' }}>
                              <div style={{ fontSize: '16px', color: 'white', fontWeight: 600, lineHeight: 1.4 }}>
                                {actName}
                              </div>
                              {actCost > 0 && (
                                <div style={{ fontSize: '13px', color: '#10b981', fontWeight: 600, whiteSpace: 'nowrap' }}>
                                  ₹{actCost}
                                </div>
                              )}
                            </div>
                            {actDesc && (
                              <div style={{ fontSize: '14px', color: 'var(--text-muted)', marginTop: '8px', lineHeight: 1.5 }}>
                                {actDesc}
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    }) : (
                      <div style={{ color: 'var(--text-muted)', fontSize: '14px', fontStyle: 'italic' }}>Leisure / Free time</div>
                    )}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </motion.div>
      ) : itinerary && itinerary.length > 0 ? (
        <motion.div variants={itemVariants}>
          <h3 style={{ fontSize: '24px', fontWeight: 800, color: 'white', marginBottom: '24px', paddingLeft: '8px' }}>
            Planned Route
          </h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
            {itinerary.map((item, idx) => (
              <div key={idx} style={{ display: 'flex', alignItems: 'center', gap: '16px', background: 'var(--glass-bg)', padding: '20px', borderRadius: '16px', border: '1px solid var(--glass-border)' }}>
                <MapPin size={24} color="var(--accent-orange)" />
                <div style={{ fontSize: '16px', color: 'white' }}>
                  {item.day ? `Day ${item.day}: ` : ''} 
                  {Array.isArray(item.locations) ? item.locations.join(', ') : item.location || JSON.stringify(item)}
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      ) : null}

      {/* Done State */}
      <motion.div variants={itemVariants} style={{ marginTop: '40px', textAlign: 'center', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}>
        <CheckCircle2 size={18} color="#10b981" />
        <span>Itinerary generated successfully by TravelAgent AI</span>
      </motion.div>
    </motion.div>
  );
}
