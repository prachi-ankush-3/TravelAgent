import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation, NavLink } from 'react-router-dom';
import { User } from 'lucide-react';

export default function Navbar() {
  const navigate = useNavigate();
  const location = useLocation();
  const isDashboard =
    location.pathname.includes('/dashboard') ||
    location.pathname.includes('/profile') ||
    location.pathname.includes('/ticket');

  return (
    <nav style={{
      position: 'sticky',
      top: 0, left: 0, right: 0, zIndex: 100,
      padding: '0 40px',
      height: '60px',
      background: 'rgba(13, 17, 30, 0.92)',
      backdropFilter: 'blur(16px)',
      borderBottom: '1px solid var(--glass-border)',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      flexShrink: 0,
    }}>
      {/* Logo */}
      <div
        style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer' }}
        onClick={() => navigate('/')}
      >
        <div style={{
          width: '32px', height: '32px', borderRadius: '8px',
          background: 'linear-gradient(135deg, #ff9a3c, #ff6a00)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: '16px'
        }}>
          🔥
        </div>
        <span style={{ fontSize: '18px', fontWeight: 700, color: 'white', letterSpacing: '-0.3px' }}>TravAgent</span>
      </div>

      {/* Center Nav Links */}
      <div style={{ display: 'flex', gap: '0', height: '100%' }}>
        {[
          { label: 'Home', to: '/', onClick: () => navigate('/') },
          { label: 'Bus Booking', to: '/dashboard/bus' },
          { label: 'Trip Planner', to: '/dashboard/planner' },
          { label: 'Features', to: '/', onClick: () => navigate('/') },
        ].map((item) => (
          <NavbarLink key={item.label} label={item.label} to={item.to} onClick={item.onClick} />
        ))}
      </div>

      {/* Right side */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
        {isDashboard ? (
          <>
            <button
              onClick={() => navigate('/profile')}
              style={{
                display: 'flex', alignItems: 'center', gap: '6px',
                background: 'transparent', border: 'none', color: 'var(--text-main)',
                cursor: 'pointer', fontSize: '14px', fontWeight: 500,
              }}
            >
              <User size={16} />
              Profile
            </button>
            <button
              onClick={() => navigate('/login')}
              style={{
                padding: '8px 20px', borderRadius: '8px',
                background: 'linear-gradient(135deg, #ff9a3c, #ff6a00)',
                border: 'none', color: 'white', fontWeight: 700,
                fontSize: '13px', cursor: 'pointer', letterSpacing: '0.5px',
                textTransform: 'uppercase',
              }}
            >
              LOGOUT
            </button>
          </>
        ) : (
          <>
            <button
              onClick={() => navigate('/login')}
              style={{ background: 'transparent', border: 'none', color: 'var(--text-main)', cursor: 'pointer', fontSize: '14px', fontWeight: 500 }}
            >
              Login
            </button>
            <button
              onClick={() => navigate('/signup')}
              style={{
                padding: '8px 20px', borderRadius: '8px',
                background: 'linear-gradient(135deg, #ff9a3c, #ff6a00)',
                border: 'none', color: 'white', fontWeight: 700,
                fontSize: '13px', cursor: 'pointer',
              }}
            >
              Get Started
            </button>
          </>
        )}
      </div>
    </nav>
  );
}

function NavbarLink({ label, to, onClick }) {
  const location = useLocation();
  const navigate = useNavigate();
  const isActive = to !== '/' && location.pathname.startsWith(to);

  return (
    <button
      onClick={onClick || (() => navigate(to))}
      style={{
        background: 'transparent',
        border: 'none',
        borderBottom: isActive ? '2px solid var(--accent-orange)' : '2px solid transparent',
        color: isActive ? 'var(--accent-orange)' : 'var(--text-main)',
        padding: '0 18px',
        height: '100%',
        cursor: 'pointer',
        fontSize: '14px',
        fontWeight: isActive ? 600 : 500,
        transition: 'color 0.2s, border-color 0.2s',
        fontFamily: 'inherit',
      }}
      onMouseEnter={(e) => { if (!isActive) e.currentTarget.style.color = 'white'; }}
      onMouseLeave={(e) => { if (!isActive) e.currentTarget.style.color = 'var(--text-main)'; }}
    >
      {label}
    </button>
  );
}
