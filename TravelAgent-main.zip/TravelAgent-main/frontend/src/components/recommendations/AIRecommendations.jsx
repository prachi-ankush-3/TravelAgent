import React from 'react';
import { motion } from 'framer-motion';
import { Layers3, List, Sparkles } from 'lucide-react';
import RecommendationCard from './RecommendationCard';

export default function AIRecommendations({ recommendations = [], allBuses = [], loading = false, onSelectBus, onViewAll }) {
	return (
		<div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
			<div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', gap: '12px', flexWrap: 'wrap' }}>
				<div>
					<div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--accent-orange)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em', fontSize: '11px' }}>
						<Sparkles size={12} /> Top 3 AI cards
					</div>
					<div style={{ marginTop: '6px', fontSize: '18px', fontWeight: 800, color: 'white' }}>The assistant highlighted the best fits</div>
				</div>
				<button
					onClick={onViewAll}
					style={{
						padding: '10px 14px',
						borderRadius: '14px',
						border: '1px solid rgba(255,255,255,0.08)',
						background: 'rgba(255,255,255,0.04)',
						color: 'white',
						fontWeight: 700,
						cursor: 'pointer',
						display: 'inline-flex',
						alignItems: 'center',
						gap: '8px',
					}}
				>
					<List size={16} /> View all {allBuses.length || recommendations.length || 0} buses
				</button>
			</div>

			<motion.div
				initial={{ opacity: 0 }}
				animate={{ opacity: 1 }}
				style={{
					display: 'grid',
					gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
					gap: '14px',
				}}
			>
				{recommendations.slice(0, 3).map((bus) => (
					<RecommendationCard key={bus.bus_id || bus.id || bus.rank_label} bus={bus} onSelect={onSelectBus} loading={loading} />
				))}
			</motion.div>

			{loading && (
				<div style={{ color: 'var(--text-muted)', fontSize: '13px', display: 'flex', alignItems: 'center', gap: '8px' }}>
					<Layers3 size={14} /> The AI is preparing the next step.
				</div>
			)}
		</div>
	);
}
