import React, { useMemo } from 'react';
import { Plus, History, BookOpen, Bookmark, Settings, Clock3, HelpCircle, LifeBuoy } from 'lucide-react';
import BookingHistoryItem from './BookingHistoryItem';

function groupBookings(bookings = []) {
	const today = new Date();
	today.setHours(0, 0, 0, 0);
	const yesterday = new Date(today);
	yesterday.setDate(yesterday.getDate() - 1);

	const groups = { Today: [], Yesterday: [], Earlier: [] };
	for (const booking of bookings) {
		const raw = booking?.updated_at || booking?.travel_date;
		const date = new Date(raw);
		if (Number.isNaN(date.getTime())) {
			groups.Earlier.push(booking);
			continue;
		}
		const normalized = new Date(date);
		normalized.setHours(0, 0, 0, 0);
		if (normalized.getTime() === today.getTime()) groups.Today.push(booking);
		else if (normalized.getTime() === yesterday.getTime()) groups.Yesterday.push(booking);
		else groups.Earlier.push(booking);
	}
	return groups;
}

export default function BookingSidebar({ bookings = [], currentBookingId = '', onNewBooking, onSelectBooking, loading = false }) {
	const grouped = useMemo(() => groupBookings(bookings), [bookings]);
	const totalBookings = bookings.length;
	const hasBookings = totalBookings > 0;

	const renderGroup = (label, items) => {
		if (!items.length) return null;
		return (
			<div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
				<div style={{ display: 'flex', alignItems: 'center', gap: '6px', color: 'var(--text-muted)', fontSize: '11px', textTransform: 'uppercase', letterSpacing: '0.12em', padding: '0 4px', marginBottom: '2px' }}>
					<Clock3 size={11} /> {label}
				</div>
				{items.map((item) => (
					<BookingHistoryItem
						key={item.booking_id || item.id || `${item.title}-${item.updated_at}`}
						item={item}
						active={(item.booking_id || item.id || item.session_id) === currentBookingId}
						onClick={() => onSelectBooking?.(item.booking_id || item.id || item.session_id)}
					/>
				))}
			</div>
		);
	};

	return (
		<aside className="booking-sidebar-panel">
			{/* Header */}
			<div style={{ padding: '20px 18px 14px', borderBottom: '1px solid var(--glass-border)', flexShrink: 0 }}>
				<div style={{ fontSize: '16px', fontWeight: 700, color: 'white', marginBottom: '2px' }}>Booking History</div>
				<div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>Manage your journeys</div>
			</div>

			{/* New Booking Button */}
			<div style={{ padding: '12px 14px', flexShrink: 0 }}>
				<button
					type="button"
					onClick={onNewBooking}
					disabled={loading}
					className="booking-new-btn-v2"
				>
					<Plus size={16} strokeWidth={2.5} />
					New Booking
				</button>
			</div>

			{/* Current Booking Active Item */}
			{currentBookingId && (
				<div style={{ padding: '0 14px 4px', flexShrink: 0 }}>
					<button
						type="button"
						className="sidebar-current-booking"
						onClick={() => onSelectBooking?.(currentBookingId)}
					>
						<BookOpen size={14} />
						<span>Current Booking</span>
					</button>
				</div>
			)}

			{/* Divider with label */}
			<div style={{ padding: '10px 18px 6px', flexShrink: 0 }}>
				<div style={{ fontSize: '11px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.1em', display: 'flex', alignItems: 'center', gap: '6px' }}>
					<History size={11} /> Booking History
				</div>
			</div>

			{/* Booking List */}
			<div style={{ flex: 1, overflowY: 'auto', padding: '0 14px', display: 'flex', flexDirection: 'column', gap: '14px', minHeight: 0 }}>
				{hasBookings ? (
					<>
						{renderGroup('Today', grouped.Today)}
						{renderGroup('Yesterday', grouped.Yesterday)}
						{renderGroup('Earlier', grouped.Earlier)}
					</>
				) : (
					<div style={{ padding: '16px', borderRadius: '12px', background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)', color: 'var(--text-muted)', fontSize: '13px', lineHeight: 1.5 }}>
						Start a new booking — your trips will appear here.
					</div>
				)}
			</div>

			{/* Bottom nav links */}
			<div style={{ padding: '12px 14px', borderTop: '1px solid var(--glass-border)', flexShrink: 0, display: 'flex', flexDirection: 'column', gap: '2px' }}>
				<SidebarNavItem icon={<Bookmark size={15} />} label="Saved Trips" />
				<SidebarNavItem icon={<Settings size={15} />} label="Settings" />
			</div>

			{/* Help and Support at very bottom */}
			<div style={{ padding: '8px 14px 16px', flexShrink: 0, display: 'flex', flexDirection: 'column', gap: '2px' }}>
				<SidebarNavItem icon={<HelpCircle size={15} />} label="Help Center" />
				<SidebarNavItem icon={<LifeBuoy size={15} />} label="Support" />
			</div>
		</aside>
	);
}

function SidebarNavItem({ icon, label, active = false, onClick }) {
	return (
		<button
			type="button"
			onClick={onClick}
			style={{
				width: '100%',
				display: 'flex',
				alignItems: 'center',
				gap: '10px',
				padding: '9px 10px',
				borderRadius: '10px',
				border: 'none',
				background: active ? 'rgba(255,154,60,0.12)' : 'transparent',
				color: active ? 'var(--accent-orange)' : 'var(--text-muted)',
				cursor: 'pointer',
				fontSize: '13px',
				fontFamily: 'inherit',
				fontWeight: 500,
				textAlign: 'left',
				transition: 'background 0.2s, color 0.2s',
			}}
			onMouseEnter={(e) => { e.currentTarget.style.background = 'rgba(255,255,255,0.05)'; e.currentTarget.style.color = 'white'; }}
			onMouseLeave={(e) => { e.currentTarget.style.background = active ? 'rgba(255,154,60,0.12)' : 'transparent'; e.currentTarget.style.color = active ? 'var(--accent-orange)' : 'var(--text-muted)'; }}
		>
			{icon}
			{label}
		</button>
	);
}