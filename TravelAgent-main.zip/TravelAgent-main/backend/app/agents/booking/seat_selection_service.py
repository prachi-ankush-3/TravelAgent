"""Seat optimization service for intelligent seat recommendation."""
from __future__ import annotations

from typing import Any, Dict, List


def _as_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    return str(value).strip().lower() in {"1", "true", "yes", "y"}


def _normalize_seats(layout: Dict[str, Any]) -> List[Dict[str, Any]]:
    seats = layout.get("seats") or layout.get("seat_map") or []
    if not isinstance(seats, list):
        return []
    normalized: List[Dict[str, Any]] = []
    for seat in seats:
        if not isinstance(seat, dict):
            continue
        record = dict(seat)
        record["seat_no"] = str(seat.get("seat_no") or seat.get("id") or "")
        record["is_available"] = bool(seat.get("is_available", seat.get("available", False)))
        record["is_window"] = _as_bool(seat.get("is_window", seat.get("window")))
        record["is_sleeper"] = _as_bool(seat.get("is_sleeper", seat.get("sleeper")))
        record["is_back"] = _as_bool(seat.get("is_back", seat.get("back")))
        record["is_lower"] = _as_bool(seat.get("is_lower", seat.get("lower")))
        normalized.append(record)
    return normalized


def select_best_seat(layout: Dict[str, Any], preferences: Dict[str, Any] | None = None) -> Dict[str, Any] | None:
    """Select best available seat using user preference-aware scoring."""
    preferences = preferences or {}
    seats = [seat for seat in _normalize_seats(layout) if seat.get("is_available")]
    if not seats:
        return None

    wants_window = _as_bool(preferences.get("window_seat"))
    wants_sleeper = _as_bool(preferences.get("sleeper"))
    motion_sickness = _as_bool(preferences.get("motion_sickness"))
    elderly = _as_bool(preferences.get("elderly"))
    peaceful_sleep = _as_bool(preferences.get("peaceful_sleep"))

    def seat_score(seat: Dict[str, Any]) -> float:
        score = 0.0
        if seat.get("is_window"):
            score += 1.0 if wants_window else 0.3
        if seat.get("is_sleeper"):
            score += 1.0 if wants_sleeper else 0.2
        if seat.get("is_lower"):
            if elderly or peaceful_sleep:
                score += 0.9
            else:
                score += 0.2
        if seat.get("is_back"):
            score -= 0.9 if motion_sickness else 0.2

        seat_number = str(seat.get("seat_no", ""))
        if seat_number.startswith("L"):
            score += 0.2
        if "window" in str(seat.get("tags", "")).lower():
            score += 0.2
        return score

    ranked = sorted(seats, key=seat_score, reverse=True)
    best = dict(ranked[0])
    best["seat_score"] = round(seat_score(best), 4)
    return best
