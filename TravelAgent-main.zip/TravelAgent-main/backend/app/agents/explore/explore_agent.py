"""ExploreAgent — orchestrates fetching, filtering, ranking places and updating state.

Usage:
    from app.agents.explore.explore_agent import ExploreAgent
    agent = ExploreAgent()
    result = agent.run(session_id)

`run` will read the GlobalTravelState for `session_id`, fetch places for the
destination, apply filters and ranking, update the state with `suggested_places`
and mark the explore stage done.
"""
from __future__ import annotations
from typing import Dict, Any, List

from app.state.session_manager import session_manager
from app.state.memory_handler import update_state, mark_stage_done
from app.services.explore_service import get_places
from app.agents.explore.explore_filters import (
    filter_by_budget,
    filter_family_friendly,
    filter_by_interests,
    filter_by_duration,
)
from app.agents.explore.explore_ranker import rank_places


class ExploreAgent:
    def __init__(self) -> None:
        pass

    def _infer_budget_level(self, budget_field: Any) -> str | None:
        # budget_field may be a dict with total_budget or a numeric total
        try:
            if isinstance(budget_field, dict):
                total = budget_field.get("total_budget")
            else:
                total = budget_field
            if total is None:
                return None
            total = float(total)
            if total <= 3000:
                return "low"
            if total <= 15000:
                return "medium"
            return "high"
        except Exception:
            return None

    def run(self, session_id: str) -> Dict[str, Any]:
        state = session_manager.get_or_create(session_id)

        destination = getattr(state, "destination", None)
        budget_field = getattr(state, "budget", None)
        travel_style = getattr(state, "travel_style", None)
        duration_days = getattr(state, "duration_days", None)
        interests = getattr(state, "interests", []) or []
        num_travelers = getattr(state, "num_travelers", None)

        # Basic guards
        if not destination:
            return {"error": "missing_destination"}

        # Fetch places
        places = get_places(destination)

        # Infer budget level
        budget_level = self._infer_budget_level(budget_field)

        # Apply filters
        candidates = places
        candidates = filter_by_budget(candidates, budget_level)
        # family filter: if any traveler is child-like info isn't available;
        # infer from travel_style keywords
        needs_family = False
        if isinstance(num_travelers, int) and num_travelers > 0:
            # no explicit children info - skip
            needs_family = False
        if travel_style and "family" in (str(travel_style).lower()):
            needs_family = True
        candidates = filter_family_friendly(candidates, needs_family)
        candidates = filter_by_interests(candidates, interests)
        candidates = filter_by_duration(candidates, duration_days)

        # Rank
        ranked = rank_places(candidates, budget_level or "", interests)

        # Prepare a compact recommendation list
        recommendations: List[Dict[str, Any]] = [
            {
                "name": p.get("name"),
                "category": p.get("category"),
                "rating": p.get("rating"),
                "estimated_cost": p.get("estimated_cost"),
                "score": p.get("score"),
            }
            for p in ranked
        ]

        # Update state. Keep both keys during transition so old and new
        # consumers can read recommendations.
        update_state(
            session_id,
            {
                "suggested_places": recommendations,
                "suggested_activities": recommendations,
            },
        )
        mark_stage_done(session_id, "explore")

        return {"recommended": recommendations}


def run_for_session(session_id: str) -> Dict[str, Any]:
    return ExploreAgent().run(session_id)
