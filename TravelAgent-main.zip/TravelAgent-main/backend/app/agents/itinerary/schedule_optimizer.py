"""Optimization layer for itinerary ordering and slot assignment."""
from __future__ import annotations

from typing import Any, Dict, Iterable, List


from app.agents.itinerary.itinerary_rules import (
    DEFAULT_SLOT_ORDER,
    best_time_for,
    category_family,
    normalize_category,
    hotel_nearby_tokens,
)


def prioritize_places(
    places: List[Dict[str, Any]],
    selected_hotel: Dict[str, Any] | None = None,
    interests: Iterable[str] | None = None,
) -> List[Dict[str, Any]]:
    """Sort places by rating, hotel proximity, and interest overlap."""
    hotel_tokens = hotel_nearby_tokens(selected_hotel)
    interest_tokens = {str(item).strip().lower() for item in (interests or []) if item}

    def score(place: Dict[str, Any]) -> tuple[float, float, float, str]:
        rating = float(place.get("rating") or 0)
        category = normalize_category(place)
        name_blob = " ".join(
            str(place.get(key, "")).lower() for key in ("name", "location", "category")
        )

        hotel_distance_score = 0.0
        hotel_coordinates = selected_hotel.get("coordinates") if selected_hotel else None
        place_coordinates = place.get("coordinates")
        if isinstance(hotel_coordinates, dict) and isinstance(place_coordinates, dict):
            try:
                from app.utils.distance_utils import calculate_distance

                distance = calculate_distance(
                    {"coordinates": hotel_coordinates},
                    {"coordinates": place_coordinates},
                )
                if distance != float("inf"):
                    hotel_distance_score = max(0.0, 1.0 - min(distance, 30.0) / 30.0)
            except Exception:
                hotel_distance_score = 0.0

        proximity_score = 1.0 if any(token and token in name_blob for token in hotel_tokens) else 0.0
        interest_score = 0.0
        if category in interest_tokens:
            interest_score += 1.0
        if any(token in name_blob for token in interest_tokens):
            interest_score += 0.5

        return (rating, hotel_distance_score + proximity_score, interest_score, str(place.get("name", "")))

    return sorted(places, key=score, reverse=True)


def choose_time_slot(place: Dict[str, Any], used_slots: set[str]) -> str:
    """Pick the best available time slot for a place."""
    preferred = best_time_for(place)
    if preferred not in used_slots:
        return preferred

    for slot in DEFAULT_SLOT_ORDER:
        if slot not in used_slots:
            return slot

    return "Night" if preferred == "Night" else DEFAULT_SLOT_ORDER[-1]


def optimize_day_schedule(day_plan: Dict[str, Any]) -> Dict[str, Any]:
    """Reorder activities inside a day to follow Morning → Afternoon → Evening."""
    slot_order = {slot: index for index, slot in enumerate(DEFAULT_SLOT_ORDER + ["Night"])}
    activities = list(day_plan.get("activities", []))
    activities.sort(key=lambda item: slot_order.get(item.get("slot", "Afternoon"), 99))
    day_plan["activities"] = activities

    for slot in DEFAULT_SLOT_ORDER + ["Night"]:
        day_plan[slot] = []

    for activity in activities:
        slot = activity.get("slot", "Afternoon")
        day_plan.setdefault(slot, []).append(activity.get("name"))

    return day_plan


def rebalance_days(days: List[Dict[str, Any]], max_activities_per_day: int) -> List[Dict[str, Any]]:
    """Trim overloaded days by moving overflow into later days when possible."""
    if max_activities_per_day <= 0:
        return days

    carry: List[Dict[str, Any]] = []
    rebalanced: List[Dict[str, Any]] = []

    for day_plan in days:
        current = list(day_plan.get("activities", []))
        current = carry + current
        carry = []

        if len(current) > max_activities_per_day:
            carry = current[max_activities_per_day:]
            current = current[:max_activities_per_day]

        day_plan["activities"] = current
        rebalanced.append(day_plan)

    if carry and rebalanced:
        rebalanced[-1]["activities"].extend(carry)

    return rebalanced