import React from 'react';
import { motion } from 'framer-motion';
import { Bus, BrainCircuit, CheckCircle2, QrCode } from 'lucide-react';

export default function TicketPage() {
  return (
    <div className="layout-container auth-bg-image" style={{ position: 'relative', justifyContent: 'center', alignItems: 'center' }}>
      <div className="orb orb-orange" style={{ top: '10%', left: '20%', width: '400px', height: '400px' }} />
      <div className="orb orb-blue" style={{ bottom: '15%', right: '10%', width: '300px', height: '300px' }} />
      
      <div style={{ width: '100%', maxWidth: '800px', zIndex: 10, textAlign: 'center', marginBottom: '24px' }}>
        <h1 style={{ fontSize: '32px', fontWeight: 700, color: 'white' }}>Your Journey is Ready ✨</h1>
      </div>

      <motion.div 
        className="glass-panel"
        style={{ width: '100%', maxWidth: '800px', zIndex: 10, display: 'flex', overflow: 'hidden', background: 'rgba(255,255,255,0.02)' }}
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
      >
        {/* Left Side: Ticket Details */}
        <div style={{ flex: 1, padding: '40px', borderRight: '2px dashed rgba(255,255,255,0.1)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '40px' }}>
            <h2 style={{ fontSize: '24px', fontWeight: 700, color: 'white', display: 'flex', alignItems: 'center', gap: '12px' }}>
              <Bus size={28} color="var(--accent-orange)" />
              VRL Travels
            </h2>
            <div style={{ padding: '6px 12px', background: 'rgba(16, 185, 129, 0.1)', color: '#10B981', borderRadius: '20px', fontSize: '14px', fontWeight: 600, border: '1px solid rgba(16, 185, 129, 0.2)' }}>
              Confirmed
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '40px' }}>
            <div>
              <div style={{ fontSize: '36px', fontWeight: 700, color: 'var(--accent-orange)' }}>22:30</div>
              <div style={{ fontSize: '16px', color: 'white', fontWeight: 600 }}>Pune</div>
              <div style={{ fontSize: '14px', color: 'var(--text-muted)' }}>Swargate</div>
            </div>
            
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', flex: 1, padding: '0 24px' }}>
              <div style={{ fontSize: '12px', color: 'var(--text-muted)', marginBottom: '8px' }}>6h 30m</div>
              <div style={{ width: '100%', height: '2px', background: 'var(--glass-border)', position: 'relative' }}>
                 <div style={{ position: 'absolute', top: '-4px', left: '50%', transform: 'translateX(-50%)' }}>
                   <Bus size={12} color="var(--accent-orange)" />
                 </div>
              </div>
              <div style={{ fontSize: '12px', color: 'var(--text-muted)', marginTop: '8px' }}>Direct</div>
            </div>

            <div style={{ textAlign: 'right' }}>
              <div style={{ fontSize: '36px', fontWeight: 700, color: 'var(--accent-orange)' }}>05:00</div>
              <div style={{ fontSize: '16px', color: 'white', fontWeight: 600 }}>Mumbai</div>
              <div style={{ fontSize: '14px', color: 'var(--text-muted)' }}>Dadar</div>
            </div>
          </div>

          <div style={{ display: 'flex', gap: '40px', borderTop: '1px solid var(--glass-border)', paddingTop: '24px' }}>
            <div>
              <div style={{ fontSize: '12px', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Passenger</div>
              <div style={{ fontSize: '16px', color: 'white', fontWeight: 600 }}>John Doe</div>
            </div>
            <div>
              <div style={{ fontSize: '12px', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Seat</div>
              <div style={{ fontSize: '16px', color: 'white', fontWeight: 600 }}>A1 (Window/Sleeper)</div>
            </div>
            <div>
              <div style={{ fontSize: '12px', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Class</div>
              <div style={{ fontSize: '16px', color: 'white', fontWeight: 600 }}>AC Sleeper</div>
            </div>
          </div>
        </div>

        {/* Right Side: QR & AI Note */}
        <div style={{ width: '280px', padding: '40px 32px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: 'rgba(0,0,0,0.2)' }}>
          <div style={{ fontSize: '14px', color: 'var(--text-muted)', marginBottom: '8px' }}>Booking ID</div>
          <div style={{ fontSize: '20px', color: 'white', fontWeight: 700, letterSpacing: '2px', marginBottom: '32px' }}>TRV-98234-A1</div>
          
          <div style={{ padding: '16px', background: 'white', borderRadius: '12px', marginBottom: '32px' }}>
             <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=TRV-98234-A1" alt="QR Code" style={{ display: 'block', width: '150px', height: '150px' }} />
          </div>
          
          <div style={{ background: 'rgba(255,106,0,0.1)', border: '1px solid var(--accent-orange-glow)', borderRadius: '12px', padding: '16px', width: '100%', display: 'flex', gap: '12px', alignItems: 'flex-start' }}>
             <BrainCircuit size={20} color="var(--accent-orange)" style={{ flexShrink: 0 }} />
             <div>
               <div style={{ fontSize: '12px', fontWeight: 600, color: 'var(--accent-orange)', marginBottom: '4px' }}>AI Optimized</div>
               <div style={{ fontSize: '11px', color: 'var(--text-muted)' }}>Optimized for comfort and budget by TravAgent AI.</div>
             </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
