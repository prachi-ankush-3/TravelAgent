import React, { useEffect, useMemo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, ChevronRight, MessageCircleHeart, Check, Shuffle, ChevronDown, ChevronUp, AlertCircle } from 'lucide-react';
import { getBookingMemory, saveBookingMemory } from '../../services/bookingMemory';
import { updateCurrentProfile } from '../../services/authService';

function normalizeSeatLayout(layout) {
	const seats = layout?.seats || layout?.seat_map || [];
	if (Array.isArray(seats) && seats.length > 0) {
		return seats;
	}
	return [
		[{ seat_no: 'A1', is_available: true, is_window: true }, { seat_no: 'A2', is_available: true }, null, { seat_no: 'A3', is_available: false }, { seat_no: 'A4', is_available: true, is_window: true }],
		[{ seat_no: 'B1', is_available: true }, { seat_no: 'B2', is_available: true, is_lower: true }, null, { seat_no: 'B3', is_available: false }, { seat_no: 'B4', is_available: true }],
	];
}

function seatLabel(seat) {
	return seat?.seat_no || seat?.id || '';
}

function inferSeatPreferenceLabel(pref) {
	const value = String(pref || '').toLowerCase();
	if (value.includes('window')) return 'window';
	if (value.includes('sleeper')) return 'sleeper';
	if (value.includes('front')) return 'front';
	if (value.includes('lower')) return 'lower';
	return '';
}

function chooseSeatForPreference(rows, preferenceLabel, fallbackSeatNo = '') {
	const flattened = [];
	rows.forEach((row, rowIndex) => {
		row.forEach((seat, seatIndex) => {
			if (!seat) return;
			flattened.push({ seat, rowIndex, seatIndex });
		});
	});
	const available = flattened.filter(({ seat }) => seat.is_available !== false);
	if (!available.length) return { seatNo: fallbackSeatNo, reason: 'No seats are available right now.' };

	const matching = available.filter(({ seat, rowIndex }) => {
		if (preferenceLabel === 'window') return Boolean(seat.is_window);
		if (preferenceLabel === 'sleeper') return Boolean(seat.is_sleeper);
		if (preferenceLabel === 'lower') return Boolean(seat.is_lower);
		if (preferenceLabel === 'front') return rowIndex === 0;
		return false;
	});

	const candidate = matching[0] || available[0];
	if (!candidate) return { seatNo: fallbackSeatNo, reason: 'I could not resolve a matching seat.' };

	if (matching.length > 0) {
		return { seatNo: seatLabel(candidate.seat), reason: `Matched your ${preferenceLabel} preference.` };
	}

	if (preferenceLabel === 'window') {
		return { seatNo: seatLabel(candidate.seat), reason: `Window seats are unavailable on this bus, so I picked the closest available seat.` };
	}

	return { seatNo: seatLabel(candidate.seat), reason: `I picked the closest available seat.` };
}

/**
 * SeatRecommendation — fully automated passenger flow.
 *
 * Props:
 *   bus             — the selected bus object
 *   data            — seat stage data from the AI
 *   seatLayout      — layout from /seat-layout/:bus_ref
 *   seatRecommendation — { seat_no, reason } from the AI
 *   loading         — loading state from parent
 *   selectedSeatNo  — currently highlighted seat
 *   passengerName   — name fetched from DB profile (shown as confirmation)
 *   missingFields   — array of missing profile fields (e.g. ['age', 'phone'])
 *   needsPreference — whether to show preference selection first
 *   onSeatSelect(seatNo) — called when the user confirms a seat
 *   onPreferenceChosen(label) — called when user picks a preference pill
 */
export default function SeatRecommendation({
	bus,
	data,
	seatLayout,
	seatRecommendation,
	loading = false,
	selectedSeatNo = '',
	passengerName = '',
	missingFields = [],
	onSeatSelect,
	onPreferenceChosen,
	needsPreference = false,
}) {
	const [highlightedSeat, setHighlightedSeat] = useState(selectedSeatNo || seatRecommendation?.seat_no || '');
	const [memory, setMemory] = useState({});
	const [preferenceChoice, setPreferenceChoice] = useState('');
	const [conversationNote, setConversationNote] = useState('');
	const [awaitingConfirmation, setAwaitingConfirmation] = useState(false);
	const [showSeatMap, setShowSeatMap] = useState(false);

	const rows = useMemo(() => {
		const layoutRows = normalizeSeatLayout(seatLayout);
		if (Array.isArray(layoutRows[0])) return layoutRows;
		const items = layoutRows;
		const grouped = [];
		for (let i = 0; i < items.length; i += 5) {
			grouped.push(items.slice(i, i + 5));
		}
		return grouped;
	}, [seatLayout]);

	useEffect(() => {
		const bm = getBookingMemory() || {};
		setMemory(bm);
	}, []);

	const inferredMemoryPreference = inferSeatPreferenceLabel(memory.seat_preference);
	const chosenPreference = inferSeatPreferenceLabel(preferenceChoice) || inferredMemoryPreference;
	const seatReason = conversationNote || seatRecommendation?.reason || data?.message || 'The AI is picking the smoothest seat for your trip profile.';

	useEffect(() => {
		if (!chosenPreference) {
			setHighlightedSeat(selectedSeatNo || seatRecommendation?.seat_no || '');
			setAwaitingConfirmation(false);
			return;
		}

		const picked = chooseSeatForPreference(rows, chosenPreference, selectedSeatNo || seatRecommendation?.seat_no || '');
		setHighlightedSeat(picked.seatNo);
		setConversationNote(
			memory.seat_preference
				? `You usually prefer ${chosenPreference} seats. ${picked.seatNo ? `I found seat ${picked.seatNo}.` : ''} Should I continue with that?`
				: `Got it. I'll prioritize ${chosenPreference} seats for future journeys too.`
		);
		setAwaitingConfirmation(true);
	}, [chosenPreference, rows, memory.seat_preference, seatRecommendation?.seat_no, selectedSeatNo]);

	const handleSeatClick = (seat) => {
		const no = seatLabel(seat);
		if (!no || seat?.is_available === false) return;
		setHighlightedSeat(no);
	};

	const handlePreferencePick = (label) => {
		const normalized = inferSeatPreferenceLabel(label);
		if (!normalized) return;
		const nextMemory = saveBookingMemory({
			...memory,
			seat_preference: normalized,
			preferred_bus_type: memory.preferred_bus_type || bus?.bus_type || bus?.type || '',
			preferred_operator: memory.preferred_operator || bus?.operator || bus?.operator_name || '',
		});
		setMemory(nextMemory);
		setPreferenceChoice(normalized);
		setConversationNote(`Got it. I'll prioritize ${normalized} seats for future journeys too.`);
		setAwaitingConfirmation(true);
		onPreferenceChosen?.(normalized);
		updateCurrentProfile({
			booking_preferences: { ...nextMemory, seat_preference: normalized },
		}).catch(() => {});
	};

	const handleUseDifferentSeat = () => {
		saveBookingMemory({ ...memory, seat_preference: preferenceChoice || memory.seat_preference || '' });
		setConversationNote("No problem. Pick any seat on the map and I'll continue from there.");
		setAwaitingConfirmation(false);
	};

	/** "Yes, Proceed" — confirm the highlighted seat and trigger direct booking */
	const handleConfirm = () => {
		if (!highlightedSeat || loading) return;
		onSeatSelect?.(highlightedSeat);
	};

	const promptOptions = ['window', 'sleeper', 'front', 'lower'];
	const hasMemory = Boolean(inferredMemoryPreference);
	const profileReady = missingFields.length === 0;

	return (
		<motion.div
			initial={{ opacity: 0, y: 12 }}
			animate={{ opacity: 1, y: 0 }}
			style={{ padding: '18px', borderRadius: '24px', background: 'linear-gradient(180deg, rgba(255,255,255,0.04), rgba(255,255,255,0.02))', border: '1px solid rgba(255,255,255,0.06)' }}
		>
			{/* Header row */}
			<div style={{ display: 'flex', justifyContent: 'space-between', gap: '12px', flexWrap: 'wrap' }}>
				<div>
					<div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--accent-orange)', fontSize: '11px', fontWeight: 800, textTransform: 'uppercase', letterSpacing: '0.1em' }}>
						<MessageCircleHeart size={12} /> Seat recommendation
					</div>
					<div style={{ marginTop: '6px', color: 'white', fontSize: '18px', fontWeight: 800 }}>{bus?.operator || 'Selected bus'}</div>
					<div style={{ marginTop: '4px', color: 'var(--text-muted)', fontSize: '13px' }}>
						{seatRecommendation?.seat_no ? `Recommended seat ${seatRecommendation.seat_no}` : "I'll learn your seat preference conversationally, then continue with the best match."}
					</div>
				</div>
				<div style={{ alignSelf: 'center', padding: '10px 14px', borderRadius: '16px', background: 'rgba(255,106,0,0.12)', color: 'white', fontSize: '13px', display: 'flex', alignItems: 'center', gap: '8px' }}>
					<Check size={14} /> {hasMemory ? 'Memory-aware seat stage' : 'Learning your preference'}
				</div>
			</div>

			{/* AI conversation note */}
			<div style={{ marginTop: '14px', padding: '14px 16px', borderRadius: '18px', background: 'rgba(255,106,0,0.08)', border: '1px solid rgba(255,106,0,0.18)', color: 'white', fontSize: '14px', lineHeight: 1.6 }}>
				{memory.seat_preference
					? `You usually prefer ${inferredMemoryPreference} seats. ${highlightedSeat ? `I found seat ${highlightedSeat}.` : ''} Should I continue with that?`
					: 'Do you have any seating preference like window, sleeper, front, or lower berth?'}
			</div>

			{/* Preference pills */}
			{!chosenPreference && (
				<div style={{ marginTop: '12px', display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
					{promptOptions.map((option) => (
						<button key={option} onClick={() => handlePreferencePick(option)} style={{ padding: '10px 12px', borderRadius: '999px', border: '1px solid rgba(255,255,255,0.08)', background: 'rgba(255,255,255,0.04)', color: 'white', cursor: 'pointer', fontWeight: 700, textTransform: 'capitalize' }}>
							{option}
						</button>
					))}
					<button onClick={handleUseDifferentSeat} style={{ padding: '10px 12px', borderRadius: '999px', border: '1px solid rgba(255,255,255,0.08)', background: 'transparent', color: 'var(--text-muted)', cursor: 'pointer', fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
						<Shuffle size={14} /> Pick anything
					</button>
				</div>
			)}

			{/* Toggle seat map */}
			<div style={{ marginTop: '12px', display: 'flex', justifyContent: 'flex-end' }}>
				<button onClick={() => setShowSeatMap((prev) => !prev)} style={{ padding: '10px 12px', borderRadius: '12px', border: '1px solid rgba(255,255,255,0.08)', background: 'rgba(255,255,255,0.03)', color: 'white', cursor: 'pointer', fontWeight: 700, display: 'inline-flex', alignItems: 'center', gap: '8px' }}>
					{showSeatMap ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
					{showSeatMap ? 'Hide seat map' : 'View seat map'}
				</button>
			</div>

			{/* Seat map + action panel */}
			<AnimatePresence>
				{showSeatMap && (
					<motion.div
						initial={{ opacity: 0, y: 8 }}
						animate={{ opacity: 1, y: 0 }}
						exit={{ opacity: 0, y: 8 }}
						style={{ marginTop: '16px', display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) 300px', gap: '16px', alignItems: 'start' }}
					>
						{/* Seat grid */}
						<div style={{ padding: '16px', borderRadius: '20px', background: 'rgba(0,0,0,0.24)', border: '1px solid rgba(255,255,255,0.06)' }}>
							<div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
								<div style={{ color: 'white', fontWeight: 700 }}>Seat map</div>
								<div style={{ color: 'var(--text-muted)', fontSize: '12px' }}>Driver at the front</div>
							</div>
							<div style={{ display: 'flex', flexDirection: 'column', gap: '12px', alignItems: 'center' }}>
								<div style={{ alignSelf: 'flex-end', padding: '8px 14px', borderRadius: '10px', border: '1px solid rgba(255,255,255,0.06)', color: 'var(--text-muted)', fontSize: '12px' }}>Driver</div>
								{rows.map((row, rowIndex) => (
									<div key={rowIndex} style={{ display: 'flex', gap: '10px' }}>
										{row.map((seat, seatIndex) => {
											if (!seat) return <div key={seatIndex} style={{ width: '40px' }} />;
											const seatNo = seatLabel(seat);
											const isAvailable = seat.is_available !== false;
											const isHighlighted = highlightedSeat === seatNo || seatRecommendation?.seat_no === seatNo;
											const background = isHighlighted ? 'linear-gradient(135deg, #ff9a3c, #ff6a00)' : isAvailable ? 'rgba(16,185,129,0.88)' : 'rgba(75,85,99,0.88)';
											return (
												<button key={seatNo || seatIndex} onClick={() => handleSeatClick(seat)} disabled={!isAvailable || loading} style={{ width: '44px', height: '44px', borderRadius: '12px', border: isHighlighted ? '2px solid rgba(255,255,255,0.7)' : 'none', background, cursor: isAvailable ? 'pointer' : 'not-allowed', color: isHighlighted ? 'black' : 'white', fontWeight: 800, fontSize: '11px', position: 'relative' }}>
													{seat.is_window && <Sparkles size={11} style={{ position: 'absolute', top: '-6px', right: '-6px', color: 'white' }} />}
													{seatNo}
												</button>
											);
										})}
									</div>
								))}
							</div>
						</div>

						{/* Right column: AI reasoning + confirm actions */}
						<div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
							{/* AI reasoning */}
							<div style={{ padding: '16px', borderRadius: '20px', background: 'rgba(255,106,0,0.09)', border: '1px solid rgba(255,106,0,0.16)', color: 'white' }}>
								<div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--accent-orange)', fontWeight: 700, marginBottom: '10px' }}>
									<Sparkles size={14} /> AI reasoning
								</div>
								<div style={{ fontSize: '13px', lineHeight: 1.6, color: 'white' }}>{seatReason}</div>
							</div>

							{/* Passenger info (auto-filled from DB) */}
							{passengerName && (
								<div style={{ padding: '12px 14px', borderRadius: '16px', background: 'rgba(16,185,129,0.08)', border: '1px solid rgba(16,185,129,0.2)', display: 'flex', alignItems: 'center', gap: '8px' }}>
									<Check size={14} color="#10B981" />
									<div style={{ fontSize: '13px', color: '#10B981' }}>
										Booking as <strong>{passengerName}</strong>
									</div>
								</div>
							)}

							{/* Missing profile warning */}
							{missingFields.length > 0 && (
								<div style={{ padding: '12px 14px', borderRadius: '16px', background: 'rgba(251,191,36,0.08)', border: '1px solid rgba(251,191,36,0.22)', display: 'flex', alignItems: 'flex-start', gap: '8px' }}>
									<AlertCircle size={14} color="#fbbf24" style={{ flexShrink: 0, marginTop: 2 }} />
									<div style={{ fontSize: '12px', color: '#fbbf24', lineHeight: 1.5 }}>
										Profile incomplete: <strong>{missingFields.join(', ')}</strong>. <a href="/profile" style={{ color: '#fbbf24', textDecoration: 'underline' }}>Update profile</a> to book.
									</div>
								</div>
							)}

							{/* Selected seat + CTA buttons */}
							<div style={{ padding: '16px', borderRadius: '20px', background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}>
								<div style={{ color: 'white', fontWeight: 700 }}>Selected seat</div>
								<div style={{ marginTop: '8px', color: 'var(--text-muted)', fontSize: '13px' }}>
									{highlightedSeat || seatRecommendation?.seat_no || 'Pick a seat to continue'}
								</div>
								<div style={{ marginTop: '8px', color: 'var(--text-muted)', fontSize: '12px', lineHeight: 1.5 }}>{seatReason}</div>

								<div style={{ marginTop: '14px', display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
									{/* Primary CTA: Yes, Proceed — triggers direct /book-ticket call */}
									<button
										type="button"
										onClick={handleConfirm}
										disabled={!highlightedSeat || loading}
										title={!profileReady ? `Complete your profile to book (missing: ${missingFields.join(', ')})` : ''}
										style={{
											padding: '12px 14px', borderRadius: '14px', border: 'none',
											background: profileReady ? 'linear-gradient(135deg, #ffb84d, #ff6a00)' : 'rgba(255,255,255,0.08)',
											color: profileReady ? 'black' : 'var(--text-muted)',
											fontWeight: 800,
											cursor: (!highlightedSeat || loading) ? 'not-allowed' : 'pointer',
											display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
											transition: 'background 0.2s',
										}}
									>
										{loading ? 'Booking…' : 'Yes, Proceed'} {!loading && <ChevronRight size={16} />}
									</button>

									{/* Secondary CTA: Show Others */}
									<button
										type="button"
										onClick={handleUseDifferentSeat}
										disabled={loading}
										style={{ padding: '12px 14px', borderRadius: '14px', border: '1px solid rgba(255,255,255,0.08)', background: 'transparent', color: 'white', fontWeight: 700, cursor: 'pointer' }}
									>
										Show Others
									</button>
								</div>
							</div>
						</div>
					</motion.div>
				)}
			</AnimatePresence>

			{/* Quick confirm when seat map is hidden but seat is selected */}
			{!showSeatMap && highlightedSeat && (
				<div style={{ marginTop: '14px', display: 'flex', gap: '10px', alignItems: 'center' }}>
					<button
						type="button"
						onClick={handleConfirm}
						disabled={loading}
						style={{
							padding: '11px 18px', borderRadius: '12px', border: 'none',
							background: profileReady ? 'linear-gradient(135deg, #ffb84d, #ff6a00)' : 'rgba(255,255,255,0.08)',
							color: profileReady ? 'black' : 'var(--text-muted)',
							fontWeight: 800, cursor: loading ? 'not-allowed' : 'pointer',
							display: 'inline-flex', alignItems: 'center', gap: '8px',
						}}
					>
						{loading ? 'Booking…' : <>Yes, Proceed <ChevronRight size={15} /></>}
					</button>
					<button
						type="button"
						onClick={handleUseDifferentSeat}
						disabled={loading}
						style={{ padding: '11px 16px', borderRadius: '12px', border: '1px solid rgba(255,255,255,0.08)', background: 'transparent', color: 'white', fontWeight: 700, cursor: 'pointer' }}
					>
						Show Others
					</button>
					{passengerName && (
						<span style={{ fontSize: '12px', color: '#10B981', display: 'flex', alignItems: 'center', gap: '4px' }}>
							<Check size={13} /> Booking as {passengerName}
						</span>
					)}
				</div>
			)}
		</motion.div>
	);
}
