"""Provider abstraction for external bus booking APIs.

All booking HTTP communication is isolated in this module so the booking
agent remains provider-agnostic.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

import httpx
import uuid
from datetime import datetime, timedelta


class BusProvider:
    """HTTP adapter for bus booking endpoints."""

    def __init__(self, base_url: str = "http://localhost:9000", timeout: float = 15.0) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        url = f"{self.base_url}{path}"
        try:
            with httpx.Client(timeout=self.timeout) as client:
                response = client.request(method, url, **kwargs)
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as exc:
            raise RuntimeError(f"Provider HTTP {exc.response.status_code} for {method} {path} - {exc.response.text}") from exc
        except httpx.HTTPError as exc:
            raise RuntimeError(f"Provider communication failed for {method} {path}: {exc}") from exc

    def search_buses(
        self,
        source: str,
        destination: str,
        date: str,
        ac_only: bool = False,
        sleeper_only: bool = False,
        min_rating: float = 1.0,
        sort_by: str = "price_min",
        order: str = "asc",
        limit: int = 10,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        params = {
            "source": source,
            "destination": destination,
            "date": date,
            "ac_only": ac_only,
            "sleeper_only": sleeper_only,
            "min_rating": min_rating,
            "sort_by": sort_by,
            "order": order,
            "limit": limit,
            "offset": offset,
        }
        payload = self._request("GET", "/buses", params=params)
        if isinstance(payload, dict):
            return payload.get("items") or payload.get("buses") or payload.get("data") or []
        if isinstance(payload, list):
            return payload
        return []

    def get_seat_layout(self, bus_id: str) -> Dict[str, Any]:
        payload = self._request("GET", f"/seat-layout/{bus_id}")
        return payload if isinstance(payload, dict) else {"seats": payload}

    def book_ticket(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        result = self._request("POST", "/book-ticket", json=payload)
        return result if isinstance(result, dict) else {"result": result}

    def cancel_booking(self, booking_id: str) -> Dict[str, Any]:
        result = self._request("POST", f"/cancel-booking/{booking_id}")
        return result if isinstance(result, dict) else {"result": result}

    def get_booking(self, booking_id: str) -> Dict[str, Any]:
        result = self._request("GET", f"/booking/{booking_id}")
        return result if isinstance(result, dict) else {"result": result}


def create_bus_provider(base_url: Optional[str] = None) -> BusProvider:
    """Factory to support future provider selection/configuration."""
    from app.core.config import BOOKING_PROVIDER_BASE_URL
    target = base_url or BOOKING_PROVIDER_BASE_URL or "http://localhost:9000"
    
    # We always return the real BusProvider now, so it hits the actual API
    # instead of intercepting and returning hardcoded mock data.
    return BusProvider(base_url=target)
