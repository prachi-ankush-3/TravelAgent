"""Validation helpers for booking workflow inputs."""
from __future__ import annotations

from typing import Any, Dict, Tuple


def validate_intent(intent: Dict[str, Any]) -> Tuple[bool, str | None]:
    source = str(intent.get("source") or "").strip()
    destination = str(intent.get("destination") or "").strip()
    travel_date = str(intent.get("travel_date") or "").strip()

    if not source:
        return False, "missing_source"
    if not destination:
        return False, "missing_destination"
    if source.lower() == destination.lower():
        return False, "source_destination_same"
    if len(travel_date) < 10:
        return False, "invalid_travel_date"
    return True, None


def validate_passenger_details(details: Dict[str, Any]) -> Tuple[bool, str | None]:
    if not isinstance(details, dict):
        return False, "invalid_passenger_details"

    required = [
        "passenger_name",
        "passenger_age",
        "passenger_gender",
        "phone_number",
    ]
    for key in required:
        if not details.get(key):
            return False, f"missing_{key}"

    try:
        age = int(details.get("passenger_age"))
    except (TypeError, ValueError):
        return False, "invalid_passenger_age"
    if age <= 0:
        return False, "invalid_passenger_age"

    phone = str(details.get("phone_number"))
    if len(phone) < 10 or not phone.isdigit():
        return False, "invalid_phone_number"

    return True, None
