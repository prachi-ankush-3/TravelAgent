# app/state/memory_handler.py
# MemoryHandler — thin helper layer between agents and GlobalTravelState.
#
# Agents should call these functions instead of touching the state directly.
# This keeps agent code clean and makes future changes (e.g. adding persistence)
# easy — you only update this file.

from __future__ import annotations
from typing import Any, Dict, Optional

from app.core.logger import get_logger
from app.state.session_manager import session_manager
from app.state.global_state import GlobalTravelState

log = get_logger(__name__)


# ── Write helpers ──────────────────────────────────────────────────────────────

def update_state(session_id: str, data: Dict[str, Any]) -> None:
    """
    Bulk-write a dict of fields into the session state.
    Typically called right after LLM extraction:

        update_state(sid, {"destination": "Goa", "duration_days": 4})
    """
    state = _get(session_id)
    state.update(data)
    log.debug(f"[MemoryHandler] update_state → {list(data.keys())}")


def set_field(session_id: str, field: str, value: Any) -> None:
    """Set a single field on the state."""
    state = _get(session_id)
    setattr(state, field, value)
    log.debug(f"[MemoryHandler] set_field {field}={value!r}")


def mark_stage_done(session_id: str, stage: str) -> None:
    """
    Mark a pipeline stage as complete.
    stage ∈ {'extraction', 'budget', 'hotel', 'explore', 'plan'}
    """
    state = _get(session_id)
    state.mark_done(stage)


def record_llm_output(session_id: str, agent_name: str, raw: Dict[str, Any]) -> None:
    """Append raw LLM response to the audit log inside state."""
    state = _get(session_id)
    state.record_llm_response(agent_name, raw)


# ── Read helpers ───────────────────────────────────────────────────────────────

def get_field(session_id: str, field: str, default: Any = None) -> Any:
    """
    Read a single field from state safely.

        destination = get_field(sid, "destination")
    """
    state = _get(session_id)
    return getattr(state, field, default)


def get_snapshot(session_id: str) -> Dict[str, Any]:
    """Return the full current state as a plain dict."""
    state = _get(session_id)
    return state.snapshot()


def is_stage_done(session_id: str, stage: str) -> bool:
    """Check whether a pipeline stage has been completed."""
    state = _get(session_id)
    return bool(getattr(state, f"{stage}_done", False))


# ── Reset / lifecycle ──────────────────────────────────────────────────────────

def reset_session(session_id: str) -> None:
    """Wipe all data for a session (keeps the session_id alive)."""
    state = _get(session_id)
    state.reset(keep_session_id=True)
    log.info(f"[MemoryHandler] Session {session_id!r} reset ✓")


def destroy_session(session_id: str) -> None:
    """Completely remove a session from memory."""
    session_manager.delete_session(session_id)
    log.info(f"[MemoryHandler] Session {session_id!r} destroyed ✓")


# ── Internal ───────────────────────────────────────────────────────────────────

def _get(session_id: str) -> GlobalTravelState:
    """Internal: fetch state or raise a clear error."""
    try:
        return session_manager.get_session(session_id)
    except KeyError:
        raise RuntimeError(
            f"No active session '{session_id}'. "
            "Call session_manager.create_session() before using memory_handler."
        )
