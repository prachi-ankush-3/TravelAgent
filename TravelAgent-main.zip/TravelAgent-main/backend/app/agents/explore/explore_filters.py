"""Filtering utilities for ExploreAgent.

Each function accepts a list of place dicts and returns a filtered list.
"""
from typing import List, Dict, Any


def filter_by_budget(places: List[Dict[str, Any]], budget_level: str) -> List[Dict[str, Any]]:
    """Keep places matching user's budget_level (low|medium|high).

    If budget_level is unknown, return places unchanged.
    """
    if not budget_level:
        return places
    level = budget_level.lower()
    return [p for p in places if p.get("budget_type", "").lower() == level]


def filter_family_friendly(places: List[Dict[str, Any]], needs_family_friendly: bool) -> List[Dict[str, Any]]:
    if not needs_family_friendly:
        return places
    return [p for p in places if p.get("family_friendly")]


def filter_by_interests(places: List[Dict[str, Any]], interests: List[str]) -> List[Dict[str, Any]]:
    if not interests:
        return places
    lowered = [i.lower() for i in interests]

    def matches(p: Dict[str, Any]) -> bool:
        cat = (p.get("category") or "").lower()
        # simple substring match for interest keywords
        for i in lowered:
            if i in cat or cat in i:
                return True
            # map plural forms (e.g., 'beaches' -> 'beach')
            if i.rstrip("s") in cat:
                return True
        return False

    matched = [p for p in places if matches(p)]
    return matched if matched else places


def filter_by_duration(places: List[Dict[str, Any]], duration_days: int) -> List[Dict[str, Any]]:
    if not duration_days or duration_days > 2:
        return places
    # For short trips, avoid high estimated_cost or high adventure_level
    out = [p for p in places if p.get("adventure_level", 0) <= 3 and p.get("estimated_cost", 0) <= 1500]
    return out if out else places
