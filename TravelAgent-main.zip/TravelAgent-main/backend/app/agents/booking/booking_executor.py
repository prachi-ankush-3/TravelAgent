"""Execution layer for booking operations through provider abstraction."""
from __future__ import annotations

from typing import Any, Dict

from app.core.logger import get_logger
from app.integrations.booking.bus_provider import BusProvider


log = get_logger(__name__)


class BookingExecutor:
    """Thin execution layer delegating calls to BusProvider."""

    def __init__(self, provider: BusProvider) -> None:
        self.provider = provider

    def search_buses(self, intent: Dict[str, Any]) -> list[Dict[str, Any]]:
        preferences = intent.get("preferences") or {}
        return self.provider.search_buses(
            source=intent["source"],
            destination=intent["destination"],
            date=intent["travel_date"],
            ac_only=bool(preferences.get("ac_only", False)),
            sleeper_only=bool(preferences.get("sleeper", False)),
            min_rating=float(preferences.get("min_rating", 1.0)),
            sort_by=str(preferences.get("sort_by", "price_min")),
            order=str(preferences.get("order", "asc")),
            limit=int(preferences.get("limit", 10)),
            offset=int(preferences.get("offset", 0)),
        )

    def get_seat_layout(self, bus_id: str) -> Dict[str, Any]:
        return self.provider.get_seat_layout(bus_id)

    def book_ticket(
        self,
        bus_id: str,
        seat_no: str,
        passenger: Dict[str, Any],
        intent: Dict[str, Any] | None = None,
        seat_preferences: list[str] | None = None,
    ) -> Dict[str, Any]:
        intent = intent or {}
        payload = {
            "bus_id": bus_id,
            "seat_no": seat_no,
            "passenger_name": passenger["passenger_name"],
            "passenger_age": int(passenger["passenger_age"]),
            "passenger_gender": passenger["passenger_gender"],
            "phone_number": passenger["phone_number"],
            "source": intent.get("source") or passenger.get("source") or "",
            "destination": intent.get("destination") or passenger.get("destination") or "",
            "travel_date": intent.get("travel_date") or passenger.get("travel_date") or "",
            "seat_preferences": seat_preferences or [],
        }
        log.info("[BookingExecutor] book_ticket payload=%s", payload)
        return self.provider.book_ticket(payload)

    def get_booking(self, booking_id: str) -> Dict[str, Any]:
        return self.provider.get_booking(booking_id)

    def cancel_booking(self, booking_id: str) -> Dict[str, Any]:
        return self.provider.cancel_booking(booking_id)
