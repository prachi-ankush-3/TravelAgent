"""Filters for HotelAgent recommendations."""
from __future__ import annotations

from typing import Any, Dict, Iterable, List, Set


def _budget_level_from_value(budget_field: Any) -> str | None:
    try:
        if isinstance(budget_field, dict):
            total = budget_field.get("total_budget")
        else:
            total = budget_field
        if total is None:
            return None
        total = float(total)
        if total <= 3000:
            return "low"
        if total <= 15000:
            return "medium"
        return "high"
    except Exception:
        return None


def filter_by_budget(hotels: List[Dict[str, Any]], budget_field: Any) -> List[Dict[str, Any]]:
    budget_level = _budget_level_from_value(budget_field)
    if not budget_level:
        return list(hotels)

    order = {"low": 0, "medium": 1, "high": 2}
    allowed_max = order.get(budget_level, 2)

    filtered: List[Dict[str, Any]] = []
    for hotel in hotels:
        hotel_budget = str(hotel.get("budget_type", "")).lower()
        if order.get(hotel_budget, 2) <= allowed_max:
            filtered.append(hotel)
    return filtered


def filter_by_location(hotels: List[Dict[str, Any]], destination: str, suggested_places: Iterable[Dict[str, Any]] | None = None) -> List[Dict[str, Any]]:
    destination_text = (destination or "").strip().lower()
    attraction_tokens: Set[str] = set()

    for place in suggested_places or []:
        if not isinstance(place, dict):
            continue
        for key in ("name", "location", "category"):
            value = place.get(key)
            if value:
                attraction_tokens.add(str(value).lower())

    filtered: List[Dict[str, Any]] = []
    for hotel in hotels:
        haystack = " ".join(
            [
                str(hotel.get("location", "")),
                " ".join(hotel.get("nearby_places", []) or []),
                str(hotel.get("name", "")),
            ]
        ).lower()

        if destination_text and destination_text in haystack:
            filtered.append(hotel)
            continue

        if any(token and token in haystack for token in attraction_tokens):
            filtered.append(hotel)

    return filtered or list(hotels)


def filter_by_amenities(hotels: List[Dict[str, Any]], preferences: Iterable[str] | None) -> List[Dict[str, Any]]:
    requested = [str(item).lower() for item in (preferences or []) if item]
    if not requested:
        return list(hotels)

    filtered: List[Dict[str, Any]] = []
    for hotel in hotels:
        amenities = {str(item).lower() for item in hotel.get("amenities", []) or []}
        if all(item in amenities for item in requested):
            filtered.append(hotel)
    return filtered or list(hotels)


def filter_by_travel_style(hotels: List[Dict[str, Any]], travel_style: str | None) -> List[Dict[str, Any]]:
    style = (travel_style or "").lower()
    if not style:
        return list(hotels)

    if "family" in style:
        return [hotel for hotel in hotels if hotel.get("family_friendly", True)] or list(hotels)
    if any(token in style for token in ("couple", "romantic")):
        return [hotel for hotel in hotels if hotel.get("couple_friendly", True)] or list(hotels)
    return list(hotels)