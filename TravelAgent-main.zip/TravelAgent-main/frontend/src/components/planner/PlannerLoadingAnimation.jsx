import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Map, MapPin, Compass, BedDouble, Coffee, Building2, CalendarDays, ListOrdered, Sparkles, MapPinned } from 'lucide-react';

const stages = [
  {
    id: 'places',
    text: 'Searching places for roaming...',
    icons: [Map, MapPin, Compass],
    color: '#ff9f43',
    bgColor: 'rgba(255, 159, 67, 0.1)',
  },
  {
    id: 'hotels',
    text: 'Searching the best hotels...',
    icons: [Building2, BedDouble, Coffee],
    color: '#00d2d3',
    bgColor: 'rgba(0, 210, 211, 0.1)',
  },
  {
    id: 'plan',
    text: 'Making detailed day-by-day plan...',
    icons: [CalendarDays, ListOrdered, MapPinned],
    color: '#f368e0',
    bgColor: 'rgba(243, 104, 224, 0.1)',
  },
  {
    id: 'finalizing',
    text: 'Finalizing your dream itinerary...',
    icons: [Sparkles],
    color: '#1dd1a1',
    bgColor: 'rgba(29, 209, 161, 0.1)',
  }
];

export default function PlannerLoadingAnimation({ onAnimationComplete }) {
  const [currentStageIndex, setCurrentStageIndex] = useState(0);
  const stage = stages[currentStageIndex];

  useEffect(() => {
    // Cycle through stages every 4 seconds
    const timer = setInterval(() => {
      setCurrentStageIndex((prev) => {
        if (prev < stages.length - 1) {
          return prev + 1;
        } else {
          clearInterval(timer);
          if (onAnimationComplete) {
            // Signal that animation has completed all stages
            onAnimationComplete();
          }
          return prev;
        }
      });
    }, 4000);
    return () => clearInterval(timer);
  }, [onAnimationComplete]);

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      minHeight: '400px',
      padding: '40px',
      width: '100%',
      maxWidth: '600px',
      margin: '0 auto'
    }}>
      <AnimatePresence mode="wait">
        <motion.div
          key={stage.id}
          initial={{ opacity: 0, y: 20, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -20, scale: 0.9 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          style={{
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            gap: '32px'
          }}
        >
          {/* Icons container */}
          <div style={{ display: 'flex', gap: '24px', alignItems: 'center' }}>
            {stage.icons.map((Icon, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ 
                  delay: idx * 0.2, 
                  type: 'spring', 
                  stiffness: 200, 
                  damping: 15 
                }}
              >
                <motion.div
                  animate={{ 
                    y: [0, -10, 0],
                    rotate: [0, 5, -5, 0]
                  }}
                  transition={{ 
                    duration: 4, 
                    repeat: Infinity, 
                    repeatType: "reverse",
                    ease: "easeInOut",
                    delay: idx * 0.3
                  }}
                  style={{
                    width: '72px',
                    height: '72px',
                    borderRadius: '50%',
                    background: stage.bgColor,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    border: `1px solid ${stage.color}40`,
                    boxShadow: `0 0 20px ${stage.color}20`
                  }}
                >
                  <Icon size={32} color={stage.color} strokeWidth={1.5} />
                </motion.div>
              </motion.div>
            ))}
          </div>

          {/* Text */}
          <div style={{ textAlign: 'center' }}>
            <motion.h3 
              style={{ 
                fontSize: '24px', 
                fontWeight: 700, 
                color: 'white',
                marginBottom: '12px',
                letterSpacing: '-0.5px'
              }}
            >
              {stage.text}
            </motion.h3>
            <motion.div 
              style={{ 
                width: '100%', 
                height: '4px', 
                background: 'rgba(255,255,255,0.1)', 
                borderRadius: '4px',
                overflow: 'hidden',
                marginTop: '24px'
              }}
            >
              <motion.div 
                initial={{ width: '0%' }}
                animate={{ width: '100%' }}
                transition={{ duration: 4, ease: "linear" }}
                style={{
                  height: '100%',
                  background: `linear-gradient(90deg, ${stage.color}40, ${stage.color})`,
                  borderRadius: '4px'
                }}
              />
            </motion.div>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
