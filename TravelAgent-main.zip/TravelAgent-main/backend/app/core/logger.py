# core/logger.py
# Centralized logging configuration for TravelAgent

import logging
import sys
from pathlib import Path

# ─── Log Directory ─────────────────────────────────────────────────────────────
LOG_DIR = Path(__file__).resolve().parents[3] / "logs"  # backend/logs/
LOG_DIR.mkdir(exist_ok=True)
LOG_FILE = LOG_DIR / "travelagent.log"

# ─── Format ────────────────────────────────────────────────────────────────────
LOG_FORMAT = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


def get_logger(name: str = "travelagent") -> logging.Logger:
    """
    Returns a configured logger instance.

    Usage:
        from app.core.logger import get_logger
        log = get_logger(__name__)
        log.info("Server started")
    """
    logger = logging.getLogger(name)

    # Avoid adding duplicate handlers on re-import
    if logger.handlers:
        return logger

    logger.setLevel(logging.DEBUG)
    formatter = logging.Formatter(LOG_FORMAT, datefmt=DATE_FORMAT)

    # Console handler — INFO and above
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(formatter)

    # File handler — DEBUG and above (full detail)
    file_handler = logging.FileHandler(LOG_FILE, encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(formatter)

    logger.addHandler(console_handler)
    logger.addHandler(file_handler)

    return logger
