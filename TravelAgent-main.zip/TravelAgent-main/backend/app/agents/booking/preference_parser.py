"""Preference and intent parsing for bus booking orchestration."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import date, timedelta
from typing import Any, Dict


@dataclass
class BookingIntent:
    source: str
    destination: str
    travel_date: str
    budget: float | None = None
    preferences: Dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> Dict[str, Any]:
        return asdict(self)


def _normalize_date(value: Any) -> str:
    if not value:
        return (date.today() + timedelta(days=1)).isoformat()
    text = str(value)
    return text[:10]


def _coerce_budget(raw_budget: Any) -> float | None:
    if raw_budget is None:
        return None
    if isinstance(raw_budget, dict):
        candidate = raw_budget.get("transport_budget") or raw_budget.get("total_budget")
    else:
        candidate = raw_budget
    try:
        return float(candidate)
    except (TypeError, ValueError):
        return None


def parse_booking_intent(state: Any) -> BookingIntent:
    source = str(getattr(state, "origin", None) or "").strip()
    destination = str(getattr(state, "destination", None) or "").strip()

    travel_dates = getattr(state, "travel_dates", None) or {}
    travel_date = _normalize_date(travel_dates.get("start") if isinstance(travel_dates, dict) else None)

    preferences: Dict[str, Any] = {}
    travel_style = str(getattr(state, "travel_style", "") or "").lower()
    if "budget" in travel_style:
        preferences["cheapest_priority"] = True
    if "luxury" in travel_style or "comfort" in travel_style:
        preferences["comfort_priority"] = True
    if "family" in travel_style or "safe" in travel_style:
        preferences["safety_priority"] = True

    interests = [str(x).lower() for x in (getattr(state, "interests", None) or [])]
    if any(x in interests for x in ["overnight", "night", "sleep"]):
        preferences["sleeper"] = True
        preferences["peaceful_sleep"] = True
    if "scenic" in interests:
        preferences["window_seat"] = True

    # Allow caller/user to override with explicit booking preferences in state extras.
    extra_preferences = getattr(state, "booking_preferences", None)
    if isinstance(extra_preferences, dict):
        preferences.update(extra_preferences)

    budget = _coerce_budget(getattr(state, "budget", None))
    return BookingIntent(
        source=source,
        destination=destination,
        travel_date=travel_date,
        budget=budget,
        preferences=preferences,
    )
