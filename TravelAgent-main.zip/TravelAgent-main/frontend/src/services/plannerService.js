import api from './api';

export const plannerService = {
  generatePlan: async (query, sessionId = null) => {
    try {
      const response = await api.post('/plan', {
        query,
        session_id: sessionId,
      });
      return response.data;
    } catch (error) {
      console.error('Planner API Error:', error);
      throw error;
    }
  },
  getPlans: async () => {
    try {
      const response = await api.get('/plan/list');
      return response.data;
    } catch (error) {
      console.error('Planner API Error:', error);
      throw error;
    }
  },
};
