import React, { useState } from 'react';
import { Paperclip, Send } from 'lucide-react';

export default function ChatInput({ onSend, disabled }) {
  const [input, setInput] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!input.trim() || disabled) return;
    onSend(input);
    setInput('');
  };

  const canSend = input.trim() && !disabled;

  return (
    <form onSubmit={handleSubmit} className="chat-input-v2">
      {/* Attachment icon */}
      <button
        type="button"
        className="chat-attach-btn"
        tabIndex={-1}
      >
        <Paperclip size={18} />
      </button>

      {/* Text input */}
      <input
        type="text"
        className="chat-text-input"
        placeholder="Where would you like to travel?"
        value={input}
        onChange={(e) => setInput(e.target.value)}
        disabled={disabled}
        autoComplete="off"
      />

      {/* Send button - orange rounded square */}
      <button
        type="submit"
        disabled={!canSend}
        className={`chat-send-btn${canSend ? ' chat-send-btn--active' : ''}`}
      >
        <Send size={17} strokeWidth={2.5} />
      </button>
    </form>
  );
}
