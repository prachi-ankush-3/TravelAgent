const DASHBOARD_TAB_KEY = 'travagent_dashboard_tab';

export function getDashboardTab() {
	try {
		const value = localStorage.getItem(DASHBOARD_TAB_KEY);
		return value === 'planner' ? 'planner' : 'bus';
	} catch {
		return 'bus';
	}
}

export function saveDashboardTab(tab) {
	try {
		localStorage.setItem(DASHBOARD_TAB_KEY, tab === 'planner' ? 'planner' : 'bus');
	} catch {
		// Ignore storage failures.
	}
}

export function getDashboardPath() {
	return `/dashboard/${getDashboardTab()}`;
}
