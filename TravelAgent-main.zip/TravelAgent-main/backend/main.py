# main.py
# TravelAgent AI — FastAPI Entry Point

import json
import httpx
from fastapi import FastAPI, HTTPException, Request, Header
from app.database.db import get_user, _supabase_request, SupabaseError
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.base import BaseHTTPMiddleware
from pydantic import BaseModel
from typing import Optional

from app.core.config import (
    APP_TITLE, APP_VERSION, APP_DESCRIPTION, ALLOWED_ORIGINS,
    LM_STUDIO_CHAT_ENDPOINT, LM_STUDIO_MODEL,
    LLM_MAX_TOKENS, LLM_TEMPERATURE, LLM_REQUEST_TIMEOUT,
)
from app.core.logger import get_logger
from app.core.prompts import TRAVEL_PLANNER_SYSTEM_PROMPT
from app.llm.json_cleaner import normalize_llm_keys
from app.agents.orchestrator.orchestrator_agent import decide_from_snapshot
from app.agents.orchestrator.workflow_manager import execute_orchestrator_plan
from app.api.routes.booking_routes import router as booking_router
from app.api.routes.auth_routes import router as auth_router

# ─── State / Memory ────────────────────────────────────────────────────────────
from app.state.session_manager import session_manager
from app.state.memory_handler import (
    update_state, mark_stage_done, record_llm_output, get_snapshot
)

log = get_logger(__name__)


def _print_workflow_summary(session_id: str, plan: dict, workflow_result: dict, snapshot: dict) -> None:
    """Print a concise summary of the generated travel plan to the terminal."""
    execution_log = workflow_result.get("execution_log", [])
    statuses = [entry.get("status", "unknown") for entry in execution_log]
    final_state = workflow_result.get("final_state", snapshot)
    itinerary = final_state.get("itinerary", []) if isinstance(final_state, dict) else []
    daily_schedule = final_state.get("daily_schedule", {}) if isinstance(final_state, dict) else {}

    print("\n=== TRAVEL PLAN SUMMARY ===")
    print(f"Session: {session_id}")
    print(f"Planned agents: {plan.get('agents_to_run', [])}")
    print(f"Execution statuses: {statuses}")
    print(f"Itinerary days: {len(itinerary)}")
    print(f"Daily schedule entries: {len(daily_schedule)}")
    if isinstance(final_state, dict):
        print(f"Plan done: {final_state.get('plan_done')}")
        print(f"Budget done: {final_state.get('budget_done')}")
        print(f"Hotel done: {final_state.get('hotel_done')}")
        print(f"Explore done: {final_state.get('explore_done')}")
    print("==========================\n")

# ─── App ───────────────────────────────────────────────────────────────────────
app = FastAPI(title=APP_TITLE, version=APP_VERSION, description=APP_DESCRIPTION)

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class RequestLogMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        path = request.url.path
        if path.startswith(("/booking", "/run-booking", "/state/", "/api/booking", "/api/run-booking")):
            log.info("[HTTP] %s %s", request.method, path)
        response = await call_next(request)
        return response


app.add_middleware(RequestLogMiddleware)

# Include booking router so frontend can call booking endpoints
app.include_router(booking_router)
app.include_router(auth_router)


# ─── Schemas ──────────────────────────────────────────────────────────────────
class TravelQuery(BaseModel):
    query: str                        # e.g. "Plan Goa trip under 15k"
    session_id: Optional[str] = None  # Pass existing ID to continue a session


class TravelPlan(BaseModel):
    session_id: str
    raw_response: dict
    state_snapshot: dict  # Full GlobalTravelState at this moment
    orchestrator_plan: dict | None = None
    workflow_result: dict | None = None


# ─── Routes ───────────────────────────────────────────────────────────────────

@app.get("/")
def home():
    """Health check — confirms the backend is running."""
    log.info("Health check called")
    return {"message": "TravAgent Backend Running", "version": APP_VERSION}


@app.post("/plan", response_model=TravelPlan)
async def plan_trip(body: TravelQuery, authorization: Optional[str] = Header(default=None)):
    """
    Accepts a natural language travel query and returns structured JSON
    extracted by the local LLM running in LM Studio.

    Example:
        POST /plan
        { "query": "Plan Goa trip under 15k" }

    Response:
        { "raw_response": { "destination": "Goa", "budget": 15000 } }
    """
    log.info(f"Received query: {body.query!r}")

    payload = {
        "model": LM_STUDIO_MODEL,
        "messages": [
            {"role": "system", "content": TRAVEL_PLANNER_SYSTEM_PROMPT},
            {"role": "user",   "content": body.query},
        ],
        "max_tokens": LLM_MAX_TOKENS,
        "temperature": LLM_TEMPERATURE,
    }

    # ── Call LM Studio ────────────────────────────────────────────────────────
    try:
        async with httpx.AsyncClient(timeout=LLM_REQUEST_TIMEOUT) as client:
            log.debug(f"Calling LM Studio: {LM_STUDIO_CHAT_ENDPOINT}")
            response = await client.post(LM_STUDIO_CHAT_ENDPOINT, json=payload)
            response.raise_for_status()

    except httpx.ConnectError:
        log.error("Cannot connect to LM Studio. Is it running on port 1234?")
        raise HTTPException(
            status_code=503,
            detail="LM Studio is not reachable at http://127.0.0.1:1234. Please start LM Studio and load the model.",
        )
    except httpx.TimeoutException:
        log.error("LM Studio request timed out")
        raise HTTPException(status_code=504, detail="LLM request timed out.")
    except httpx.HTTPStatusError as e:
        log.error(f"LM Studio returned HTTP {e.response.status_code}")
        raise HTTPException(status_code=502, detail=f"LLM returned HTTP {e.response.status_code}")

    # ── Parse response ────────────────────────────────────────────────────────
    llm_data = response.json()
    raw_text: str = llm_data["choices"][0]["message"]["content"].strip()
    log.debug(f"LLM raw output: {raw_text}")

    # Strip accidental markdown fences if LLM wraps JSON in ```
    if raw_text.startswith("```"):
        raw_text = raw_text.split("```")[1]
        if raw_text.startswith("json"):
            raw_text = raw_text[4:]
        raw_text = raw_text.strip()

    try:
        parsed: dict = json.loads(raw_text)
        # Normalize legacy/alternate keys from the LLM output so the
        # rest of the pipeline uses canonical field names.
        parsed = normalize_llm_keys(parsed)
    except json.JSONDecodeError as e:
        log.error(f"JSON parse failed: {e} | Raw: {raw_text!r}")
        raise HTTPException(
            status_code=422,
            detail=f"LLM did not return valid JSON. Raw output: {raw_text}",
        )

    log.info(f"Parsed travel plan: {parsed}")

    # ── Write into GlobalTravelState ──────────────────────────────────────────
    sid = body.session_id or session_manager.create_session()
    state = session_manager.get_or_create(sid)

    state.raw_query = body.query                    # remember original query
    update_state(sid, parsed)                       # push all LLM fields into memory
    record_llm_output(sid, "extraction", parsed)    # audit log
    mark_stage_done(sid, "extraction")              # flag pipeline stage

    # ── Print full state to terminal ──────────────────────────────────────────
    state.print_state()

    snapshot = get_snapshot(sid)
    # Run orchestrator on the up-to-date snapshot and return the plan
    try:
        plan = decide_from_snapshot(snapshot)
    except Exception:
        plan = {"agents_to_run": []}

    # Execute selected agents sequentially using shared state.
    try:
        workflow_result = execute_orchestrator_plan(plan=plan, session_id=sid)
    except Exception:
        workflow_result = {"agents_requested": plan.get("agents_to_run", []), "execution_log": [], "final_state": snapshot}

    final_snapshot = workflow_result.get("final_state", snapshot)
    _print_workflow_summary(sid, plan, workflow_result, final_snapshot)

    user_id = None
    if authorization:
        token = authorization.removeprefix("Bearer ").strip()
        if token:
            try:
                user = await get_user(token)
                user_id = str(user.get("id", "") or "") or None
            except SupabaseError as e:
                log.error(f"[plan_trip] Auth failed: {e}")

    if user_id:
        title = final_snapshot.get("destination", "New Trip")
        if isinstance(title, str) and title != "New Trip":
            title = f"{title} Trip"
            
        try:
            await _supabase_request(
                "POST",
                "/rest/v1/travel_plans",
                json={
                    "user_id": user_id,
                    "title": title,
                    "destination": final_snapshot.get("destination", ""),
                    "query": body.query,
                    "plan_data": final_snapshot
                }
            )
            log.info(f"Saved travel plan for user {user_id}")
        except Exception as e:
            log.error(f"Failed to save travel plan: {e}")

    return TravelPlan(
        session_id=sid,
        raw_response=parsed,
        state_snapshot=final_snapshot,
        orchestrator_plan=plan,
        workflow_result=workflow_result,
    )


@app.get("/plan/list")
async def get_travel_plans(authorization: Optional[str] = Header(default=None)):
    """Fetch all saved travel plans for the authenticated user."""
    user_id = None
    if authorization:
        token = authorization.removeprefix("Bearer ").strip()
        if token:
            try:
                user = await get_user(token)
                user_id = str(user.get("id", "") or "") or None
            except SupabaseError as e:
                log.error(f"[get_travel_plans] Auth failed: {e}")
                raise HTTPException(status_code=401, detail="Invalid token")
    
    if not user_id:
        raise HTTPException(status_code=401, detail="Authentication required")
        
    try:
        response = await _supabase_request(
            "GET",
            "/rest/v1/travel_plans",
            params={
                "user_id": f"eq.{user_id}",
                "order": "created_at.desc"
            }
        )
        return response.json() if hasattr(response, "json") else response
    except Exception as e:
        log.error(f"Failed to fetch travel plans: {e}")
        raise HTTPException(status_code=500, detail="Failed to fetch travel plans")


class ChatMessageRequest(BaseModel):
    message: str
    session_id: Optional[str] = None
    context: Optional[str] = "bus"

class AIChatResponse(BaseModel):
    message: str
    workflow: list
    cards: list
    memory_updates: list
    requires_confirmation: bool
    session_id: str

@app.post("/chat", response_model=AIChatResponse)
async def chat_endpoint(body: ChatMessageRequest):
    """
    Universal conversational AI endpoint.
    Handles booking flow, generates structured responses with cards & workflow updates.
    """
    log.info(f"Received chat message: {body.message!r} [Context: {body.context}]")

    # Inject context-specific instructions to LLM
    sys_prompt = TRAVEL_PLANNER_SYSTEM_PROMPT
    if body.context == "bus":
        sys_prompt += "\nIMPORTANT: User is in the Bus Booking workspace. You MUST extract 'origin' and 'destination'. Example: {'origin': 'Pune', 'destination': 'Mumbai'}"

    payload = {
        "model": LM_STUDIO_MODEL,
        "messages": [
            {"role": "system", "content": sys_prompt},
            {"role": "user",   "content": body.message},
        ],
        "max_tokens": LLM_MAX_TOKENS,
        "temperature": LLM_TEMPERATURE,
    }

    try:
        async with httpx.AsyncClient(timeout=LLM_REQUEST_TIMEOUT) as client:
            response = await client.post(LM_STUDIO_CHAT_ENDPOINT, json=payload)
            response.raise_for_status()
    except Exception as e:
        log.error(f"LLM request failed: {e}")
        return AIChatResponse(
            message="I'm having trouble connecting to my brain. Please check LM Studio.",
            workflow=[],
            cards=[],
            memory_updates=[],
            requires_confirmation=False,
            session_id=body.session_id or ""
        )

    llm_data = response.json()
    raw_text: str = llm_data["choices"][0]["message"]["content"].strip()
    
    if raw_text.startswith("```"):
        raw_text = raw_text.split("```")[1]
        if raw_text.startswith("json"):
            raw_text = raw_text[4:]
        raw_text = raw_text.strip()

    parsed = {}
    try:
        parsed = normalize_llm_keys(json.loads(raw_text))
    except json.JSONDecodeError:
        log.error("JSON parse failed. Falling back.")

    sid = body.session_id or session_manager.create_session()
    state = session_manager.get_or_create(sid)

    state.raw_query = body.message
    if parsed:
        update_state(sid, parsed)
        record_llm_output(sid, "extraction", parsed)
        mark_stage_done(sid, "extraction")

    snapshot = get_snapshot(sid)
    plan = {"agents_to_run": []}
    try:
        plan = decide_from_snapshot(snapshot)
    except Exception:
        pass

    # Force context-specific agents if Orchestrator missed it
    if body.context == "bus" and "BookingAgent" not in plan.get("agents_to_run", []):
        plan["agents_to_run"] = ["BookingAgent"] + plan.get("agents_to_run", [])
    elif body.context == "planner" and not any(a in plan.get("agents_to_run", []) for a in ["ExploreAgent", "ItineraryAgent"]):
        plan["agents_to_run"].append("ExploreAgent")

    workflow_result = {"execution_log": []}
    try:
        if plan.get("agents_to_run"):
            workflow_result = execute_orchestrator_plan(plan=plan, session_id=sid)
    except Exception as e:
        log.error(f"Workflow execution failed: {e}")

    # Build response
    execution_log = workflow_result.get("execution_log", [])
    final_state = workflow_result.get("final_state", snapshot)
    
    workflow_steps = [
        {"step": "Understanding request", "status": "completed" if "extraction" in final_state.get("pipeline_flags", {}) else "processing"}
    ]
    
    for entry in execution_log:
        agent = entry.get("agent")
        if agent == "BookingAgent":
            workflow_steps.append({"step": "Searching for buses", "status": "completed"})
            if entry.get("result", {}).get("requires_confirmation"):
                workflow_steps.append({"step": "Selecting optimal seat", "status": "processing"})
        elif agent == "ExploreAgent":
            workflow_steps.append({"step": "Planning itinerary", "status": "completed"})

    cards = []
    message = "Here is what I found for you."
    requires_confirmation = False

    # Find booking recommendation
    for entry in execution_log:
        res = entry.get("result", {})
        if res.get("recommendation"):
            cards.append({
                "type": "bus_recommendation",
                "data": res["recommendation"]
            })
            message = res.get("message", message)
            requires_confirmation = res.get("requires_confirmation", False)
        
        # If BookingAgent returned an error stage (e.g. missing intent)
        if entry.get("agent") == "BookingAgent" and res.get("error"):
            if res.get("stage") == "intent_validation":
                message = "Could you please specify both your starting city and destination to search for buses?"
            elif res.get("stage") == "search":
                message = "I couldn't find any buses for that route on the selected date. Could you try a different date or route?"
    
    if final_state.get("seat_recommendation") and not requires_confirmation:
        # If auto-booked or something, maybe layout card? We'll just stick to recommendation.
        pass

    memory_updates = []
    intent = final_state.get("booking_intent") or {}
    if intent.get("destination"):
        memory_updates.append(f"Destination set to {intent['destination']}")
    if intent.get("source"):
        memory_updates.append(f"Origin set to {intent['source']}")
    prefs = intent.get("preferences") or {}
    if prefs.get("seat_type"):
        memory_updates.append(f"Prefers {prefs['seat_type']} seats")

    if not cards and not plan.get("agents_to_run") and message == "Here is what I found for you.":
        message = "Could you please specify your destination, date, and any preferences you have?"

    return AIChatResponse(
        message=message,
        workflow=workflow_steps,
        cards=cards,
        memory_updates=memory_updates,
        requires_confirmation=requires_confirmation,
        session_id=sid
    )


# ─── State Inspector ───────────────────────────────────────────────────────────

@app.get("/state/{session_id}")
def get_state(session_id: str):
    """Debug endpoint — returns the full GlobalTravelState for a session."""
    try:
        snapshot = get_snapshot(session_id)
        return {"session_id": session_id, "state": snapshot}
    except RuntimeError as e:
        raise HTTPException(status_code=404, detail=str(e))


@app.delete("/state/{session_id}")
def reset_state(session_id: str):
    """Wipe a session's memory without destroying the session ID."""
    from app.state.memory_handler import reset_session
    try:
        reset_session(session_id)
        return {"message": f"Session '{session_id}' reset ✓"}
    except RuntimeError as e:
        raise HTTPException(status_code=404, detail=str(e))


# ─── Dev Launcher ─────────────────────────────────────────────────────────────
@app.on_event("startup")
async def log_startup() -> None:
    log.info("TravAgent API ready at http://127.0.0.1:8000")
    log.info("Booking UI should proxy via Vite: http://localhost:5173/api -> :8000")
    log.info("Key routes: POST /booking/chat  POST /booking/new  GET /booking/list")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True, access_log=True)
