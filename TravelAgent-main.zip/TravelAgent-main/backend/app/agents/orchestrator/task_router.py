"""Task router placeholder — will convert plan entries to runnable tasks.

Currently provides a no-op mapping from agent names to task descriptors.
"""
from typing import Dict, Any


def agent_to_task(agent_name: str) -> Dict[str, Any]:
    return {"agent": agent_name, "task": "run"}
