import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { BrainCircuit, Map, Calendar, Coffee, Navigation, Sparkles, Send } from 'lucide-react';
import PlannerLoadingAnimation from '../components/planner/PlannerLoadingAnimation';
import PlannerResults from '../components/planner/PlannerResults';
import PlannerSidebar from '../components/planner/PlannerSidebar';
import { plannerService } from '../services/plannerService';

export default function PlannerWorkspace() {
  const [query, setQuery] = useState('');
  const [status, setStatus] = useState('idle'); // 'idle' | 'loading' | 'results' | 'error'
  const [results, setResults] = useState(null);
  const [errorMsg, setErrorMsg] = useState('');
  
  const [apiResult, setApiResult] = useState(null);
  const [animationDone, setAnimationDone] = useState(false);

  useEffect(() => {
    if (status === 'loading' && apiResult && animationDone) {
      if (apiResult.error) {
        setErrorMsg(apiResult.error);
        setStatus('error');
      } else {
        setResults(apiResult);
        setStatus('results');
      }
    }
  }, [status, apiResult, animationDone]);

  const handleGenerate = async (e) => {
    e.preventDefault();
    if (!query.trim()) return;

    setStatus('loading');
    setErrorMsg('');
    setResults(null);
    setApiResult(null);
    setAnimationDone(false);

    try {
      const data = await plannerService.generatePlan(query);
      if (data.error) {
        setApiResult({ error: data.error });
      } else {
        setApiResult(data);
      }
    } catch (err) {
      console.error('Planner error:', err);
      setApiResult({ error: err.message || 'An error occurred while planning your trip.' });
    }
  };

  const handleReset = () => {
    setStatus('idle');
    setQuery('');
    setResults(null);
    setApiResult(null);
    setAnimationDone(false);
  };

  const handleSelectPlan = (plan) => {
    setQuery(plan.query || '');
    setResults({ state_snapshot: plan.plan_data });
    setStatus('results');
  };

  return (
    <div style={{ display: 'flex', width: '100%', height: '100%' }}>
      <PlannerSidebar onSelectPlan={handleSelectPlan} onNewTrip={handleReset} />
      
      <div 
        className="planner-workspace" 
        style={{ 
          flex: 1, 
          height: '100%', 

        overflowY: 'auto',
        padding: '40px 24px 60px 24px'
      }}
    >
      {status === 'idle' && (
        <motion.div
          key="idle-state"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.5 }}
          style={{ maxWidth: '600px', width: '100%', margin: '40px auto 0 auto', textAlign: 'center' }}
        >
          <div style={{ display: 'inline-flex', padding: '24px', borderRadius: '50%', background: 'var(--glass-bg)', border: '1px solid var(--glass-border)', marginBottom: '24px' }}>
            <Map size={48} color="var(--accent-orange)" />
          </div>
          
          <h2 className="gradient-text" style={{ fontSize: '36px', fontWeight: 900, marginBottom: '16px' }}>AI Trip Planner</h2>
          <p style={{ fontSize: '18px', color: 'var(--text-muted)', marginBottom: '40px' }}>
            Describe your dream vacation, and our AI will generate a complete timeline-based itinerary.
          </p>

          <form onSubmit={handleGenerate} style={{ position: 'relative', marginBottom: '40px' }}>
            <textarea
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="e.g. Plan a 5-day Goa trip under 20k with focus on beaches and nightlife..."
              style={{
                width: '100%',
                minHeight: '120px',
                padding: '24px',
                paddingRight: '80px',
                background: 'var(--glass-bg)',
                border: '1px solid var(--accent-orange)',
                borderRadius: '24px',
                color: 'white',
                fontSize: '18px',
                lineHeight: 1.5,
                resize: 'none',
                boxShadow: '0 0 40px rgba(255, 159, 67, 0.1)',
                outline: 'none',
              }}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleGenerate(e);
                }
              }}
            />
            <button
              type="submit"
              disabled={!query.trim()}
              style={{
                position: 'absolute',
                right: '16px',
                bottom: '16px',
                width: '48px',
                height: '48px',
                borderRadius: '16px',
                background: query.trim() ? 'var(--accent-orange)' : 'rgba(255,255,255,0.1)',
                color: query.trim() ? 'black' : 'rgba(255,255,255,0.3)',
                border: 'none',
                cursor: query.trim() ? 'pointer' : 'not-allowed',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                transition: 'all 0.2s',
              }}
            >
              <Send size={20} style={{ marginLeft: '2px' }} />
            </button>
          </form>

          <div style={{ padding: '24px', background: 'rgba(255,106,0,0.05)', border: '1px solid var(--accent-orange-glow)', borderRadius: '16px', textAlign: 'left', display: 'flex', flexDirection: 'column', gap: '16px' }}>
             <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--accent-orange)', fontWeight: 600 }}>
               <BrainCircuit size={20} /> Generative AI Itineraries
             </div>
             <p style={{ fontSize: '14px', color: 'var(--text-muted)', lineHeight: 1.6 }}>
               Our intelligent orchestrator searches across multiple agents to organize:
             </p>
             <ul style={{ fontSize: '14px', color: 'white', display: 'flex', flexWrap: 'wrap', gap: '16px', listStyle: 'none', padding: 0, margin: 0 }}>
               <li style={{ display: 'flex', alignItems: 'center', gap: '8px' }}><Calendar size={16} color="var(--accent-orange)" /> Day-by-day plans</li>
               <li style={{ display: 'flex', alignItems: 'center', gap: '8px' }}><Navigation size={16} color="var(--accent-orange)" /> Optimal routing</li>
               <li style={{ display: 'flex', alignItems: 'center', gap: '8px' }}><Coffee size={16} color="var(--accent-orange)" /> Local food spots</li>
             </ul>
          </div>
        </motion.div>
      )}

      {status === 'loading' && (
        <motion.div
          key="loading-state"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          style={{ width: '100%', minHeight: '60vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
        >
          <PlannerLoadingAnimation onAnimationComplete={() => setAnimationDone(true)} />
        </motion.div>
      )}

      {status === 'error' && (
        <motion.div
          key="error-state"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          style={{ maxWidth: '600px', width: '100%', margin: '60px auto 0 auto', textAlign: 'center' }}
        >
          <div style={{ color: '#ff4757', marginBottom: '24px', fontSize: '18px' }}>
            {errorMsg}
          </div>
          <button
            onClick={handleReset}
            style={{
              padding: '12px 24px',
              background: 'rgba(255,255,255,0.1)',
              border: '1px solid rgba(255,255,255,0.2)',
              borderRadius: '12px',
              color: 'white',
              cursor: 'pointer',
              fontSize: '16px'
            }}
          >
            Try Again
          </button>
        </motion.div>
      )}

      {status === 'results' && results && (
        <motion.div
          key="results-state"
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          style={{ width: '100%', maxWidth: '800px', margin: '0 auto' }}
        >
          <div style={{ display: 'flex', justifyContent: 'flex-start', marginBottom: '32px' }}>
            <button
              onClick={handleReset}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                padding: '10px 20px',
                background: 'rgba(255,255,255,0.05)',
                border: '1px solid rgba(255,255,255,0.1)',
                borderRadius: '99px',
                color: 'white',
                cursor: 'pointer',
                fontSize: '14px',
                fontWeight: 600,
                transition: 'all 0.2s',
              }}
              onMouseOver={(e) => e.currentTarget.style.background = 'rgba(255,255,255,0.1)'}
              onMouseOut={(e) => e.currentTarget.style.background = 'rgba(255,255,255,0.05)'}
            >
              <Sparkles size={16} color="var(--accent-orange)" />
              Plan Another Trip
            </button>
          </div>
          <PlannerResults results={results} />
        </motion.div>
      )}

    </div>
    </div>
  );
}
