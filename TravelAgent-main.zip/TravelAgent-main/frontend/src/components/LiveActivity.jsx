import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Activity, CheckCircle2, Loader2, BrainCircuit } from 'lucide-react';

export default function LiveActivity({ currentStep = 2 }) {
  const steps = [
    "Understanding your journey",
    "Searching available buses",
    "Comparing comfort and pricing",
    "Selecting optimal seats",
    "Preparing booking"
  ];

  return (
    <div style={{
      width: '300px',
      height: '100vh',
      background: 'var(--bg-sidebar)',
      borderLeft: '1px solid var(--glass-border)',
      padding: '24px',
      display: 'flex',
      flexDirection: 'column'
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '32px' }}>
        <motion.div 
          animate={{ rotate: 360 }} 
          transition={{ duration: 4, repeat: Infinity, ease: 'linear' }}
        >
          <Activity size={20} color="var(--accent-orange)" />
        </motion.div>
        <h2 style={{ fontSize: '16px', fontWeight: 600 }}>TravAgent Thinking</h2>
      </div>

      <div style={{ position: 'relative', flex: 1 }}>
        {/* Connecting Line */}
        <div style={{ position: 'absolute', left: '11px', top: '24px', bottom: '24px', width: '2px', background: 'var(--glass-border)', zIndex: 0 }} />

        <div style={{ display: 'flex', flexDirection: 'column', gap: '32px', position: 'relative', zIndex: 1 }}>
          <AnimatePresence>
            {steps.map((step, index) => {
              const isCompleted = index < currentStep;
              const isActive = index === currentStep;
              const isPending = index > currentStep;

              return (
                <motion.div 
                  key={step}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: isPending ? 0.4 : 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  style={{ display: 'flex', gap: '16px', alignItems: 'flex-start' }}
                >
                  <div style={{ position: 'relative', zIndex: 2, background: 'var(--bg-sidebar)', padding: '2px 0' }}>
                    {isCompleted && (
                      <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }}>
                        <CheckCircle2 size={24} color="#10B981" />
                      </motion.div>
                    )}
                    {isActive && (
                      <motion.div 
                        className="animate-glow"
                        style={{ background: 'var(--glass-bg)', borderRadius: '50%', padding: '2px' }}
                      >
                        <motion.div
                           animate={{ rotate: 360 }}
                           transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
                        >
                          <Loader2 size={20} color="var(--accent-orange)" />
                        </motion.div>
                      </motion.div>
                    )}
                    {isPending && (
                      <div style={{ width: '24px', height: '24px', borderRadius: '50%', border: '2px solid var(--glass-border)' }} />
                    )}
                  </div>
                  
                  <div style={{ paddingTop: '2px' }}>
                    <div style={{ 
                      fontSize: '14px', 
                      fontWeight: isActive ? 600 : 400,
                      color: isActive ? 'white' : 'var(--text-muted)'
                    }}>
                      {step}
                    </div>
                    {isActive && (
                      <motion.div 
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        style={{ fontSize: '12px', color: 'var(--accent-orange)', marginTop: '4px', display: 'flex', alignItems: 'center', gap: '4px' }}
                      >
                        <BrainCircuit size={12} /> AI processing...
                      </motion.div>
                    )}
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      </div>
      
      <div style={{ marginTop: 'auto', padding: '16px', background: 'rgba(255,106,0,0.05)', border: '1px solid var(--accent-orange-glow)', borderRadius: '12px', display: 'flex', alignItems: 'center', gap: '12px' }}>
        <BrainCircuit size={24} color="var(--accent-orange)" />
        <div style={{ fontSize: '12px' }}>
          <div style={{ color: 'white', fontWeight: 600 }}>Memory Active</div>
          <div style={{ color: 'var(--text-muted)' }}>Preferences loaded.</div>
        </div>
      </div>
    </div>
  );
}
