"""HotelAgent — recommends context-aware hotels from the dataset.

The agent reads shared session state, uses explore recommendations to bias
location matching, filters by budget/preferences, ranks, and writes the result
back into the state.
"""
from __future__ import annotations

from typing import Any, Dict, List

from app.state.session_manager import session_manager
from app.state.memory_handler import update_state, mark_stage_done
from app.services.hotel_service import get_hotels
from app.agents.hotel.hotel_filters import (
    filter_by_budget,
    filter_by_location,
    filter_by_amenities,
    filter_by_travel_style,
)
from app.agents.hotel.hotel_ranker import rank_hotels


class HotelAgent:
    def _normalize_amenities(self, preferences: Any) -> List[str]:
        if not preferences:
            return []
        if isinstance(preferences, dict):
            return [str(item).lower() for item in preferences.get("amenities", []) or []]
        if isinstance(preferences, list):
            return [str(item).lower() for item in preferences]
        return []

    def run(self, state) -> Dict[str, Any]:
        """Run hotel selection using a shared GlobalTravelState instance."""
        destination = getattr(state, "destination", None)
        if not destination:
            return {"error": "missing_destination"}

        budget = getattr(state, "budget", None)
        travel_style = getattr(state, "travel_style", None)
        hotel_preferences = getattr(state, "hotel_preferences", None)
        suggested_places = getattr(state, "suggested_places", None) or getattr(state, "suggested_activities", None) or []

        amenities_preferences = self._normalize_amenities(hotel_preferences)

        hotels = get_hotels(destination)
        candidates = filter_by_location(hotels, destination, suggested_places)
        candidates = filter_by_budget(candidates, budget)
        candidates = filter_by_travel_style(candidates, travel_style)
        candidates = filter_by_amenities(candidates, amenities_preferences)

        ranked = rank_hotels(candidates, budget_field=budget, suggested_places=suggested_places)

        recommendations: List[Dict[str, Any]] = []
        for hotel in ranked:
            recommendations.append(
                {
                    "name": hotel.get("name"),
                    "location": hotel.get("location"),
                    "category": hotel.get("category"),
                    "star_rating": hotel.get("star_rating"),
                    "rating": hotel.get("rating"),
                    "price_per_night": hotel.get("price_per_night"),
                    "amenities": hotel.get("amenities", []),
                    "nearby_places": hotel.get("nearby_places", []),
                    "score": hotel.get("score"),
                }
            )

        update_state(
            state.session_id,
            {
                "suggested_hotels": recommendations,
                "selected_hotel_candidates": recommendations,
            },
        )
        mark_stage_done(state.session_id, "hotel")

        return {"recommended": recommendations}


def run_for_session(session_id: str) -> Dict[str, Any]:
    state = session_manager.get_or_create(session_id)
    return HotelAgent().run(state)