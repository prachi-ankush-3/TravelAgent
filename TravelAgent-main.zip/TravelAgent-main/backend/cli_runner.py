"""Simple interactive CLI to send travel queries to the existing pipeline.

Run from repository root:

    python backend/cli_runner.py

It will prompt for a natural-language query, call LM Studio, normalize keys,
update session state and print the returned snapshot. This mirrors the logic
in the FastAPI `/plan` endpoint so you can test without running the HTTP server.
"""
import asyncio
import json
import sys

import httpx

from app.core.config import (
    LM_STUDIO_CHAT_ENDPOINT,
    LM_STUDIO_MODEL,
    LLM_MAX_TOKENS,
    LLM_TEMPERATURE,
    LLM_REQUEST_TIMEOUT,
)
from app.core.prompts import TRAVEL_PLANNER_SYSTEM_PROMPT
from app.llm.json_cleaner import normalize_llm_keys
from app.state.session_manager import session_manager
from app.state.memory_handler import (
    update_state,
    record_llm_output,
    mark_stage_done,
    get_snapshot,
)
from app.agents.orchestrator.orchestrator_agent import decide_from_snapshot
from app.agents.orchestrator.workflow_manager import execute_orchestrator_plan
from app.core.logger import get_logger

log = get_logger(__name__)


def _print_workflow_summary(session_id: str, plan: dict, workflow_result: dict, snapshot: dict) -> None:
    """Print a concise summary of the generated travel plan to the terminal."""
    execution_log = workflow_result.get("execution_log", [])
    statuses = [entry.get("status", "unknown") for entry in execution_log]
    final_state = workflow_result.get("final_state", snapshot)
    itinerary = final_state.get("itinerary", []) if isinstance(final_state, dict) else []
    daily_schedule = final_state.get("daily_schedule", {}) if isinstance(final_state, dict) else {}

    print("\n=== TRAVEL PLAN SUMMARY ===")
    print(f"Session: {session_id}")
    print(f"Planned agents: {plan.get('agents_to_run', [])}")
    print(f"Execution statuses: {statuses}")
    print(f"Itinerary days: {len(itinerary)}")
    print(f"Daily schedule entries: {len(daily_schedule)}")
    if isinstance(final_state, dict):
        print(f"Plan done: {final_state.get('plan_done')}")
        print(f"Budget done: {final_state.get('budget_done')}")
        print(f"Hotel done: {final_state.get('hotel_done')}")
        print(f"Explore done: {final_state.get('explore_done')}")
    print("==========================\n")


async def _process_query(query: str, session_id: str | None = None) -> dict:
    payload = {
        "model": LM_STUDIO_MODEL,
        "messages": [
            {"role": "system", "content": TRAVEL_PLANNER_SYSTEM_PROMPT},
            {"role": "user", "content": query},
        ],
        "max_tokens": LLM_MAX_TOKENS,
        "temperature": LLM_TEMPERATURE,
    }

    try:
        async with httpx.AsyncClient(timeout=LLM_REQUEST_TIMEOUT) as client:
            print(f"Calling LM Studio at {LM_STUDIO_CHAT_ENDPOINT}...")
            response = await client.post(LM_STUDIO_CHAT_ENDPOINT, json=payload)
            response.raise_for_status()
    except httpx.ConnectError:
        print("ERROR: Cannot connect to LM Studio. Is it running?")
        return {"error": "lm_unreachable"}
    except Exception as e:
        print("ERROR: LM Studio call failed:", e)
        return {"error": "lm_error", "detail": str(e)}

    llm_data = response.json()
    raw_text: str = llm_data["choices"][0]["message"]["content"].strip()

    if raw_text.startswith("```"):
        raw_text = raw_text.split("```")[1]
        if raw_text.startswith("json"):
            raw_text = raw_text[4:]
        raw_text = raw_text.strip()

    try:
        parsed = json.loads(raw_text)
        parsed = normalize_llm_keys(parsed)
    except json.JSONDecodeError:
        print("ERROR: LLM did not return valid JSON. Raw output:\n", raw_text)
        return {"error": "invalid_json", "raw": raw_text}

    sid = session_id or session_manager.create_session()
    state = session_manager.get_or_create(sid)

    state.raw_query = query
    update_state(sid, parsed)
    record_llm_output(sid, "extraction", parsed)
    mark_stage_done(sid, "extraction")

    state.print_state()
    snapshot = get_snapshot(sid)
    try:
        plan = decide_from_snapshot(snapshot)
    except Exception:
        plan = {"agents_to_run": []}

    try:
        workflow_result = execute_orchestrator_plan(plan=plan, session_id=sid)
    except Exception:
        workflow_result = {
            "agents_requested": plan.get("agents_to_run", []),
            "execution_log": [],
            "final_state": snapshot,
        }

    final_snapshot = workflow_result.get("final_state", snapshot)
    _print_workflow_summary(sid, plan, workflow_result, final_snapshot)

    return {
        "session_id": sid,
        "raw_response": parsed,
        "state_snapshot": final_snapshot,
        "orchestrator_plan": plan,
        "workflow_result": workflow_result,
    }


def main():
    print("TravelAgent CLI — interactive mode. Press Enter on empty query to exit.")
    try:
        while True:
            query = input("Enter travel query: ").strip()
            if not query:
                print("Exiting.")
                break
            sid = input("(Optional) session_id to continue (press Enter to create new): ").strip() or None
            result = asyncio.run(_process_query(query, sid))
            print("Result:\n", json.dumps(result, indent=2, ensure_ascii=False))
    except KeyboardInterrupt:
        print("\nInterrupted — exiting.")
        sys.exit(0)


if __name__ == "__main__":
    main()
