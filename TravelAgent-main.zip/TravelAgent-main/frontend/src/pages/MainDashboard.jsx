import React, { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import LiveActivity from '../components/workflow/LiveActivity';
import BusBookingWorkspace from './BusBookingWorkspace';
import PlannerWorkspace from './PlannerWorkspace';
import Navbar from '../components/Navbar';
import { useBookingStore } from '../store/bookingStore';
import { getDashboardTab, saveDashboardTab } from '../services/uiStorage';

export default function MainDashboard() {
	const location = useLocation();
	const navigate = useNavigate();
	const workflow = useBookingStore((state) => state.workflow);
	const activeTab = location.pathname.includes('/planner') ? 'planner' : 'bus';

	useEffect(() => {
		if (location.pathname.match(/\/dashboard\/?$/)) {
			navigate(`/dashboard/${getDashboardTab()}`, { replace: true });
		}
	}, [location.pathname, navigate]);

	useEffect(() => {
		saveDashboardTab(activeTab);
	}, [activeTab]);

	return (
		<div className="dashboard-shell main-dashboard-bg">
			<Navbar />

			<div className="dashboard-body">
				<section className="workspace-main">
					<div className="workspace-content" style={{ height: '100%' }}>
						<div
							className={`workspace-pane${activeTab === 'bus' ? ' workspace-pane--active' : ''}`}
							aria-hidden={activeTab !== 'bus'}
						>
							<BusBookingWorkspace />
						</div>
						<div
							className={`workspace-pane${activeTab === 'planner' ? ' workspace-pane--active' : ''}`}
							aria-hidden={activeTab !== 'planner'}
						>
							<PlannerWorkspace />
						</div>
					</div>
				</section>

				{activeTab === 'bus' ? <LiveActivity workflow={workflow} /> : null}
			</div>
		</div>
	);
}
