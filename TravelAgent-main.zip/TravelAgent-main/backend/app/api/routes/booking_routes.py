from __future__ import annotations

from typing import Any, Dict, List, Optional

from fastapi import APIRouter, HTTPException, Header
from pydantic import BaseModel

from app.agents.booking.booking_agent import BookingAgent
from app.agents.booking.run_booking_agent import (
	_extract_llm_json,
	_first_present,
	_parse_date_from_query,
	_resolve_natural_date,
)
from app.integrations.booking.bus_provider import create_bus_provider
from app.core.config import BOOKING_PROVIDER_BASE_URL
from app.database.db import SupabaseError, get_profile, get_user
from app.llm.json_cleaner import normalize_llm_keys
from app.core.logger import get_logger
from app.state.booking_session_manager import booking_session_manager
from app.agents.booking.booking_stage import build_workflow
from app.agents.booking.conversation_manager import conversation_manager

router = APIRouter()

_provider = create_bus_provider(BOOKING_PROVIDER_BASE_URL)
log = get_logger(__name__)


class BookRequest(BaseModel):
	booking_id: Optional[str] = None
	bus_id: str
	seat_no: str
	passenger_name: str
	passenger_age: int
	passenger_gender: str
	phone_number: str
	source: Optional[str] = None
	destination: Optional[str] = None
	travel_date: Optional[str] = None
	operator: Optional[str] = None
	price: Optional[Any] = None
	departure_time: Optional[str] = None
	arrival_time: Optional[str] = None
	seat_preferences: Optional[List[str]] = None


class RunBookingRequest(BaseModel):
	query: str
	session_id: Optional[str] = None
	booking_id: Optional[str] = None
	action: Optional[str] = "search"
	auto_book: Optional[bool] = False
	fetch_booking_details: Optional[bool] = False
	selected_bus_id: Optional[str] = None
	selected_recommendation_id: Optional[str] = None
	selected_seat_no: Optional[str] = None
	booking_preferences: Optional[Dict[str, Any]] = None
	passenger_details: Optional[Dict[str, Any]] = None


class BookingChatRequest(BaseModel):
	booking_id: str
	message: str
	selected_recommendation_id: Optional[str] = None
	selected_bus_id: Optional[str] = None
	selected_seat_no: Optional[str] = None
	action: Optional[str] = None
	auto_book: Optional[bool] = False
	booking_preferences: Optional[Dict[str, Any]] = None
	passenger_details: Optional[Dict[str, Any]] = None
	fetch_booking_details: Optional[bool] = False


def _passenger_from_profile(profile: Dict[str, Any]) -> Dict[str, Any] | None:
	if not isinstance(profile, dict):
		return None

	name = (profile.get("full_name") or profile.get("username") or "").strip()
	age = profile.get("age")
	gender = (profile.get("gender") or "").strip()
	phone = (profile.get("mobile") or "").strip()

	if not (name and age and gender and phone):
		return None

	try:
		age_int = int(age)
	except (TypeError, ValueError):
		return None

	return {
		"passenger_name": name,
		"passenger_age": age_int,
		"passenger_gender": gender,
		"phone_number": phone,
	}


def _build_booking_preferences(extracted: Dict[str, Any]) -> Dict[str, Any]:
	preferences: Dict[str, Any] = {}
	extracted_preferences = extracted.get("preferences")
	if isinstance(extracted_preferences, list):
		pref_text = " ".join(str(item).lower() for item in extracted_preferences)
		if "window" in pref_text:
			preferences["window_seat"] = True
		if "sleeper" in pref_text:
			preferences["sleeper"] = True
		if any(term in pref_text for term in ["comfort", "luxury", "premium"]):
			preferences["comfort_priority"] = True
		return preferences
	if isinstance(extracted_preferences, dict):
		return extracted_preferences
	return preferences


def _title_from_row(row: Dict[str, Any]) -> str:
	source = str(row.get("source") or "").strip()
	destination = str(row.get("destination") or "").strip()
	travel_date = str(row.get("travel_date") or "").strip()
	if source and destination and travel_date:
		return f"{source} → {destination}"
	if source and destination:
		return f"{source} → {destination}"
	return "Untitled Booking"


def _extract_booking_intent(query: str) -> Dict[str, Any]:
	extracted: Dict[str, Any] = {}
	try:
		extracted = normalize_llm_keys(_extract_llm_json(query))
	except Exception as exc:
		raise HTTPException(status_code=502, detail=f"Failed to extract booking intent: {exc}") from exc

	def _first_alias(*keys: str) -> Any:
		for key in keys:
			value = extracted.get(key)
			if value not in (None, ""):
				return value
		return None

	date_candidate = _first_present(
		(extracted.get("travel_dates") or {}).get("start") if isinstance(extracted.get("travel_dates"), dict) else None,
		extracted.get("travel_date"),
		extracted.get("date_of_departure"),
		extracted.get("departure_date"),
		_parse_date_from_query(query),
	)

	return {
		"source": _first_present(
			_first_alias("source", "origin", "departure_location", "departure_city", "from_city", "start_city"),
		) or "",
		"destination": _first_present(
			_first_alias("destination", "arrival_location", "arrival_city", "to_city", "end_city"),
		) or "",
		"travel_date": _resolve_natural_date(date_candidate),
		"budget": extracted.get("budget"),
		"preferences": _build_booking_preferences(extracted),
		"passenger_details": extracted.get("passenger_details") if isinstance(extracted.get("passenger_details"), dict) else None,
	}


@router.get("/buses")
def search_buses(
	source: str,
	destination: str,
	date: str,
	ac_only: Optional[bool] = False,
	sleeper_only: Optional[bool] = False,
	min_rating: Optional[float] = 1.0,
	sort_by: Optional[str] = "price_min",
	order: Optional[str] = "asc",
	limit: Optional[int] = 10,
	offset: Optional[int] = 0,
) -> List[Dict[str, Any]]:
	try:
		buses = _provider.search_buses(
			source=source,
			destination=destination,
			date=date,
			ac_only=bool(ac_only),
			sleeper_only=bool(sleeper_only),
			min_rating=float(min_rating or 1.0),
			sort_by=sort_by or "price_min",
			order=order or "asc",
			limit=int(limit or 10),
			offset=int(offset or 0),
		)
		return buses
	except Exception as exc:
		raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.get("/seat-layout/{bus_id}")
def seat_layout(bus_id: str) -> Dict[str, Any]:
	try:
		return _provider.get_seat_layout(bus_id)
	except Exception as exc:
		raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.post("/book-ticket")
def book_ticket(body: BookRequest) -> Dict[str, Any]:
	log.info(f"[BookingRoute] /book-ticket called with payload: {body.dict()}")
	try:
		result = _provider.book_ticket(body.dict())
		log.info(f"[BookingRoute] /book-ticket success: {result}")
		return result
	except Exception as exc:
		log.error(f"[BookingRoute] /book-ticket ERROR: {exc}", exc_info=True)
		raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.post("/run-booking-agent")
async def run_booking_agent(
	body: RunBookingRequest,
	authorization: Optional[str] = Header(default=None),
) -> Dict[str, Any]:
	try:
		sid = body.booking_id or body.session_id or booking_session_manager.create_session()
		state = booking_session_manager.load_session(sid)
		action = str(body.action or "").strip().lower() or None
		user_id: str | None = None
		log.info(
			"[BookingRoute] incoming request session=%s action=%s query=%r auto_book=%s",
			sid,
			action,
			body.query,
			body.auto_book,
		)
		log.info("[BookingRoute] state before run: origin=%r destination=%r booking_stage=%r booking_status=%r", state.origin, state.destination, state.booking_stage, state.booking_status)

		resolved_passenger = body.passenger_details

		# If passenger details are missing but user is logged in,
		# fetch profile from DB and auto-fill booking passenger data.
		if not resolved_passenger and authorization:
			token = authorization.removeprefix("Bearer ").strip()
			if token:
				try:
					user = await get_user(token)
					user_id = str(user.get("id", "") or "") or None
					state.user_id = user_id
					booking_session_manager.save_session(state)
					profile = await get_profile(str(user.get("id", "")))
					resolved_passenger = _passenger_from_profile(profile)
					if resolved_passenger:
						log.info("[BookingRoute] Auto-filled passenger details from profile for user=%s", user.get("id"))
				except SupabaseError as exc:
					log.warning("[BookingRoute] Could not auto-fill passenger details from profile: %s", exc)

		result = conversation_manager.handle_turn(
			session_id=sid,
			message=body.query,
			action=action,
			auto_book=bool(body.auto_book),
			selected_bus_id=body.selected_bus_id,
			selected_recommendation_id=body.selected_recommendation_id,
			selected_seat_no=body.selected_seat_no,
			booking_preferences=body.booking_preferences,
			passenger_details=resolved_passenger,
			fetch_booking_details=bool(body.fetch_booking_details),
			user_id=user_id,
		)
		log.info("[BookingRoute] booking agent result: %s", result)
		workflow = result.get("workflow") or build_workflow(result.get("booking_stage") or state.booking_stage)
		message = result.get("message", "Here is what I found for you.")
		cards = result.get("cards") or []
		if not cards and result.get("recommended_buses"):
			cards.append({"type": "bus_recommendation_bundle", "data": result})
		log.info("[BookingRoute] final response message=%r cards=%d", message, len(cards))

		return {
			"message": message,
			"workflow": workflow,
			"cards": cards,
			"recommended_buses": result.get("recommended_buses") or [],
			"all_buses": result.get("all_buses") or [],
			"selected_bus": result.get("selected_bus"),
			"seat_recommendation": result.get("seat_recommendation"),
			"seat_layout": result.get("seat_layout"),
			"ticket": result.get("ticket"),
			"booking": result.get("booking"),
			"status": result.get("status"),
			"booking_stage": result.get("booking_stage") or (state.booking_stage.value if hasattr(state.booking_stage, "value") else state.booking_stage),
			"conversation_history": result.get("conversation_history") or [],
			"state": result.get("state") or state.snapshot(),
			"session_id": sid,
		}
	except HTTPException:
		raise
	except Exception as exc:
		raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.post("/booking/chat")
async def booking_chat(
	body: BookingChatRequest,
	authorization: Optional[str] = Header(default=None),
) -> Dict[str, Any]:
	log.info(
		"[BookingChat] POST /booking/chat booking_id=%s action=%s message=%r",
		body.booking_id,
		body.action,
		body.message,
	)
	request = RunBookingRequest(
		query=body.message,
		session_id=body.booking_id,
		booking_id=body.booking_id,
		action=body.action,
		auto_book=body.auto_book,
		fetch_booking_details=body.fetch_booking_details,
		selected_bus_id=body.selected_bus_id,
		selected_recommendation_id=body.selected_recommendation_id,
		selected_seat_no=body.selected_seat_no,
		booking_preferences=body.booking_preferences,
		passenger_details=body.passenger_details,
	)
	return await run_booking_agent(request, authorization=authorization)


@router.post("/booking/confirm-ticket")
async def confirm_ticket(
	request: Request,
	authorization: Optional[str] = Header(default=None),
) -> Dict[str, Any]:
	"""
	Called by the frontend immediately after POST /book-ticket succeeds.
	Saves the confirmed ticket into the booking session (Supabase bookings row)
	so it can be restored when the user clicks the booking in the sidebar.
	"""
	body: Dict[str, Any] = await request.json()
	session_id: str = str(body.get("session_id") or "").strip()
	ticket: Dict[str, Any] = body.get("ticket") or body.get("booking") or {}
	bus_data: Dict[str, Any] = body.get("bus") or {}

	if not session_id:
		raise HTTPException(status_code=400, detail="session_id is required")

	try:
		state = booking_session_manager.load_session(session_id)

		# Merge real bus fields that may not be in the ticket response
		merged_ticket = {**ticket}
		if bus_data:
			merged_ticket.setdefault("operator", bus_data.get("operator") or bus_data.get("operator_name") or "")
			merged_ticket.setdefault("source", bus_data.get("source") or bus_data.get("origin") or "")
			merged_ticket.setdefault("destination", bus_data.get("destination") or bus_data.get("to") or "")
			merged_ticket.setdefault("departure_time", bus_data.get("departure_time") or "")
			merged_ticket.setdefault("arrival_time", bus_data.get("arrival_time") or "")
			merged_ticket.setdefault("price", bus_data.get("price") or bus_data.get("price_min") or "")
			merged_ticket.setdefault("travel_date", bus_data.get("travel_date") or "")

		provider_booking_id = str(merged_ticket.get("booking_id") or merged_ticket.get("id") or "")
		seat_no = str(merged_ticket.get("seat_no") or merged_ticket.get("seat") or "")
		src = str(merged_ticket.get("source") or state.origin or "")
		dst = str(merged_ticket.get("destination") or state.destination or "")

		# Build a human-readable title from real names
		new_title = f"{src} → {dst}" if src and dst else state.booking_title or "Confirmed Booking"

		# Update the in-memory state
		state.ticket_data = merged_ticket
		state.booking_status = "confirmed"
		state.selected_seat = seat_no
		state.booking_title = new_title
		if src:
			state.origin = src
		if dst:
			state.destination = dst
		state.set_stage("booking_complete")

		# Persist to Supabase
		booking_session_manager.save_session(state)

		log.info(
			"[ConfirmTicket] session=%s provider_booking_id=%s seat=%s route=%s→%s",
			session_id, provider_booking_id, seat_no, src, dst,
		)

		return {
			"ok": True,
			"session_id": session_id,
			"provider_booking_id": provider_booking_id,
			"booking_title": new_title,
			"ticket": merged_ticket,
		}
	except HTTPException:
		raise
	except Exception as exc:
		log.error("[ConfirmTicket] Failed for session=%s: %s", session_id, exc)
		raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.post("/booking/new")

async def booking_new(authorization: Optional[str] = Header(default=None)) -> Dict[str, Any]:
	user_id: str | None = None
	if authorization:
		token = authorization.removeprefix("Bearer ").strip()
		if token:
			try:
				user = await get_user(token)
				user_id = str(user.get("id", "") or "") or None
			except SupabaseError:
				user_id = None
	created = booking_session_manager.create_booking(user_id=user_id, booking_title="New Booking")
	return {"booking_id": created["booking_id"], "booking_title": created["booking_title"]}


@router.get("/booking/list")
async def booking_list(authorization: Optional[str] = Header(default=None)) -> List[Dict[str, Any]]:
	user_id: str | None = None
	if authorization:
		token = authorization.removeprefix("Bearer ").strip()
		if token:
			try:
				user = await get_user(token)
				user_id = str(user.get("id", "") or "") or None
			except SupabaseError as e:
				log.error(f"[BookingList] Auth failed: {e}")
				user_id = None
	log.info(f"[BookingList] Fetching bookings for user_id: {user_id}")
	bookings = booking_session_manager.list_bookings(user_id=user_id)
	log.info(f"[BookingList] Found {len(bookings)} bookings")
	return [
		{
			"booking_id": row.get("id") or row.get("booking_id") or row.get("session_id") or "",
			"title": row.get("booking_title") or row.get("title") or _title_from_row(row),
			"travel_date": row.get("travel_date") or "",
			"updated_at": row.get("updated_at") or row.get("created_at") or "",
			"booking_stage": row.get("booking_stage") or "",
			"booking_status": row.get("booking_status") or row.get("status") or "active",
			"ticket": row.get("ticket_data") or None,
			"source": row.get("source") or row.get("origin") or "",
			"destination": row.get("destination") or "",
		}
		for row in bookings
		if isinstance(row, dict)
	]


@router.get("/state/{session_id}")
def get_state(session_id: str) -> Dict[str, Any]:
	try:
		state = booking_session_manager.load_session(session_id)
		state_data = state.snapshot() if hasattr(state, "snapshot") else dict(state.__dict__)
		return {"session_id": session_id, "state": state_data}
	except Exception as exc:
		raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.get("/booking/session/{session_id}")
def restore_booking(session_id: str) -> Dict[str, Any]:
	try:
		data = booking_session_manager.restore_booking_session(session_id)
		if data.get("status") == "expired":
			return data
		return data
	except Exception as exc:
		raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.get("/booking/{booking_id}")
def get_booking(booking_id: str) -> Dict[str, Any]:
	try:
		return _provider.get_booking(booking_id)
	except Exception as exc:
		raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.post("/cancel-booking/{booking_id}")
def cancel_booking(booking_id: str) -> Dict[str, Any]:
	try:
		return _provider.cancel_booking(booking_id)
	except Exception as exc:
		raise HTTPException(status_code=502, detail=str(exc)) from exc

