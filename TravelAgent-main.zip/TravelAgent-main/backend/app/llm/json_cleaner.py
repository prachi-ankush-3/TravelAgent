"""LLM JSON cleaner and normalizer.

Provides helpers to normalise keys produced by the LLM so the rest of the
pipeline can rely on a single canonical field naming convention.

Currently handles:
- "travelers" -> "num_travelers"
- "trip_type" -> "travel_style"

This module is intentionally small and deterministic.
"""
from typing import Any, Dict


def normalize_llm_keys(data: Dict[str, Any]) -> Dict[str, Any]:
    """Return a copy of `data` with canonical keys.

    Rules:
    - If `num_travelers` missing but `travelers` present, move value to `num_travelers`.
    - If both present, prefer `num_travelers` when it is not None; otherwise use `travelers`.
    - Same for `travel_style` vs `trip_type`.
    - Normalize `budget` to `{"total_budget": <numeric>}` format.
    - Remove the legacy keys (`travelers`, `trip_type`) from the returned dict.
    """
    if not isinstance(data, dict):
        return data

    out = dict(data)  # shallow copy

    # travellers -> num_travelers
    if "num_travelers" not in out and "travelers" in out:
        out["num_travelers"] = out.get("travelers")
    elif "num_travelers" in out and "travelers" in out:
        if out.get("num_travelers") is None and out.get("travelers") is not None:
            out["num_travelers"] = out.get("travelers")

    # trip_type -> travel_style
    if "travel_style" not in out and "trip_type" in out:
        out["travel_style"] = out.get("trip_type")
    elif "travel_style" in out and "trip_type" in out:
        if out.get("travel_style") is None and out.get("trip_type") is not None:
            out["travel_style"] = out.get("trip_type")

    # budget normalization: convert raw numeric to {"total_budget": <value>}
    if "budget" in out:
        budget_val = out.get("budget")
        if isinstance(budget_val, dict):
            # Already in dict form (e.g., {"total_budget": 15000}), keep as is
            pass
        elif isinstance(budget_val, (int, float)) and budget_val is not None:
            # Convert raw number to structured form
            out["budget"] = {"total_budget": float(budget_val)}
        elif budget_val is None:
            # Preserve None
            out["budget"] = {"total_budget": None}

    # Remove legacy keys if present
    out.pop("travelers", None)
    out.pop("trip_type", None)

    return out
