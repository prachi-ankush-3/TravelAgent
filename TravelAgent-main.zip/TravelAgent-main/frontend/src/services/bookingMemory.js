const BOOKING_MEMORY_KEY = 'travagent_booking_memory';

function readMemory() {
	try {
		const raw = localStorage.getItem(BOOKING_MEMORY_KEY);
		if (!raw) return {};
		const parsed = JSON.parse(raw);
		return parsed && typeof parsed === 'object' ? parsed : {};
	} catch {
		return {};
	}
}

function writeMemory(nextValue) {
	try {
		localStorage.setItem(BOOKING_MEMORY_KEY, JSON.stringify(nextValue || {}));
	} catch {
		// Ignore storage failures in private browsing / disabled storage.
	}
}

export function getBookingMemory() {
	return readMemory();
}

export function saveBookingMemory(patch = {}) {
	const current = readMemory();
	const nextValue = {
		...current,
		...patch,
		updated_at: new Date().toISOString(),
	};
	writeMemory(nextValue);
	return nextValue;
}

export function getBookingPreferences() {
	const memory = readMemory();
	const seatPreference = String(memory.seat_preference || '').toLowerCase();
	return {
		window_seat: seatPreference === 'window',
		sleeper: seatPreference === 'sleeper',
		front: seatPreference === 'front',
		lower_berth: seatPreference === 'lower',
		preferred_bus_type: memory.preferred_bus_type || '',
		preferred_operator: memory.preferred_operator || '',
		travel_style: memory.travel_style || '',
	};
}
