"""Direct runner script for BookingAgent.

This script accepts a normal sentence, runs LLM extraction, asks follow-up
questions only if essential booking fields are missing, then runs BookingAgent.

Run from backend directory:
    C:/Users/Lenovo/AppData/Local/Python/pythoncore-3.14-64/python.exe -m app.agents.booking.run_booking_agent "book a bus from kolhapur to mumbai tomorrow"

Examples:
    # Recommendation only (human-in-the-loop)
    C:/Users/Lenovo/AppData/Local/Python/pythoncore-3.14-64/python.exe -m app.agents.booking.run_booking_agent "book a bus from mumbai to pune on 2026-05-23"

    # Auto-book with passenger details
    C:/Users/Lenovo/AppData/Local/Python/pythoncore-3.14-64/python.exe -m app.agents.booking.run_booking_agent "book a sleeper bus from mumbai to pune on 2026-05-23" --auto-book --name Parth --age 20 --gender Male --phone 9999999999 --fetch-booking-details
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from datetime import date, timedelta
from typing import Any, Dict

import httpx

# Support running this file directly from inside the booking folder.
# Example: python .\run_booking_agent.py ...
if __package__ in {None, ""}:
    backend_root = Path(__file__).resolve().parents[3]
    if str(backend_root) not in sys.path:
        sys.path.insert(0, str(backend_root))

from app.agents.booking.booking_agent import BookingAgent
from app.core.config import (
    LM_STUDIO_CHAT_ENDPOINT,
    LM_STUDIO_MODEL,
    LLM_MAX_TOKENS,
    LLM_REQUEST_TIMEOUT,
    LLM_TEMPERATURE,
)
from app.core.prompts import TRAVEL_PLANNER_SYSTEM_PROMPT
from app.llm.json_cleaner import normalize_llm_keys
from app.state.session_manager import session_manager


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run BookingAgent directly")
    parser.add_argument("--session-id", default="booking-cli-session")
    parser.add_argument("query", nargs="?", default="", help="Natural-language booking request")
    parser.add_argument("--source")
    parser.add_argument("--destination")
    parser.add_argument("--date", help="Travel date YYYY-MM-DD")
    parser.add_argument("--budget", type=float)

    # Preference flags
    parser.add_argument("--window-seat", action="store_true")
    parser.add_argument("--sleeper", action="store_true")
    parser.add_argument("--comfort-priority", action="store_true")
    parser.add_argument("--safety-priority", action="store_true")
    parser.add_argument("--cheapest-priority", action="store_true")
    parser.add_argument("--motion-sickness", action="store_true")
    parser.add_argument("--elderly", action="store_true")
    parser.add_argument("--peaceful-sleep", action="store_true")
    parser.add_argument("--ac-only", action="store_true")
    parser.add_argument("--min-rating", type=float, default=1.0)

    # Booking mode
    parser.add_argument("--auto-book", action="store_true", help="Execute booking immediately")
    parser.add_argument("--fetch-booking-details", action="store_true")

    # Passenger details (required only for --auto-book)
    parser.add_argument("--name", default="")
    parser.add_argument("--age", type=int, default=0)
    parser.add_argument("--gender", default="")
    parser.add_argument("--phone", default="")
    return parser.parse_args()


def _ask(prompt: str, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    value = input(f"{prompt}{suffix}: ").strip()
    return value or default


def _extract_llm_json(query: str) -> Dict[str, Any]:
    from app.core.logger import get_logger

    log = get_logger(__name__)
    log.info("[BookingLLM] Calling LM Studio at %s (model=%s)", LM_STUDIO_CHAT_ENDPOINT, LM_STUDIO_MODEL)
    log.info("[BookingLLM] User message: %r", query)

    payload = {
        "model": LM_STUDIO_MODEL,
        "messages": [
            {"role": "system", "content": TRAVEL_PLANNER_SYSTEM_PROMPT},
            {"role": "user", "content": query},
        ],
        "max_tokens": LLM_MAX_TOKENS,
        "temperature": LLM_TEMPERATURE,
    }

    with httpx.Client(timeout=LLM_REQUEST_TIMEOUT) as client:
        response = client.post(LM_STUDIO_CHAT_ENDPOINT, json=payload)
        response.raise_for_status()

    llm_data = response.json()
    raw_text: str = llm_data["choices"][0]["message"]["content"].strip()
    log.info("[BookingLLM] Raw LLM response (first 500 chars): %s", raw_text[:500])

    if raw_text.startswith("```"):
        raw_text = raw_text.split("```", 1)[1]
        if raw_text.startswith("json"):
            raw_text = raw_text[4:]
        raw_text = raw_text.strip()

    parsed = json.loads(raw_text)
    normalized = normalize_llm_keys(parsed)
    log.info("[BookingLLM] Parsed extraction: %s", normalized)
    return normalized


def _parse_date_from_query(query: str) -> str | None:
    match = re.search(r"\b(\d{4}-\d{2}-\d{2})\b", query)
    return match.group(1) if match else None


def _resolve_natural_date(value: Any) -> str | None:
    if value is None:
        return None

    text = str(value).strip().lower()
    if not text:
        return None
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", text):
        return text
    if text in {"today", "todays"}:
        return date.today().isoformat()
    if text in {"tomorrow", "tmrw", "tommorrow", "tomarrow"}:
        return (date.today() + timedelta(days=1)).isoformat()
    if text in {"day after tomorrow", "after tomorrow"}:
        return (date.today() + timedelta(days=2)).isoformat()
    return None


def _first_present(*values: Any) -> Any:
    for value in values:
        if value not in (None, ""):
            return value
    return None


def _build_booking_intent(args: argparse.Namespace) -> Dict[str, Any]:
    query = args.query.strip()
    if not query:
        query = _ask("Enter your bus booking request")

    extracted: Dict[str, Any] = {}
    try:
        extracted = _extract_llm_json(query)
        print("Extracted booking fields:")
        print(json.dumps(extracted, indent=2, ensure_ascii=False))
    except Exception as exc:
        print(f"LLM extraction failed, falling back to interactive prompts: {exc}")

    source = _first_present(
        args.source,
        extracted.get("source"),
        extracted.get("origin"),
        extracted.get("departure_location"),
    ) or _ask("From which city")

    destination = _first_present(
        args.destination,
        extracted.get("destination"),
        extracted.get("arrival_location"),
    ) or _ask("To which city")

    extracted_date = _first_present(
        args.date,
        (extracted.get("travel_dates") or {}).get("start") if isinstance(extracted.get("travel_dates"), dict) else None,
        extracted.get("travel_date"),
        extracted.get("date_of_departure"),
        extracted.get("departure_date"),
        _parse_date_from_query(query),
    )
    date_value = _resolve_natural_date(extracted_date) or _ask("Travel date YYYY-MM-DD")

    budget_value = args.budget
    if budget_value is None:
        budget_raw = extracted.get("budget")
        if isinstance(budget_raw, dict):
            budget_value = budget_raw.get("transport_budget") or budget_raw.get("total_budget")
        elif isinstance(budget_raw, (int, float)):
            budget_value = float(budget_raw)
    if budget_value is None:
        budget_text = _ask("Budget (INR)", "1500")
        try:
            budget_value = float(budget_text)
        except ValueError:
            budget_value = 1500.0

    preferences: Dict[str, Any] = {
        "window_seat": args.window_seat,
        "sleeper": args.sleeper,
        "comfort_priority": args.comfort_priority,
        "safety_priority": args.safety_priority,
        "cheapest_priority": args.cheapest_priority,
        "motion_sickness": args.motion_sickness,
        "elderly": args.elderly,
        "peaceful_sleep": args.peaceful_sleep,
        "ac_only": args.ac_only,
        "min_rating": args.min_rating,
    }

    extracted_prefs = extracted.get("preferences")
    if isinstance(extracted_prefs, list):
        pref_text = " ".join(str(item).lower() for item in extracted_prefs)
        if "window" in pref_text:
            preferences["window_seat"] = True
        if "sleeper" in pref_text:
            preferences["sleeper"] = True
        if any(term in pref_text for term in ["comfort", "luxury", "premium"]):
            preferences["comfort_priority"] = True

    passenger = _build_passenger_details(args, extracted, prompt_for_missing=args.auto_book)

    return {
        "source": source,
        "destination": destination,
        "travel_date": str(date_value),
        "budget": float(budget_value),
        "preferences": preferences,
        "passenger_details": passenger,
        "_extracted": extracted,
    }


def _build_passenger_details(args: argparse.Namespace, extracted: Dict[str, Any], prompt_for_missing: bool) -> Dict[str, Any] | None:
    values: Dict[str, Any] = {
        "passenger_name": _first_present(args.name, extracted.get("passenger_name"), extracted.get("name")),
        "passenger_age": _first_present(args.age or None, extracted.get("passenger_age"), extracted.get("age")),
        "passenger_gender": _first_present(args.gender, extracted.get("passenger_gender"), extracted.get("gender")),
        "phone_number": _first_present(args.phone, extracted.get("phone_number"), extracted.get("phone")),
    }

    if not prompt_for_missing:
        # Keep whatever the extractor already found without asking extra questions.
        cleaned = {k: v for k, v in values.items() if v not in (None, "")}
        return cleaned or None

    if not values.get("passenger_name"):
        values["passenger_name"] = _ask("Passenger name")
    if not values.get("passenger_age"):
        values["passenger_age"] = int(_ask("Passenger age", "20"))
    if not values.get("passenger_gender"):
        values["passenger_gender"] = _ask("Passenger gender", "Male")
    if not values.get("phone_number"):
        values["phone_number"] = _ask("Phone number")

    return values


def _prepare_state(args: argparse.Namespace):
    intent = _build_booking_intent(args)
    state = session_manager.get_or_create(args.session_id)
    state.origin = intent["source"]
    state.destination = intent["destination"]
    state.travel_dates = {"start": intent["travel_date"]}
    state.budget = {"transport_budget": intent["budget"]}
    state.booking_preferences = intent["preferences"]
    if intent.get("passenger_details"):
        state.passenger_details = intent["passenger_details"]
    return state, intent


def main() -> None:
    args = _parse_args()
    state, intent = _prepare_state(args)

    result = BookingAgent().run(
        state,
        auto_book=args.auto_book,
        passenger_details=intent.get("passenger_details"),
        fetch_booking_details=args.fetch_booking_details,
    )

    if result.get("requires_confirmation") and not args.auto_book:
        print(json.dumps(result, indent=2, ensure_ascii=False))
        answer = _ask("Proceed with booking? (y/n)", "n").strip().lower()
        if answer in {"y", "yes"}:
            passenger_details = _build_passenger_details(
                args,
                intent.get("_extracted") or {},
                prompt_for_missing=True,
            )
            result = BookingAgent().run(
                state,
                auto_book=True,
                passenger_details=passenger_details,
                fetch_booking_details=args.fetch_booking_details,
            )

    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
