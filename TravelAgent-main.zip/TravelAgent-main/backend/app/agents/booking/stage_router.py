from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from app.agents.booking.booking_stage import BookingStage, normalize_stage


BookingAction = Literal["search", "seat", "book", "view", "question"]


@dataclass(frozen=True)
class StageRoutingResult:
	allowed: bool
	action: BookingAction
	reason: str = ""


def route_stage_action(stage: BookingStage | str, action: str) -> StageRoutingResult:
	normalized_stage = normalize_stage(stage)
	requested = str(action or "").strip().lower()

	if normalized_stage == BookingStage.awaiting_bus_selection:
		if not requested or requested in {"search", "seat", "view", "question"}:
			return StageRoutingResult(True, requested or "view")
		return StageRoutingResult(False, "question", "Bus selection is active; booking is blocked until a bus is chosen.")

	if normalized_stage == BookingStage.awaiting_seat_preference:
		if not requested or requested in {"seat", "book", "question"}:
			return StageRoutingResult(True, requested or "seat")
		return StageRoutingResult(False, "question", "Share your seat preference before starting a new search.")

	if normalized_stage == BookingStage.awaiting_seat_confirmation:
		if not requested or requested in {"book", "seat", "question"}:
			return StageRoutingResult(True, requested or "question")
		return StageRoutingResult(False, "question", "Seat confirmation is active; route extraction and bus ranking are blocked.")

	if normalized_stage == BookingStage.booking_in_progress:
		if not requested or requested in {"book", "question"}:
			return StageRoutingResult(True, requested or "book")
		return StageRoutingResult(False, "question", "Booking is already in progress.")

	if normalized_stage == BookingStage.booking_complete:
		if not requested or requested in {"search", "question"}:
			return StageRoutingResult(True, requested or "question")
		return StageRoutingResult(False, "question", "This booking is complete. Start a new booking for another trip.")

	return StageRoutingResult(True, requested or "search")