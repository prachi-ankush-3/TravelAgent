"""ItineraryAgent — assembles a structured, budget-aware travel plan.

Reads recommendations from ExploreAgent, HotelAgent, and BudgetAgent,
then uses the itinerary builder and optimizer to generate a structured day-by-day
schedule that the frontend can render directly.
"""
from __future__ import annotations

from typing import Any, Dict, List

from app.core.config import ENABLE_ITINERARY_BEAUTIFICATION
from app.agents.itinerary.itinerary_beautifier import beautify_itinerary
from app.state.session_manager import session_manager
from app.state.memory_handler import mark_stage_done
from app.agents.itinerary.itinerary_builder import ItineraryBuilder


class ItineraryAgent:
    """Assembles final travel itinerary from agent recommendations."""

    def run(self, state) -> Dict[str, Any]:
        """Build a structured itinerary from previous agent outputs."""
        destination = getattr(state, "destination", None)
        duration_days = getattr(state, "duration_days", None) or 1
        places = getattr(state, "suggested_places", []) or []
        hotels = getattr(state, "suggested_hotels", []) or []
        budget_daily = getattr(state, "budget_daily", {}) or {}
        budget = getattr(state, "budget", None)
        interests = getattr(state, "interests", []) or []
        travel_style = getattr(state, "travel_style", None)

        selected_hotel = getattr(state, "selected_hotel", None)
        if not selected_hotel and hotels:
            selected_hotel = hotels[0]

        if not destination or not places:
            return {
                "error": "insufficient_data",
                "detail": "Need destination and place recommendations from ExploreAgent",
            }

        builder = ItineraryBuilder()
        plan = builder.build_itinerary(
            destination=destination,
            duration_days=duration_days,
            places=places,
            selected_hotel=selected_hotel,
            budget=budget,
            budget_daily=budget_daily,
            travel_style=travel_style,
            interests=interests,
        )

        itinerary = plan["itinerary"]
        daily_schedule = plan["daily_schedule"]
        itinerary_summary = plan.get("itinerary_summary", {})
        beautified_guide = beautify_itinerary(
            daily_schedule,
            destination=destination,
            enabled=ENABLE_ITINERARY_BEAUTIFICATION,
        )

        # Update state
        state_obj = session_manager.get_or_create(state.session_id)
        state_obj.itinerary = itinerary
        state_obj.daily_schedule = daily_schedule
        state_obj.itinerary_summary = itinerary_summary
        state_obj.suggested_activities = itinerary
        state_obj.plan_ready = True
        state_obj.itinerary_guide = beautified_guide
        mark_stage_done(state.session_id, "plan")

        return {
            "itinerary": itinerary,
            "daily_schedule": daily_schedule,
            "itinerary_summary": itinerary_summary,
            "itinerary_guide": beautified_guide,
            "days_planned": len(itinerary),
            "destination": destination,
        }


def run_for_session(session_id: str) -> Dict[str, Any]:
    state = session_manager.get_or_create(session_id)
    return ItineraryAgent().run(state)
