"""BudgetAgent — financial planning and feasibility intelligence.

Reads shared state, calculates budget allocations, hotel/activity constraints,
and feasibility analysis, then updates state to guide downstream agents.
"""
from __future__ import annotations

from typing import Any, Dict

from app.state.session_manager import session_manager
from app.state.memory_handler import update_state, mark_stage_done
from app.agents.budget.budget_optimizer import (
    extract_numeric_budget,
    calculate_budget_allocation,
    calculate_per_day_budget,
    calculate_hotel_constraints,
    analyze_feasibility,
)


class BudgetAgent:
    def run(self, state) -> Dict[str, Any]:
        """Analyze budget constraints and update state.
        
        Expects state to have:
        - budget (dict or numeric)
        - duration_days
        - num_travelers
        - destination
        - travel_style (optional)
        """
        total_budget = extract_numeric_budget(getattr(state, "budget", None))
        if not total_budget or total_budget < 100:
            return {"error": "invalid_budget", "detail": "Budget must be at least 100 INR"}

        duration_days = getattr(state, "duration_days", None) or 1
        num_travelers = getattr(state, "num_travelers", None) or 1
        destination = getattr(state, "destination", None)
        travel_style = getattr(state, "travel_style", None)

        # Calculate allocations
        allocation = calculate_budget_allocation(
            total_budget,
            duration_days=duration_days,
            num_travelers=num_travelers,
            destination=destination,
        )

        # Calculate per-day budgets
        per_day = calculate_per_day_budget(
            total_budget,
            duration_days=duration_days,
            num_travelers=num_travelers,
        )

        # Calculate hotel constraints (max price per night)
        hotel_constraints = calculate_hotel_constraints(
            total_budget,
            duration_days=duration_days,
            allocation_percentage=0.45,
        )

        # Analyze feasibility
        feasibility = analyze_feasibility(
            total_budget,
            duration_days=duration_days,
            num_travelers=num_travelers,
            destination=destination,
            travel_style=travel_style,
        )

        # Build budget breakdown for state
        budget_breakdown = {
            "total_budget": total_budget,
            "hotel_budget": allocation["hotel"],
            "food_budget": allocation["food"],
            "activities_budget": allocation["activities"],
            "transport_budget": allocation["transport"],
            "misc_budget": allocation["misc"],
        }

        # Prepare the update dict with all computed values
        state_updates = {
            "budget": budget_breakdown,
            "budget_daily": per_day,
            "budget_feasibility": {
                "is_feasible": feasibility["is_feasible"],
                "affordability_level": feasibility["affordability_level"],
                "per_person_per_day": feasibility["per_person_per_day"],
                "warnings": feasibility["warnings"],
                "suggestions": feasibility["suggestions"],
            },
        }
        
        # Update the state
        update_state(state.session_id, state_updates)
        
        # Update hotel preferences separately since it's a nested object
        state_obj = session_manager.get_or_create(state.session_id)
        if state_obj.hotel_preferences:
            state_obj.hotel_preferences.max_price_per_night = hotel_constraints["max_price_per_night"]
        
        mark_stage_done(state.session_id, "budget")

        return {
            "budget_allocation": budget_breakdown,
            "per_day_budget": per_day,
            "hotel_constraints": hotel_constraints,
            "feasibility": feasibility,
        }


def run_for_session(session_id: str) -> Dict[str, Any]:
    state = session_manager.get_or_create(session_id)
    return BudgetAgent().run(state)
