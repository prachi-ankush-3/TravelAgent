# app/models/state_models.py
# Pydantic schema for the GlobalTravelState
# This is the single source of truth shared across all agents.

from __future__ import annotations
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field


class HotelPreferences(BaseModel):
    """Preferences collected by the Hotel Agent."""
    star_rating: Optional[int] = None          # e.g. 3, 4, 5
    max_price_per_night: Optional[float] = None
    amenities: List[str] = Field(default_factory=list)  # e.g. ["pool", "wifi"]
    preferred_area: Optional[str] = None


class BudgetBreakdown(BaseModel):
    """Budget details populated by the Budget Agent."""
    total_budget: Optional[float] = None
    transport_budget: Optional[float] = None
    hotel_budget: Optional[float] = None
    food_budget: Optional[float] = None
    activities_budget: Optional[float] = None
    misc_budget: Optional[float] = None


class TravelStateModel(BaseModel):
    """
    Central memory object that all agents read from and write to.
    Every field is Optional so agents can partially populate it.
    """

    # ── Session ───────────────────────────────────────────────────────────────
    session_id: str = ""                        # Unique ID per user session
    created_at: Optional[str] = None            # ISO timestamp

    # ── Core Trip Info (from user query + LLM extraction) ─────────────────────
    raw_query: Optional[str] = None             # Original user text
    destination: Optional[str] = None           # e.g. "Goa"
    origin: Optional[str] = None                # e.g. "Mumbai"
    duration_days: Optional[int] = None         # e.g. 4
    travel_dates: Optional[Dict[str, str]] = None  # {"start": "2025-12-01", "end": "2025-12-05"}
    num_travelers: Optional[int] = None         # e.g. 2
    travel_style: Optional[str] = None          # e.g. "budget", "luxury", "adventure"

    # ── Budget (Budget Agent) ──────────────────────────────────────────────────
    budget: Optional[BudgetBreakdown] = Field(default_factory=BudgetBreakdown)
    budget_daily: Optional[Dict[str, float]] = None  # per_day_total, per_person_per_day
    budget_feasibility: Optional[Dict[str, Any]] = None  # is_feasible, warnings, suggestions

    # ── Hotel (Hotel Agent) ────────────────────────────────────────────────────
    hotel_preferences: Optional[HotelPreferences] = Field(default_factory=HotelPreferences)
    selected_hotel: Optional[Dict[str, Any]] = None   # Final hotel chosen
    suggested_hotels: List[Dict[str, Any]] = Field(default_factory=list)

    # ── Explore / Activities (Explore Agent) ──────────────────────────────────
    interests: List[str] = Field(default_factory=list)  # e.g. ["beaches", "nightlife"]
    suggested_activities: List[Dict[str, Any]] = Field(default_factory=list)
    suggested_places: List[Dict[str, Any]] = Field(default_factory=list)

    # ── Itinerary (Itinerary Agent) ───────────────────────────────────────────
    itinerary: List[Dict[str, Any]] = Field(default_factory=list)
    daily_schedule: Dict[str, Any] = Field(default_factory=dict)
    itinerary_summary: Dict[str, Any] = Field(default_factory=dict)

    # ── Bus Booking (Booking Agent) ───────────────────────────────────────────
    booking_intent: Optional[Dict[str, Any]] = None
    booking_preferences: Optional[Dict[str, Any]] = None
    suggested_buses: List[Dict[str, Any]] = Field(default_factory=list)
    selected_bus: Optional[Dict[str, Any]] = None
    seat_recommendation: Optional[Dict[str, Any]] = None
    selected_seat: Optional[Dict[str, Any]] = None
    booking_recommendation: Optional[Dict[str, Any]] = None
    booking_status: Optional[str] = None
    ticket: Optional[Dict[str, Any]] = None
    booking_details: Optional[Dict[str, Any]] = None

    # ── LLM Raw Output (stored for debugging / audit) ─────────────────────────
    llm_responses: List[Dict[str, Any]] = Field(default_factory=list)

    # ── Pipeline Flags ────────────────────────────────────────────────────────
    extraction_done: bool = False   # LLM parsed the query
    explore_done: bool = False       # Explore Agent finished
    budget_done: bool = False        # Budget Agent finished
    hotel_done: bool = False         # Hotel Agent finished
    booking_done: bool = False       # Booking Agent finished
    plan_ready: bool = False         # Itinerary Agent finished (compatibility)
    plan_done: bool = False          # Full plan assembled (ItineraryAgent finished)

    class Config:
        # Allow extra fields so future agents can add their own keys
        extra = "allow"
