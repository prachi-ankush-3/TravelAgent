import api, { accessTokenKey } from './api';

function persistAuth(session) {
  const token = session?.access_token;
  if (token) {
    localStorage.setItem(accessTokenKey, token);
  }
  localStorage.setItem('travagent_auth_session', JSON.stringify(session || {}));
}

export async function signup(payload) {
  const response = await api.post('/auth/signup', payload);
  persistAuth(response.data.session);
  return response.data;
}

export async function login(payload) {
  const response = await api.post('/auth/login', payload);
  persistAuth(response.data.session);
  return response.data;
}

export function clearAuth() {
  localStorage.removeItem(accessTokenKey);
  localStorage.removeItem('travagent_auth_session');
}

export async function getCurrentProfile() {
  const response = await api.get('/auth/me');
  return response.data;
}

export async function updateCurrentProfile(payload) {
  const response = await api.put('/auth/me/profile', payload);
  return response.data;
}