import { create } from 'zustand';
import { bookingService } from '../services/bookingService';

const ACTIVE_BOOKING_KEY = 'travagent_active_booking_id';

function readActiveBookingId() {
	try {
		return localStorage.getItem(ACTIVE_BOOKING_KEY) || '';
	} catch {
		return '';
	}
}

function saveActiveBookingId(bookingId) {
	try {
		if (bookingId) {
			localStorage.setItem(ACTIVE_BOOKING_KEY, bookingId);
		} else {
			localStorage.removeItem(ACTIVE_BOOKING_KEY);
		}
	} catch {
		// Ignore storage failures.
	}
}

function toRenderedMessages(response, bookingId) {
	const history = Array.isArray(response?.messages) ? response.messages : [];
	const renderedHistory = history.map((entry) => ({
		type: entry.role === 'user' ? 'user' : 'ai',
		text: entry.message || '',
		sessionId: bookingId,
		bookingId,
	}));

	const bookingStage = String(response?.booking_stage || '').toLowerCase();
	const bookingState = response?.booking_state || {};
	const selectedJourney = response?.selected_journey || bookingState?.selected_bus || null;
	const recommendedBuses = Array.isArray(response?.recommended_buses) ? response.recommended_buses : [];
	const ticketInfo = response?.ticket_info || bookingState?.ticket_data || null;

	if (bookingStage === 'booking_complete' && ticketInfo) {
		renderedHistory.push({
			type: 'ai',
			text: 'Your booking has been restored.',
			sessionId: bookingId,
			bookingId,
			cards: [{ type: 'ticket_reveal', data: ticketInfo }],
		});
		return renderedHistory;
	}

	if (bookingStage === 'awaiting_seat_preference' && selectedJourney) {
		renderedHistory.push({
			type: 'ai',
			text: 'Your session was restored. Share your seat preference to continue.',
			sessionId: bookingId,
			bookingId,
			cards: [{
				type: 'seat_preference_prompt',
				data: {
					message: 'Do you have any seating preference like window, front, sleeper, or lower berth?',
					selected_bus: selectedJourney,
					status: 'need_seat_preference',
				},
			}],
		});
		return renderedHistory;
	}

	if (bookingStage === 'awaiting_seat_confirmation' && selectedJourney) {
		renderedHistory.push({
			type: 'ai',
			text: 'Your booking session was restored with the selected bus and seat recommendation.',
			sessionId: bookingId,
			bookingId,
			cards: [{
				type: 'seat_recommendation',
				data: {
					message: 'Continue with the recommended seat?',
					selected_bus: selectedJourney,
					seat_recommendation: bookingState?.recommended_seat || { seat_no: bookingState?.selected_seat || '' },
					seat_layout: response?.seat_layout || null,
				},
			}],
		});
		return renderedHistory;
	}

	if (
		(bookingStage === 'awaiting_bus_selection' || bookingStage === 'recommendations_shown' || bookingStage === 'searching_buses')
		&& recommendedBuses.length > 0
	) {
		renderedHistory.push({
			type: 'ai',
			text: 'Your recommendations were restored.',
			sessionId: bookingId,
			bookingId,
			cards: [{
				type: 'bus_recommendation_bundle',
				data: {
					message: 'Your earlier recommendations have been restored.',
					recommended_buses: recommendedBuses,
					all_buses: recommendedBuses,
					workflow: response?.workflow || [],
					selected_bus: selectedJourney,
					seat_recommendation: bookingState?.recommended_seat || null,
					seat_layout: response?.seat_layout || null,
					ticket: ticketInfo,
					booking: ticketInfo,
				},
			}],
		});
		return renderedHistory;
	}

	return renderedHistory;
}

const initialState = {
	currentBookingId: readActiveBookingId(),
	messages: [],
	bookingStage: 'idle',
	workflow: [],
	recommendedBuses: [],
	selectedBus: null,
	selectedSeat: '',
	ticketData: null,
	userPreferences: {},
	bookingHistory: [],
	loading: false,
	workspaceInitialized: false,
};

export const useBookingStore = create((set, get) => ({
	...initialState,
	refreshBookingHistory: async () => {
		set({ loading: true });
		try {
			const bookingHistory = await bookingService.listBookings();
			set({ bookingHistory: Array.isArray(bookingHistory) ? bookingHistory : [] });
			return bookingHistory;
		} finally {
			set({ loading: false });
		}
	},
	createBooking: async () => {
		set({ loading: true });
		try {
			const created = await bookingService.createBooking();
			const bookingId = created?.booking_id || '';
			saveActiveBookingId(bookingId);
			set({
				currentBookingId: bookingId,
				messages: [],
				bookingStage: 'idle',
				workflow: [],
				recommendedBuses: [],
				selectedBus: null,
				selectedSeat: '',
				ticketData: null,
				userPreferences: {},
			});
			return created;
		} finally {
			set({ loading: false });
		}
	},
	loadBooking: async (bookingId) => {
		if (!bookingId) return null;
		set({ loading: true });
		try {
			const response = await bookingService.loadBooking(bookingId);
			if (response?.status === 'expired') {
				set({ currentBookingId: '', messages: [], workflow: [], recommendedBuses: [], selectedBus: null, selectedSeat: '', ticketData: null, userPreferences: {}, bookingStage: 'idle' });
				saveActiveBookingId('');
				return response;
			}
			const hydrated = get().hydrateBooking(bookingId, response);
			saveActiveBookingId(bookingId);
			return hydrated;
		} finally {
			set({ loading: false });
		}
	},
	hydrateBooking: (bookingId, response) => {
		const bookingState = response?.booking_state || {};
		const messages = toRenderedMessages(response, bookingId);
		const nextState = {
			currentBookingId: bookingId,
			messages,
			bookingStage: String(response?.booking_stage || 'idle').toLowerCase(),
			workflow: Array.isArray(response?.workflow) ? response.workflow : [],
			recommendedBuses: Array.isArray(response?.recommended_buses) ? response.recommended_buses : [],
			selectedBus: response?.selected_journey || bookingState?.selected_bus || null,
			selectedSeat: bookingState?.selected_seat || '',
			ticketData: response?.ticket_info || bookingState?.ticket_data || null,
			userPreferences: response?.user_preferences || bookingState?.booking_preferences || {},
		};
		set(nextState);
		return nextState;
	},
	appendMessage: (message) => set((state) => ({ messages: [...state.messages, message] })),
	setWorkflow: (workflow) => set({ workflow: Array.isArray(workflow) ? workflow : [] }),
	setSelectedBus: (selectedBus) => set({ selectedBus }),
	setSelectedSeat: (selectedSeat) => set({ selectedSeat }),
	setBookingStage: (bookingStage) => set({ bookingStage }),
	setUserPreferences: (userPreferences) => set({ userPreferences: userPreferences || {} }),
	setBookingHistory: (bookingHistory) => set({ bookingHistory: Array.isArray(bookingHistory) ? bookingHistory : [] }),
	setCurrentBookingId: (bookingId) => {
		saveActiveBookingId(bookingId || '');
		set({ currentBookingId: bookingId || '' });
	},
	clearBooking: () => {
		saveActiveBookingId('');
		set({
			currentBookingId: '',
			messages: [],
			bookingStage: 'idle',
			workflow: [],
			recommendedBuses: [],
			selectedBus: null,
			selectedSeat: '',
			ticketData: null,
		});
	},
	initializeWorkspace: async () => {
		set({ loading: true });
		try {
			await get().refreshBookingHistory();
			const activeBookingId = get().currentBookingId;
			const history = get().bookingHistory;

			if (activeBookingId) {
				await get().loadBooking(activeBookingId);
			} else if (history.length > 0) {
				const firstBooking = history[0];
				const bookingId = firstBooking.booking_id || firstBooking.id || firstBooking.session_id;
				if (bookingId) {
					await get().loadBooking(bookingId);
				} else {
					await get().createBooking();
				}
			} else {
				await get().createBooking();
			}
			set({ workspaceInitialized: true });
			return get().currentBookingId;
		} catch (error) {
			console.warn('Could not bootstrap booking workspace', error);
			if (!get().currentBookingId) {
				await get().createBooking();
			}
			set({ workspaceInitialized: true });
			return get().currentBookingId;
		} finally {
			set({ loading: false });
		}
	},
}));