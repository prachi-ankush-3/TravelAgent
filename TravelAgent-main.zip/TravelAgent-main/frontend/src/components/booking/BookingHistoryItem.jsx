import React from 'react';
import { MapPin, CalendarDays, Ticket } from 'lucide-react';

function formatDateLabel(value) {
	if (!value) return '';
	const date = new Date(value);
	if (Number.isNaN(date.getTime())) return '';
	return date.toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
}

export default function BookingHistoryItem({ item, active = false, onClick }) {
	const title = item?.title || 'Untitled Booking';
	const travelDate = formatDateLabel(item?.travel_date || item?.updated_at);
	const route = [item?.source, item?.destination].filter(Boolean).join(' → ');
	const status = String(item?.booking_status || 'saved').replace(/_/g, ' ');

	return (
		<button
			type="button"
			onClick={onClick}
			style={{
				width: '100%',
				textAlign: 'left',
				padding: '12px 14px',
				borderRadius: '14px',
				border: `1px solid ${active ? 'rgba(255,159,67,0.45)' : 'rgba(255,255,255,0.06)'}`,
				background: active ? 'rgba(255,159,67,0.12)' : 'rgba(255,255,255,0.03)',
				color: 'white',
				cursor: 'pointer',
				display: 'flex',
				flexDirection: 'column',
				gap: '6px',
			}}
		>
			<div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '12px' }}>
				<div style={{ fontSize: '14px', fontWeight: 700, lineHeight: 1.2 }}>{title}</div>
				{status === 'confirmed' ? (
					<div style={{ fontSize: '11px', padding: '4px 8px', borderRadius: '999px', background: 'rgba(16,185,129,0.18)', color: '#34d399', whiteSpace: 'nowrap', fontWeight: 600 }}>
						Confirmed ✓
					</div>
				) : (
					<div style={{ fontSize: '11px', padding: '4px 8px', borderRadius: '999px', background: active ? 'rgba(255,159,67,0.18)' : 'rgba(255,255,255,0.05)', color: active ? '#ffd6b0' : 'var(--text-muted)', whiteSpace: 'nowrap' }}>
						{status}
					</div>
				)}
			</div>
			{route ? (
				<div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '12px', color: 'var(--text-main)' }}>
					<MapPin size={12} color="var(--accent-orange)" />
					<span>{route}</span>
				</div>
			) : null}
			<div style={{ display: 'flex', alignItems: 'center', gap: '12px', fontSize: '12px', color: 'var(--text-muted)' }}>
				<span style={{ display: 'inline-flex', alignItems: 'center', gap: '5px' }}><CalendarDays size={12} /> {travelDate || 'Recently updated'}</span>
				{item?.selected_seat ? <span style={{ display: 'inline-flex', alignItems: 'center', gap: '5px' }}><Ticket size={12} /> Seat {item.selected_seat}</span> : null}
			</div>
		</button>
	);
}