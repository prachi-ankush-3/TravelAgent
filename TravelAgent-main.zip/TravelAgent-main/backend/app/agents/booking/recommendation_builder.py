"""Formatting helpers for bus recommendation and booking responses."""
from __future__ import annotations

from typing import Any, Dict, List

from app.agents.booking.booking_stage import BookingStage, build_workflow as build_stage_workflow, normalize_stage


def _price(bus: Dict[str, Any]) -> float:
	try:
		return float(bus.get("price") or bus.get("price_min") or 0)
	except (TypeError, ValueError):
		return 0.0


def _rating(bus: Dict[str, Any]) -> float:
	try:
		return float(bus.get("rating") or 0)
	except (TypeError, ValueError):
		return 0.0


def _bus_title(bus: Dict[str, Any]) -> str:
	return str(bus.get("operator") or bus.get("operator_name") or bus.get("travels") or bus.get("name") or "Trusted Operator")


def _bus_id(bus: Dict[str, Any]) -> str:
	return str(bus.get("bus_id") or bus.get("id") or bus.get("vehicle_id") or "")


def build_recommendation_card(bus: Dict[str, Any]) -> Dict[str, Any]:
	return {
		"type": "bus",
		"recommendation_id": bus.get("recommendation_id") or bus.get("bus_id") or bus.get("id") or "",
		"bus_id": _bus_id(bus),
		"rank_label": bus.get("rank_label") or "Smart Match",
		"headline": bus.get("headline") or "AI matched",
		"operator": _bus_title(bus),
		"bus_type": bus.get("bus_type") or bus.get("type") or "Bus",
		"price": _price(bus),
		"rating": _rating(bus),
		"departure_time": bus.get("departure_time") or "",
		"arrival_time": bus.get("arrival_time") or "",
		"available_seats": bus.get("available_seats") or 0,
		"amenities": bus.get("amenities") or [],
		"reason": bus.get("reason") or "Matched to your trip profile.",
		"score_breakdown": bus.get("score_breakdown") or {},
		"final_score": bus.get("final_score") or 0,
	}


def build_recommendation_response(
	*,
	message: str,
	recommended_buses: List[Dict[str, Any]],
	all_buses: List[Dict[str, Any]],
	workflow: List[Dict[str, Any]],
	status: str,
	selected_bus: Dict[str, Any] | None = None,
	seat_recommendation: Dict[str, Any] | None = None,
	seat_layout: Dict[str, Any] | None = None,
	ticket: Dict[str, Any] | None = None,
	booking: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
	payload: Dict[str, Any] = {
		"message": message,
		"status": status,
		"recommended_buses": recommended_buses,
		"all_buses": all_buses,
		"workflow": workflow,
	}
	if selected_bus is not None:
		payload["selected_bus"] = selected_bus
	if seat_recommendation is not None:
		payload["seat_recommendation"] = seat_recommendation
	if seat_layout is not None:
		payload["seat_layout"] = seat_layout
	if ticket is not None:
		payload["ticket"] = ticket
	if booking is not None:
		payload["booking"] = booking
	if status == "booked" and ticket is not None:
		payload["cards"] = [
			{
				"type": "ticket_reveal",
				"data": ticket,
			},
		]
	elif status == "need_seat_preference" and selected_bus is not None:
		payload["cards"] = [
			{
				"type": "seat_preference_prompt",
				"data": {
					"message": message,
					"status": status,
					"selected_bus": selected_bus,
				},
			},
		]
	elif status in {"seat_recommended", "seat_selection_ready"} and seat_recommendation is not None:
		payload["cards"] = [
			{
				"type": "seat_recommendation",
				"data": {
					"message": message,
					"status": status,
					"selected_bus": selected_bus,
					"seat_recommendation": seat_recommendation,
					"seat_layout": seat_layout,
				},
			},
		]
	else:
		payload["cards"] = [
			{
				"type": "bus_recommendation_bundle",
				"data": {
					"message": message,
					"status": status,
					"recommended_buses": recommended_buses,
					"all_buses": all_buses,
					"workflow": workflow,
					"selected_bus": selected_bus,
					"seat_recommendation": seat_recommendation,
					"seat_layout": seat_layout,
					"ticket": ticket,
					"booking": booking,
					"selected_recommendation_id": selected_bus.get("recommendation_id") if isinstance(selected_bus, dict) else None,
				},
			}
		]
	return payload


def build_workflow(stage: str, has_results: bool = False, booking_done: bool = False) -> List[Dict[str, Any]]:
	if stage == "intent_validation":
		return [
			{"label": "Understanding request", "step": "Understanding request", "status": "completed"},
			{"label": "Extracting travel details", "step": "Extracting travel details", "status": "completed"},
			{"label": "Waiting for route details", "step": "Waiting for route details", "status": "active"},
		]

	resolved_stage = BookingStage.awaiting_bus_selection if has_results else BookingStage.searching_buses
	return build_stage_workflow(normalize_stage(resolved_stage), booking_done=booking_done)
