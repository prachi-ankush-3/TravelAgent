"""AI-style bus ranking helpers for recommendation-first booking flows."""
from __future__ import annotations

from typing import Any, Dict, List

from app.agents.booking.ranking_service import rank_buses


def _safe_float(value: Any, default: float = 0.0) -> float:
	try:
		return float(value)
	except (TypeError, ValueError):
		return default


def _bus_id(bus: Dict[str, Any]) -> str:
	return str(bus.get("bus_id") or bus.get("id") or bus.get("vehicle_id") or "")


def _price(bus: Dict[str, Any]) -> float:
	return _safe_float(bus.get("price_min") or bus.get("price") or bus.get("fare"), 0.0)


def _comfort_score(bus: Dict[str, Any]) -> float:
	return _safe_float(bus.get("comfort_score") or bus.get("final_score") or bus.get("rating"), 0.0)


def _bus_reason(bus: Dict[str, Any], intent: Dict[str, Any], label: str) -> str:
	price = _price(bus)
	rating = _safe_float(bus.get("rating"), 0.0)
	seat_count = _safe_float(bus.get("available_seats"), 0.0)
	preferences = intent.get("preferences") or {}
	bits: List[str] = []
	if label == "Best Overall":
		bits.append("balances comfort, rating, and price")
	elif label == "Budget Friendly":
		bits.append("keeps the fare lean without losing core comfort")
	else:
		bits.append("puts comfort and onboard experience first")
	if preferences.get("window_seat"):
		bits.append("window-seat friendly")
	if preferences.get("sleeper"):
		bits.append("sleeper-friendly")
	if rating:
		bits.append(f"rated {rating:.1f}/5")
	if seat_count:
		bits.append(f"{int(seat_count)} seats visible")
	if price:
		bits.append(f"₹{price:.0f} fare")
	return ". ".join(bits)


def _score_label(bus: Dict[str, Any]) -> str:
	price = _price(bus)
	rating = _safe_float(bus.get("rating"), 0.0)
	comfort = _comfort_score(bus)
	if price <= 0:
		return "Unnamed Value"
	if comfort >= 4.5 and rating >= 4.6:
		return "Premium Comfort"
	if price <= 999:
		return "Budget Value"
	if rating >= 4.0:
		return "Best Overall"
	return "Smart Match"


def _dedupe_buses(buses: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
	seen: set[str] = set()
	items: List[Dict[str, Any]] = []
	for bus in buses:
		bus_key = _bus_id(bus)
		if bus_key in seen:
			continue
		seen.add(bus_key)
		items.append(bus)
	return items


def _pick_budget_friendly(buses: List[Dict[str, Any]], budget: float | None) -> Dict[str, Any] | None:
	if not buses:
		return None
	if budget and budget > 0:
		within_budget = [bus for bus in buses if _price(bus) <= budget]
		if within_budget:
			return min(within_budget, key=lambda bus: (_price(bus), -_safe_float(bus.get("rating"), 0.0)))
	return min(buses, key=lambda bus: (_price(bus), -_safe_float(bus.get("rating"), 0.0)))


def _pick_premium_comfort(buses: List[Dict[str, Any]]) -> Dict[str, Any] | None:
	if not buses:
		return None
	return max(
		buses,
		key=lambda bus: (
			_safe_float(bus.get("comfort_score"), 0.0),
			_safe_float(bus.get("rating"), 0.0),
			_safe_float(bus.get("available_seats"), 0.0),
			-_price(bus),
		),
	)


def build_bus_rankings(buses: List[Dict[str, Any]], intent: Dict[str, Any]) -> Dict[str, Any]:
	"""Return ranked inventory plus three AI-curated headline recommendations."""
	preferences = intent.get("preferences") or {}
	ranked_buses = rank_buses(
		buses,
		budget=intent.get("budget"),
		preferences=preferences,
	)
	ranked_buses = _dedupe_buses(ranked_buses)

	featured: List[Dict[str, Any]] = []
	best_overall = ranked_buses[0] if ranked_buses else None
	budget_friendly = _pick_budget_friendly(ranked_buses, intent.get("budget"))
	premium_comfort = _pick_premium_comfort(ranked_buses)

	for label, bus in [
		("Best Overall", best_overall),
		("Budget Friendly", budget_friendly),
		("Premium Comfort", premium_comfort),
	]:
		if not bus:
			continue
		bus_id = _bus_id(bus)
		if not bus_id:
			continue
		featured.append(
			{
				"recommendation_id": f"rec_{len(featured) + 1}",
				"rank_label": label,
				"bus_id": bus_id,
				"operator": bus.get("operator") or bus.get("operator_name") or bus.get("travels") or bus.get("name") or "Trusted Operator",
				"bus_type": bus.get("bus_type") or bus.get("type") or "Bus",
				"price": _price(bus),
				"rating": _safe_float(bus.get("rating"), 0.0),
				"departure_time": bus.get("departure_time") or bus.get("departure") or "",
				"arrival_time": bus.get("arrival_time") or bus.get("arrival") or "",
				"available_seats": int(_safe_float(bus.get("available_seats"), 0.0)),
				"final_score": _safe_float(bus.get("final_score"), 0.0),
				"score_breakdown": bus.get("score_breakdown") or {},
				"amenities": bus.get("amenities") or [],
				"reason": _bus_reason(bus, intent, label),
				"headline": _score_label(bus),
				"raw": bus,
			}
		)

	return {
		"ranked_buses": ranked_buses,
		"recommended_buses": featured,
		"best_overall": best_overall,
		"budget_friendly": budget_friendly,
		"premium_comfort": premium_comfort,
	}


def pick_bus_by_id(buses: List[Dict[str, Any]], bus_id: str | None) -> Dict[str, Any] | None:
	if not bus_id:
		return None
	for bus in buses:
		if _bus_id(bus) == str(bus_id):
			return bus
	return None
