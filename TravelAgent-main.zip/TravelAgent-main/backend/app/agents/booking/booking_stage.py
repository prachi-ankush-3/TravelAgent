from __future__ import annotations

from enum import Enum
from typing import Any, Dict, List


class BookingStage(str, Enum):
	idle = "idle"
	searching_buses = "searching_buses"
	recommendations_shown = "recommendations_shown"
	awaiting_bus_selection = "awaiting_bus_selection"
	awaiting_seat_preference = "awaiting_seat_preference"
	awaiting_seat_confirmation = "awaiting_seat_confirmation"
	booking_in_progress = "booking_in_progress"
	booking_complete = "booking_complete"


def normalize_stage(value: Any) -> BookingStage:
	if isinstance(value, BookingStage):
		return value
	text = str(value or BookingStage.idle.value).strip().lower()
	for stage in BookingStage:
		if stage.value == text:
			return stage
	return BookingStage.idle


def stage_label(stage: BookingStage | str) -> str:
	normalized = normalize_stage(stage)
	return normalized.value.replace("_", " ").title()


def build_workflow(stage: BookingStage | str, booking_done: bool = False) -> List[Dict[str, str]]:
	normalized = normalize_stage(stage)
	steps: List[Dict[str, str]] = [
		{"label": "Understanding request", "step": "Understanding request", "status": "completed"},
		{"label": "Searching buses", "step": "Searching buses", "status": "completed" if normalized != BookingStage.idle else "active"},
		{"label": "Showing recommendations", "step": "Showing recommendations", "status": "completed" if normalized in {BookingStage.recommendations_shown, BookingStage.awaiting_bus_selection, BookingStage.awaiting_seat_preference, BookingStage.awaiting_seat_confirmation, BookingStage.booking_in_progress, BookingStage.booking_complete} else "pending"},
		{"label": "Awaiting bus selection", "step": "Awaiting bus selection", "status": "completed" if normalized in {BookingStage.awaiting_seat_preference, BookingStage.awaiting_seat_confirmation, BookingStage.booking_in_progress, BookingStage.booking_complete} else ("active" if normalized == BookingStage.awaiting_bus_selection else "pending")},
		{"label": "Seat preference", "step": "Seat preference", "status": "completed" if normalized in {BookingStage.awaiting_seat_confirmation, BookingStage.booking_in_progress, BookingStage.booking_complete} else ("active" if normalized == BookingStage.awaiting_seat_preference else "pending")},
		{"label": "Awaiting seat confirmation", "step": "Awaiting seat confirmation", "status": "completed" if normalized in {BookingStage.booking_in_progress, BookingStage.booking_complete} else ("active" if normalized == BookingStage.awaiting_seat_confirmation else "pending")},
		{"label": "Booking in progress", "step": "Booking in progress", "status": "completed" if normalized == BookingStage.booking_complete or booking_done else ("active" if normalized == BookingStage.booking_in_progress else "pending")},
		{"label": "Booking complete", "step": "Booking complete", "status": "completed" if normalized == BookingStage.booking_complete or booking_done else "pending"},
	]
	return steps


def confirmation_intent(message: str) -> bool:
	text = " ".join(str(message or "").strip().lower().split())
	if not text:
		return False
	positive_tokens = {"yes", "yep", "yeah", "sure", "continue", "confirm", "go with it", "go ahead", "book it", "that one", "choose that", "looks good", "proceed"}
	return text in positive_tokens or any(token in text for token in positive_tokens)


def cancellation_intent(message: str) -> bool:
	text = " ".join(str(message or "").strip().lower().split())
	if not text:
		return False
	negative_tokens = {"no", "nope", "stop", "cancel", "not that", "change it", "other one"}
	return text in negative_tokens or any(token in text for token in negative_tokens)
