from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, ConfigDict

from app.agents.booking.booking_stage import BookingStage, build_workflow, normalize_stage


class BookingChatMessage(BaseModel):
	role: str
	message: str
	created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


class BookingConversationState(BaseModel):
	model_config = ConfigDict(extra="allow")

	session_id: str
	booking_id: Optional[str] = None
	booking_title: Optional[str] = None
	user_id: Optional[str] = None
	booking_stage: BookingStage = BookingStage.idle
	origin: Optional[str] = None
	destination: Optional[str] = None
	travel_date: Optional[str] = None
	travel_dates: Optional[Dict[str, str]] = None
	budget: Optional[Dict[str, Any]] = None
	travel_style: Optional[str] = None
	interests: List[str] = Field(default_factory=list)
	booking_intent: Optional[Dict[str, Any]] = None
	recommended_buses: List[Dict[str, Any]] = Field(default_factory=list)
	all_buses: List[Dict[str, Any]] = Field(default_factory=list)
	selected_bus: Optional[Dict[str, Any]] = None
	recommended_seat: Optional[Dict[str, Any]] = None
	selected_seat: Optional[str] = None
	booking_id: Optional[str] = None
	ticket_data: Optional[Dict[str, Any]] = None
	booking_details: Optional[Dict[str, Any]] = None
	conversation_history: List[BookingChatMessage] = Field(default_factory=list)
	workflow_steps: List[Dict[str, Any]] = Field(default_factory=list)
	booking_preferences: Dict[str, Any] = Field(default_factory=dict)
	passenger_details: Optional[Dict[str, Any]] = None
	raw_query: Optional[str] = None
	booking_status: Optional[str] = None
	updated_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

	def touch(self) -> None:
		self.updated_at = datetime.now(timezone.utc).isoformat()

	def set_stage(self, stage: BookingStage | str) -> None:
		self.booking_stage = normalize_stage(stage)
		self.workflow_steps = build_workflow(self.booking_stage, booking_done=self.booking_stage == BookingStage.booking_complete)
		self.touch()

	def append_message(self, role: str, message: str) -> BookingChatMessage:
		entry = BookingChatMessage(role=role, message=message)
		self.conversation_history.append(entry)
		self.touch()
		return entry

	def apply_updates(self, updates: Dict[str, Any]) -> None:
		for key, value in updates.items():
			if key == "booking_stage":
				self.set_stage(value)
				continue
			setattr(self, key, value)
		self.touch()

	def snapshot(self) -> Dict[str, Any]:
		payload = self.model_dump() if hasattr(self, "model_dump") else self.dict()
		payload["booking_id"] = self.booking_id or self.session_id
		payload["booking_title"] = self.booking_title or self._default_title()
		payload["booking_stage"] = self.booking_stage.value if isinstance(self.booking_stage, BookingStage) else str(self.booking_stage)
		payload["workflow_steps"] = list(self.workflow_steps or build_workflow(self.booking_stage))
		payload["conversation_history"] = [entry.model_dump() if hasattr(entry, "model_dump") else entry.dict() for entry in self.conversation_history]
		payload["messages"] = list(payload["conversation_history"])
		return payload

	def recent_messages(self, limit: int = 12) -> List[Dict[str, Any]]:
		entries = self.conversation_history[-max(1, limit):]
		return [entry.model_dump() if hasattr(entry, "model_dump") else entry.dict() for entry in entries]

	def _default_title(self) -> str:
		if self.origin and self.destination:
			return f"{self.origin} → {self.destination}"
		return "New Booking"
