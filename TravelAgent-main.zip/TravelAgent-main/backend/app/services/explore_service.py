"""ExploreService — dataset layer for place lookups.

Loads backend/datasets/places.json and provides a simple `get_places(city)`
function that returns a list of place dicts for the requested city.
"""
from __future__ import annotations
from pathlib import Path
import json
from typing import List, Dict, Any


_CACHE: Dict[str, List[Dict[str, Any]]] = {}


def _load_dataset() -> Dict[str, List[Dict[str, Any]]]:
    repo_root = Path(__file__).resolve().parents[2]
    dataset_path = repo_root / "datasets" / "places.json"
    if not dataset_path.exists():
        return {}
    try:
        with dataset_path.open("r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def get_places(city: str) -> List[Dict[str, Any]]:
    """Return list of places for `city`. City matching is case-insensitive.

    Returns an empty list if the city is not found or dataset missing.
    Results are shallow-copied from a module-level cache.
    """
    if not _CACHE:
        data = _load_dataset()
        for k, v in data.items():
            _CACHE[k.lower()] = v

    return list(_CACHE.get((city or "").lower(), []))
