"""Ranking helpers for HotelAgent."""
from __future__ import annotations

from typing import Any, Dict, Iterable, List


def calculate_score(hotel: Dict[str, Any], budget_field: Any = None, suggested_places: Iterable[Dict[str, Any]] | None = None) -> float:
    rating = float(hotel.get("rating") or 0.0)
    price = float(hotel.get("price_per_night") or 0.0)
    score = rating * 0.55

    total_budget = None
    if isinstance(budget_field, dict):
        total_budget = budget_field.get("total_budget")
    elif isinstance(budget_field, (int, float)):
        total_budget = budget_field

    if total_budget:
        total_budget = float(total_budget)
        if price <= total_budget / 4:
            score += 0.25
        elif price <= total_budget / 2:
            score += 0.15
        else:
            score += 0.05

    desired_tokens = set()
    for place in suggested_places or []:
        if not isinstance(place, dict):
            continue
        for key in ("name", "location", "category"):
            value = place.get(key)
            if value:
                desired_tokens.add(str(value).lower())

    haystack = " ".join(
        [
            str(hotel.get("location", "")),
            " ".join(hotel.get("nearby_places", []) or []),
            str(hotel.get("name", "")),
        ]
    ).lower()
    if any(token and token in haystack for token in desired_tokens):
        score += 0.2

    if hotel.get("family_friendly"):
        score += 0.05
    if hotel.get("couple_friendly"):
        score += 0.05

    return round(score, 3)


def rank_hotels(hotels: List[Dict[str, Any]], budget_field: Any = None, suggested_places: Iterable[Dict[str, Any]] | None = None) -> List[Dict[str, Any]]:
    ranked = []
    for hotel in hotels:
        item = dict(hotel)
        item["score"] = calculate_score(item, budget_field=budget_field, suggested_places=suggested_places)
        ranked.append(item)
    ranked.sort(key=lambda item: (item.get("score", 0.0), item.get("rating", 0.0), -(item.get("price_per_night", 0) or 0)), reverse=True)
    return ranked