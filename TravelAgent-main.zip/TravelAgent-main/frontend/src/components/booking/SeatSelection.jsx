import React from 'react';
import { motion } from 'framer-motion';
import { Sparkles, Info } from 'lucide-react';

export default function SeatSelection({ data, onSelect }) {
  // Use passed data layout or mock
  const seats = data?.layout || [
    ['gray', 'green', 'empty', 'orange', 'green'],
    ['gray', 'gray', 'empty', 'green', 'green'],
    ['green', 'orange', 'empty', 'gray', 'green'],
    ['green', 'green', 'empty', 'green', 'orange'],
    ['gray', 'green', 'empty', 'green', 'green'],
  ];

  return (
    <div className="glass-panel" style={{ padding: '24px', marginTop: '16px', maxWidth: '400px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
        <h3 style={{ fontSize: '18px', fontWeight: 600 }}>Select Your Seat</h3>
        <div style={{ padding: '4px 12px', background: 'var(--glass-bg)', borderRadius: '20px', border: '1px solid var(--glass-border)', fontSize: '12px', display: 'flex', gap: '8px' }}>
           <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}><div style={{ width: '10px', height: '10px', background: '#10B981', borderRadius: '2px' }}/> Available</div>
           <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}><div style={{ width: '10px', height: '10px', background: 'var(--accent-orange)', borderRadius: '2px' }}/> Recommended</div>
           <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}><div style={{ width: '10px', height: '10px', background: '#4B5563', borderRadius: '2px' }}/> Booked</div>
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', alignItems: 'center', padding: '24px', background: 'rgba(0,0,0,0.2)', borderRadius: '12px', border: '1px solid var(--glass-border)' }}>
        <div style={{ alignSelf: 'flex-end', padding: '8px 16px', border: '1px solid var(--glass-border)', borderRadius: '8px', marginBottom: '16px', fontSize: '12px', color: 'var(--text-muted)' }}>
          Driver
        </div>
        
        {seats.map((row, rIdx) => (
          <div key={rIdx} style={{ display: 'flex', gap: '12px' }}>
            {row.map((seat, cIdx) => {
              if (seat === 'empty') return <div key={cIdx} style={{ width: '40px' }} />;
              
              const isRecommended = seat === 'orange';
              const isAvailable = seat === 'green' || isRecommended;
              
              let bg = '#4B5563';
              if (seat === 'green') bg = '#10B981';
              if (seat === 'orange') bg = 'var(--accent-orange)';

              return (
                <motion.button
                  key={cIdx}
                  whileHover={isAvailable ? { scale: 1.1 } : {}}
                  whileTap={isAvailable ? { scale: 0.95 } : {}}
                  onClick={() => isAvailable && onSelect(seat)}
                  style={{
                    width: '40px',
                    height: '40px',
                    borderRadius: '8px',
                    border: 'none',
                    background: bg,
                    cursor: isAvailable ? 'pointer' : 'not-allowed',
                    opacity: isAvailable ? 1 : 0.5,
                    position: 'relative'
                  }}
                >
                  {isRecommended && (
                    <motion.div
                      className="floating"
                      style={{ position: 'absolute', top: '-8px', right: '-8px', background: 'white', borderRadius: '50%', padding: '2px' }}
                    >
                      <Sparkles size={12} color="var(--accent-orange)" />
                    </motion.div>
                  )}
                </motion.button>
              );
            })}
          </div>
        ))}
      </div>

      {/* AI Reasoning */}
      <motion.div 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        style={{ marginTop: '24px', padding: '16px', background: 'rgba(255,106,0,0.1)', border: '1px solid var(--accent-orange-glow)', borderRadius: '12px' }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--accent-orange)', marginBottom: '8px', fontWeight: 600 }}>
          <Sparkles size={16} /> AI Reasoning
        </div>
        <p style={{ fontSize: '14px', color: 'white' }}>I selected A1 because it’s a front-side window seat with less vibration.</p>
      </motion.div>
    </div>
  );
}
