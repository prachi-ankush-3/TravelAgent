# core/config.py
# Central configuration for the TravelAgent backend

import os
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parents[2]
PROJECT_ROOT = BASE_DIR.parent

# Load variables from repo-root/.env.local first, then backend/.env.local and backend/.env
load_dotenv(PROJECT_ROOT / ".env.local")
load_dotenv(BASE_DIR / ".env.local", override=False)
load_dotenv(BASE_DIR / ".env", override=False)

# ─── LM Studio (Local LLM) ────────────────────────────────────────────────────
LM_STUDIO_BASE_URL: str = os.getenv("LM_STUDIO_BASE_URL", "http://127.0.0.1:1234")
LM_STUDIO_CHAT_ENDPOINT: str = f"{LM_STUDIO_BASE_URL}/v1/chat/completions"
LM_STUDIO_MODEL: str = os.getenv("LM_STUDIO_MODEL", "qwen/qwen2.5-vl-7b")

# ─── API Keys (for future integrations) ───────────────────────────────────────
GOOGLE_MAPS_API_KEY: str = os.getenv("GOOGLE_MAPS_API_KEY", "")
BOOKING_API_KEY: str = os.getenv("BOOKING_API_KEY", "")
RAPIDAPI_KEY: str = os.getenv("RAPIDAPI_KEY", "")
BOOKING_PROVIDER_BASE_URL: str = os.getenv("BOOKING_PROVIDER_BASE_URL", "http://localhost:9000")
SUPABASE_URL: str = os.getenv("SUPABASE_URL", "")
SUPABASE_SERVICE_KEY: str = os.getenv("SUPABASE_SERVICE_KEY", "")
SUPABASE_ANON_KEY: str = os.getenv("SUPABASE_ANON_KEY", "")

# ─── FastAPI App Settings ──────────────────────────────────────────────────────
APP_TITLE: str = "TravelAgent AI"
APP_VERSION: str = "1.0.0"
APP_DESCRIPTION: str = "AI-powered travel planning system powered by LM Studio"

# ─── LLM Request Settings ─────────────────────────────────────────────────────
LLM_MAX_TOKENS: int = 1024
LLM_TEMPERATURE: float = 0.3   # Lower = more deterministic JSON output
LLM_REQUEST_TIMEOUT: int = 60  # seconds
ENABLE_ITINERARY_BEAUTIFICATION: bool = os.getenv("ENABLE_ITINERARY_BEAUTIFICATION", "false").lower() in {"1", "true", "yes", "on"}
ENABLE_BOOKING_LLM_EXTRACTION: bool = os.getenv("ENABLE_BOOKING_LLM_EXTRACTION", "true").lower() in {"1", "true", "yes", "on"}

# ─── CORS ─────────────────────────────────────────────────────────────────────
ALLOWED_ORIGINS: list[str] = [
    "http://localhost:3000",
    "http://localhost:5173",
    "http://127.0.0.1:3000",
    "http://127.0.0.1:5173",
]
