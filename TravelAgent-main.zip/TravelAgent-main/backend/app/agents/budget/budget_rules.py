"""Budget allocation rules and affordability thresholds.

Defines default percentages, destination cost factors, and feasibility logic.
"""
from __future__ import annotations

from typing import Dict

# Default percentage allocations of total trip budget
DEFAULT_BUDGET_ALLOCATION_PERCENTAGES = {
    "hotel": 0.45,
    "food": 0.20,
    "activities": 0.20,
    "transport": 0.10,
    "misc": 0.05,
}

# Destination-specific multipliers (e.g., Mumbai is 1.5x baseline cost)
DESTINATION_COST_FACTORS: Dict[str, float] = {
    "Goa": 1.3,
    "Mumbai": 1.5,
    "Pune": 1.0,
    "Bangalore": 1.2,
    "Delhi": 1.4,
}

# Affordability rules: per-person-per-day minimums in INR
# Below these thresholds, travel becomes uncomfortable
AFFORDABILITY_THRESHOLDS = {
    "low": 500,       # backpacking/hostel level
    "medium": 1500,   # budget+mid-range hotels
    "high": 3000,     # comfort/upscale
    "luxury": 5000,   # luxury travel
}

# Travel style to minimum affordability mapping
TRAVEL_STYLE_AFFORDABILITY: Dict[str, str] = {
    "backpacking": "low",
    "budget": "low",
    "leisure": "medium",
    "adventure": "medium",
    "business": "high",
    "luxury": "luxury",
}


def get_destination_cost_factor(destination: str) -> float:
    """Return cost multiplier for a destination (default 1.0)."""
    return DESTINATION_COST_FACTORS.get((destination or "").title(), 1.0)


def get_affordability_level(travel_style: str | None) -> str:
    """Map travel_style to affordability threshold level."""
    if not travel_style:
        return "medium"
    style_key = travel_style.lower()
    return TRAVEL_STYLE_AFFORDABILITY.get(style_key, "medium")
