from __future__ import annotations

import json
import re
from typing import Any, Dict, List, Optional

from app.core.config import LM_STUDIO_MODEL, LLM_MAX_TOKENS, LLM_TEMPERATURE, LM_STUDIO_CHAT_ENDPOINT, LLM_REQUEST_TIMEOUT

try:
	import httpx
except Exception:  # pragma: no cover - runtime dependency guard
	httpx = None


_POSITION_WORDS = {
	"first": 0,
	"1st": 0,
	"one": 0,
	"second": 1,
	"2nd": 1,
	"two": 1,
	"third": 2,
	"3rd": 2,
	"three": 2,
}


def _text(value: Any) -> str:
	return " ".join(str(value or "").lower().split())


def _bus_title(bus: Dict[str, Any]) -> str:
	return str(bus.get("operator") or bus.get("operator_name") or bus.get("travels") or bus.get("name") or "Trusted Operator")


def _bus_bus_type(bus: Dict[str, Any]) -> str:
	return str(bus.get("bus_type") or bus.get("type") or "bus")


def _bus_id(bus: Dict[str, Any]) -> str:
	return str(bus.get("bus_id") or bus.get("id") or bus.get("vehicle_id") or "")


def _recommendation_id(bus: Dict[str, Any], index: int) -> str:
	return str(bus.get("recommendation_id") or f"rec_{index + 1}")


def _category_terms(user_message: str) -> Optional[str]:
	text = _text(user_message)
	if not text:
		return None
	if any(term in text for term in ["cheap", "cheaper", "budget", "lowest", "lowest fare", "value"]):
		return "Budget Friendly"
	if any(term in text for term in ["premium", "comfort", "luxury", "best comfort", "high end"]):
		return "Premium Comfort"
	if any(term in text for term in ["best", "overall", "top", "recommended", "first"]):
		return "Best Overall"
	return None


def _position_index(user_message: str) -> Optional[int]:
	text = _text(user_message)
	if not text:
		return None
	for phrase, index in _POSITION_WORDS.items():
		if re.search(rf"\b{re.escape(phrase)}\b", text):
			return index
	match = re.search(r"\boption\s*(\d+)\b", text)
	if match:
		try:
			return max(0, int(match.group(1)) - 1)
		except ValueError:
			return None
	return None


def _bus_matches_text(bus: Dict[str, Any], user_message: str) -> bool:
	text = _text(user_message)
	if not text:
		return False
	operator = _text(_bus_title(bus))
	bus_type = _text(_bus_bus_type(bus))
	rank_label = _text(bus.get("rank_label"))
	headline = _text(bus.get("headline"))
	return any(token and token in text for token in [operator, bus_type, rank_label, headline, _bus_id(bus).lower()])


def _semantic_pick(recommended_buses: List[Dict[str, Any]], user_message: str) -> Optional[Dict[str, Any]]:
	if not httpx:
		return None
	payload = {
		"model": LM_STUDIO_MODEL,
		"messages": [
			{
				"role": "system",
				"content": (
					"You select one recommendation index from the current bus shortlist. "
					"Return only JSON like {\"selected_bus_index\": 0}. "
					"Choose the most likely bus the user referred to from the shortlist."
				),
			},
			{
				"role": "user",
				"content": json.dumps(
					{
						"user_message": user_message,
						"recommended_buses": [
							{
								"recommendation_id": bus.get("recommendation_id"),
								"rank_label": bus.get("rank_label"),
								"operator": bus.get("operator"),
								"bus_type": bus.get("bus_type"),
								"price": bus.get("price"),
								"rating": bus.get("rating"),
							}
							for bus in recommended_buses
						],
					},
					ensure_ascii=False,
				),
			},
		],
		"max_tokens": LLM_MAX_TOKENS,
		"temperature": LLM_TEMPERATURE,
	}
	with httpx.Client(timeout=LLM_REQUEST_TIMEOUT) as client:
		response = client.post(LM_STUDIO_CHAT_ENDPOINT, json=payload)
		response.raise_for_status()
	data = response.json()
	raw = data["choices"][0]["message"]["content"]
	cleaned = raw.strip()
	if cleaned.startswith("```"):
		cleaned = cleaned.split("```", 1)[1].strip()
		if cleaned.startswith("json"):
			cleaned = cleaned[4:].strip()
	match = re.search(r"\{.*\}", cleaned, flags=re.S)
	parsed = json.loads(match.group(0) if match else cleaned)
	selected_index = parsed.get("selected_bus_index")
	try:
		index = int(selected_index)
	except (TypeError, ValueError):
		return None
	if 0 <= index < len(recommended_buses):
		return recommended_buses[index]
	return None


def resolve_selected_bus(
	*,
	user_message: str,
	recommended_buses: List[Dict[str, Any]],
	all_buses: List[Dict[str, Any]],
	booking_stage: str,
	selected_recommendation_id: Optional[str] = None,
	selected_bus_id: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
	if not recommended_buses and not all_buses:
		return None

	if selected_recommendation_id:
		for bus in recommended_buses:
			if str(bus.get("recommendation_id")) == str(selected_recommendation_id):
				return bus

	if selected_bus_id:
		for bus in recommended_buses + all_buses:
			if _bus_id(bus) == str(selected_bus_id):
				return bus

	text = _text(user_message)
	if not text:
		return None

	for bus in recommended_buses:
		if _bus_matches_text(bus, text):
			return bus

	category = _category_terms(text)
	if category:
		for bus in recommended_buses:
			if _text(bus.get("rank_label")) == _text(category):
				return bus

	index = _position_index(text)
	if index is not None and 0 <= index < len(recommended_buses):
		return recommended_buses[index]

	if any(term in text for term in ["this one", "that one", "choose that", "go with that", "book it", "proceed"]):
		return recommended_buses[0] if recommended_buses else None

	semantic = _semantic_pick(recommended_buses, user_message)
	if semantic:
		return semantic

	return None
