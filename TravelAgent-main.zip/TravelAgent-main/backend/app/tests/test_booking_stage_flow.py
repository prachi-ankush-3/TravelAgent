from __future__ import annotations

from app.agents.booking.booking_stage import BookingStage
from app.agents.booking.conversation_manager import BookingConversationManager
from app.agents.booking.stage_router import route_stage_action
from app.state.booking_session_manager import booking_session_manager


def test_empty_action_allowed_during_seat_confirmation() -> None:
	result = route_stage_action(BookingStage.awaiting_seat_confirmation, "")
	assert result.allowed is True


def test_search_stage_transitions_to_awaiting_bus_selection() -> None:
	manager = BookingConversationManager()

	def fake_run(state, **kwargs):
		if kwargs.get("action") == "search":
			return {
				"message": "I analyzed 3 buses and shortlisted the strongest options for your journey.",
				"status": "recommendations_ready",
				"recommended_buses": [{"bus_id": "bus-1", "rank_label": "Best Overall"}],
				"all_buses": [{"bus_id": "bus-1"}],
				"cards": [],
			}
		return {"message": "unexpected", "status": "need_more_info", "cards": []}

	manager.agent.run = fake_run
	session_id = "stage-flow-search"
	state = booking_session_manager.load_session(session_id)
	state.origin = "Pune"
	state.destination = "Mumbai"
	booking_session_manager.save_session(state)

	response = manager.handle_turn(
		session_id=session_id,
		message="Book bus from Pune to Mumbai tomorrow",
		action="search",
	)

	assert response["booking_stage"] == BookingStage.awaiting_bus_selection.value
