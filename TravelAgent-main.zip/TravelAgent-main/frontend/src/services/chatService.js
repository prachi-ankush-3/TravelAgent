import api from './api';

export const chatService = {
  sendMessage: async (message, sessionId = null, context = 'bus') => {
    try {
      const response = await api.post('/chat', {
        message,
        session_id: sessionId,
        context: context
      });
      return response.data;
    } catch (error) {
      console.error('Chat API Error:', error);
      throw error;
    }
  }
};
