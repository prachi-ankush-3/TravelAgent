"""Budget calculation and optimization logic.

Provides functions to split total budget, calculate per-day budgets,
generate hotel/activity constraints, and analyze feasibility.
"""
from __future__ import annotations

from typing import Any, Dict, Tuple

from app.agents.budget.budget_rules import (
    DEFAULT_BUDGET_ALLOCATION_PERCENTAGES,
    get_destination_cost_factor,
    get_affordability_level,
    AFFORDABILITY_THRESHOLDS,
)
from app.models.state_models import BudgetBreakdown


def extract_numeric_budget(budget_field: Any) -> float | None:
    """Extract total budget as a float from various formats."""
    if isinstance(budget_field, BudgetBreakdown):
        total = budget_field.total_budget
    elif isinstance(budget_field, dict):
        total = budget_field.get("total_budget")
    else:
        total = budget_field
    if total is None:
        return None
    try:
        return float(total)
    except (ValueError, TypeError):
        return None


def calculate_budget_allocation(
    total_budget: float,
    duration_days: int | None = None,
    num_travelers: int | None = None,
    destination: str | None = None,
) -> Dict[str, float]:
    """Allocate total budget across categories.
    
    Returns dict with keys: hotel, food, activities, transport, misc.
    """
    allocation = {}
    for category, percentage in DEFAULT_BUDGET_ALLOCATION_PERCENTAGES.items():
        allocation[category] = round(total_budget * percentage, 2)
    return allocation


def calculate_per_day_budget(
    total_budget: float,
    duration_days: int | None = None,
    num_travelers: int | None = None,
) -> Dict[str, float]:
    """Calculate per-day and per-person budgets."""
    if not duration_days or duration_days < 1:
        duration_days = 1
    if not num_travelers or num_travelers < 1:
        num_travelers = 1

    per_day_total = round(total_budget / duration_days, 2)
    per_person_per_day = round(per_day_total / num_travelers, 2)

    return {
        "per_day_total": per_day_total,
        "per_person_per_day": per_person_per_day,
    }


def calculate_hotel_constraints(
    total_budget: float,
    duration_days: int | None = None,
    allocation_percentage: float = 0.45,
) -> Dict[str, float]:
    """Calculate max hotel price per night from allocated budget."""
    if not duration_days or duration_days < 1:
        duration_days = 1

    hotel_budget = total_budget * allocation_percentage
    max_price_per_night = round(hotel_budget / duration_days, 2)

    return {
        "hotel_budget": round(hotel_budget, 2),
        "max_price_per_night": max_price_per_night,
    }


def analyze_feasibility(
    total_budget: float,
    duration_days: int | None = None,
    num_travelers: int | None = None,
    destination: str | None = None,
    travel_style: str | None = None,
) -> Dict[str, Any]:
    """Analyze whether budget is feasible.
    
    Returns dict with 'is_feasible', 'level', 'warnings', 'suggestions'.
    """
    if not duration_days or duration_days < 1:
        duration_days = 1
    if not num_travelers or num_travelers < 1:
        num_travelers = 1

    per_day = calculate_per_day_budget(
        total_budget,
        duration_days=duration_days,
        num_travelers=num_travelers,
    )
    per_person_per_day = per_day["per_person_per_day"]

    affordability_level = get_affordability_level(travel_style)
    minimum_required = AFFORDABILITY_THRESHOLDS.get(affordability_level, 1500)

    is_feasible = per_person_per_day >= minimum_required
    warnings = []
    suggestions = []

    if not is_feasible:
        deficit = round(minimum_required - per_person_per_day, 2)
        warnings.append(
            f"Budget may be insufficient for {travel_style or 'comfortable'} travel. "
            f"Need ₹{deficit} more per person per day."
        )

        shortfall_total = round(deficit * num_travelers * duration_days, 2)
        suggestions.append(f"Increase total budget by ₹{shortfall_total}")
        suggestions.append(f"Reduce trip duration from {duration_days} to {max(1, int(total_budget / (num_travelers * minimum_required)))} days")
        suggestions.append(f"Reduce travelers or choose budget accommodation")

    return {
        "is_feasible": is_feasible,
        "affordability_level": affordability_level,
        "per_person_per_day": per_person_per_day,
        "minimum_required": minimum_required,
        "warnings": warnings,
        "suggestions": suggestions,
    }
