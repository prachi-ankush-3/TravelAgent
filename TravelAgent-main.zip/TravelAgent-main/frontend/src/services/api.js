import axios from 'axios';

const accessTokenKey = 'travagent_access_token';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || '/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

api.interceptors.request.use((config) => {
  config.headers = config.headers ?? {};
  const token = localStorage.getItem(accessTokenKey);
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  if (import.meta.env.DEV) {
    const method = (config.method || 'get').toUpperCase();
    const url = `${config.baseURL || ''}${config.url || ''}`;
    console.info(`[TravAgent API] ${method} ${url}`);
  }
  return config;
});

api.interceptors.response.use(
  (response) => {
    if (import.meta.env.DEV) {
      console.info(`[TravAgent API] ${response.status} ${response.config.url}`);
    }
    return response;
  },
  (error) => {
    if (import.meta.env.DEV) {
      const status = error?.response?.status ?? 'network';
      const url = error?.config?.url ?? 'unknown';
      console.error(`[TravAgent API] FAILED ${status} ${url}`, error?.message);
    }
    return Promise.reject(error);
  },
);

export default api;
export { accessTokenKey };
