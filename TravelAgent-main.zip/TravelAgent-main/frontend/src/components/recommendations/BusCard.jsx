import React, { useEffect, useMemo, useRef, useState } from 'react';
import { AlertCircle, Sparkles, Loader2, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { bookingService } from '../../services/bookingService';
import { getCurrentProfile } from '../../services/authService';
import { getBookingPreferences, saveBookingMemory } from '../../services/bookingMemory';
import AIRecommendations from './AIRecommendations';
import AllBusesModal from './AllBusesModal';
import SeatRecommendation from './SeatRecommendation';
import TicketReveal from './TicketReveal';

/** Extract the canonical bus_id from any bus shape */
function getBusId(bus) {
	return bus?.bus_id || bus?.id || bus?.vehicle_id || '';
}

/** Build seat_preferences array from bookingPreferences object */
function getSeatPreferencesList(prefs = {}) {
	const list = [];
	if (prefs.window_seat) list.push('window');
	if (prefs.sleeper) list.push('sleeper');
	if (prefs.front) list.push('front');
	if (prefs.lower_berth) list.push('lower_berth');
	return list;
}

/**
 * Map a profile (from /auth/me) to the passenger fields needed for /book-ticket.
 * Returns null if required fields are missing.
 */
function passengerFromProfile(profile = {}) {
	const name = (profile.full_name || profile.name || profile.username || '').trim();
	const age = profile.age != null ? parseInt(String(profile.age), 10) : null;
	const gender = (profile.gender || '').trim();
	const phone = (profile.mobile || profile.phone || profile.phone_number || '').trim();
	return { name, age, gender, phone };
}

/**
 * Determine which required fields are missing from the passenger data.
 * Returns an empty array if all fields are present.
 */
function getMissingPassengerFields(p) {
	const missing = [];
	if (!p.name) missing.push('full name');
	if (!p.age || isNaN(p.age)) missing.push('age');
	if (!p.gender) missing.push('gender');
	if (!p.phone) missing.push('phone number');
	return missing;
}

export default function BusCard({ data, sessionId, query = '', onAction }) {
	const [loading, setLoading] = useState(false);
	const [viewAllOpen, setViewAllOpen] = useState(false);
	const [seatStage, setSeatStage] = useState(null);
	const [selectedBus, setSelectedBus] = useState(data?.selected_bus || null);
	const [selectedSeatNo, setSelectedSeatNo] = useState('');
	const [ticketResult, setTicketResult] = useState(null);
	const [profileLoading, setProfileLoading] = useState(false);
	const [passenger, setPassenger] = useState({ name: '', age: null, gender: '', phone: '' });
	const [missingFields, setMissingFields] = useState([]);
	const profileFetchedRef = useRef(false);

	const [paymentProcessing, setPaymentProcessing] = useState(false);
	const [paymentStep, setPaymentStep] = useState(0);
	const [bookingError, setBookingError] = useState('');

	const recommendationBundle = useMemo(() => {
		if (data?.recommended_buses || data?.all_buses) return data;
		if (Array.isArray(data)) return { recommended_buses: data.slice(0, 3), all_buses: data };
		if (data && data.bus_id) return { recommended_buses: [data], all_buses: [data] };
		return { recommended_buses: [], all_buses: [] };
	}, [data]);

	const recommendedBuses = recommendationBundle.recommended_buses || [];
	const allBuses = recommendationBundle.all_buses || [];
	const workflow = recommendationBundle.workflow || data?.workflow || [];
	const message = recommendationBundle.message || data?.message || '';
	const status = recommendationBundle.status || data?.status || 'recommendations_ready';
	const seatLayout = seatStage?.seat_layout || recommendationBundle.seat_layout || data?.seat_layout || null;
	const seatRecommendation = seatStage?.seat_recommendation || recommendationBundle.seat_recommendation || data?.seat_recommendation || null;

	useEffect(() => {
		if (data?.selected_bus) {
			setSelectedBus(data.selected_bus);
		}
	}, [data?.selected_bus]);

	// ── Auto-fetch passenger profile from DB on mount ──────────────────────────
	useEffect(() => {
		if (profileFetchedRef.current) return;
		profileFetchedRef.current = true;

		let isMounted = true;
		const fetchProfile = async () => {
			setProfileLoading(true);
			try {
				const me = await getCurrentProfile();
				const profile = me?.profile || me || {};

				// Also sync booking preferences to local memory
				if (profile.booking_preferences && typeof profile.booking_preferences === 'object') {
					saveBookingMemory(profile.booking_preferences);
				}

				if (isMounted) {
					const p = passengerFromProfile(profile);
					setPassenger(p);
					setMissingFields(getMissingPassengerFields(p));
				}
			} catch {
				// Guest / unauthenticated: leave passenger empty, show warning on proceed
				if (isMounted) {
					setMissingFields(['full name', 'age', 'gender', 'phone number']);
				}
			} finally {
				if (isMounted) setProfileLoading(false);
			}
		};

		fetchProfile();
		return () => { isMounted = false; };
	}, []);

	// ── Select a bus — asks backend for seat recommendation ───────────────────
	const handleSelectBus = async (bus) => {
		if (!sessionId || !bus) return;
		setLoading(true);
		setSelectedBus(bus);
		setSelectedSeatNo('');
		try {
			const response = await bookingService.runBookingAgent(query || 'book bus', sessionId, {
				action: 'seat',
				selectedBusId: getBusId(bus),
				selectedRecommendationId: bus?.recommendation_id || null,
				bookingPreferences: getBookingPreferences(),
				passengerDetails: null, // not needed for seat recommendation step
			});
			setSeatStage(response);
			if (onAction) onAction(response, { syncOnly: true });
		} catch (error) {
			console.error('Seat recommendation request failed', error);
		} finally {
			setLoading(false);
		}
	};

	// ── "Yes, Proceed" — directly call POST /book-ticket ──────────────────────
	const handleChooseSeat = async (seatNo) => {
		if (!selectedBus || !seatNo) return;

		setLoading(true);

		let currentPassenger = passenger;
		let currentMissing = getMissingPassengerFields(passenger);

		// Re-fetch just in case they updated it in another tab or in the DB directly
		if (currentMissing.length > 0) {
			try {
				const me = await getCurrentProfile();
				const profile = me?.profile || me || {};
				currentPassenger = passengerFromProfile(profile);
				currentMissing = getMissingPassengerFields(currentPassenger);
				setPassenger(currentPassenger);
				setMissingFields(currentMissing);
			} catch (e) {
				console.error('[BusCard] Failed to re-fetch profile:', e);
			}
		}

		// Guard: if profile is still incomplete, surface the warning but don't proceed
		if (currentMissing.length > 0) {
			setLoading(false);
			alert(`Cannot book ticket: Your profile is missing ${currentMissing.join(', ')}.\n\nMake sure you are logged into the app (check the sidebar) and that your profile is fully updated.`);
			return;
		}

		setSelectedSeatNo(seatNo);

		// Payment Animation Flow
		setPaymentProcessing(true);
		setPaymentStep(0); // Verifying
		await new Promise(r => setTimeout(r, 1000));
		setPaymentStep(1); // Processing
		await new Promise(r => setTimeout(r, 1500));
		setPaymentStep(2); // Success
		await new Promise(r => setTimeout(r, 800));

		try {
			const prefs = getBookingPreferences();
			const prefList = getSeatPreferencesList(prefs);

			// Build the exact payload schema for POST /book-ticket
			const payload = {
				booking_id: crypto.randomUUID(),
				bus_id: getBusId(selectedBus),
				seat_no: seatNo,
				passenger_name: passenger.name,
				passenger_age: parseInt(String(passenger.age), 10),
				passenger_gender: passenger.gender,
				phone_number: passenger.phone,
				source: selectedBus.source || selectedBus.origin || '',
				destination: selectedBus.destination || selectedBus.to || '',
				travel_date: selectedBus.travel_date || '',
				operator: selectedBus.operator || selectedBus.operator_name || '',
				price: selectedBus.price || selectedBus.price_min || '',
				departure_time: selectedBus.departure_time || '',
				arrival_time: selectedBus.arrival_time || '',
				seat_preferences: prefList,
			};

			const ticketData = await bookingService.bookTicket(payload);

			// Persist the confirmed ticket into the backend session
			if (sessionId) {
				try {
					await bookingService.confirmTicket(sessionId, ticketData, selectedBus);
				} catch (confirmError) {
					console.error('[BusCard] Failed to confirm ticket with backend:', confirmError);
					// Proceed anyway so the user sees the ticket, even if history persistence failed
				}
			}

			// Persist travel preferences to memory
			saveBookingMemory({
				seat_preference: prefs.window_seat ? 'window' : prefs.sleeper ? 'sleeper' : prefs.front ? 'front' : prefs.lower_berth ? 'lower' : '',
				preferred_bus_type: selectedBus?.bus_type || selectedBus?.type || '',
				preferred_operator: selectedBus?.operator || selectedBus?.operator_name || '',
			});

			setTicketResult(ticketData);

			// Bubble up to parent (BusBookingWorkspace) so the workflow/store reflects ticket done
			if (onAction) {
				onAction({
					message: 'Your ticket has been booked successfully!',
					workflow: [
						{ step: 'Understanding Request', status: 'completed' },
						{ step: 'Searching Buses', status: 'completed' },
						{ step: 'Recommendations', status: 'completed' },
						{ step: 'Bus Selection', status: 'completed' },
						{ step: 'Seat Confirmation', status: 'completed' },
						{ step: 'Payment', status: 'completed' },
					],
					cards: [{ type: 'ticket_reveal', data: ticketData }],
					ticket: ticketData,
					booking_stage: 'booking_complete',
				}, { syncOnly: true });
			}
		} catch (error) {
			console.error('[BusCard] Direct ticket booking failed:', error);
			setBookingError(error?.response?.data?.detail || error.message || 'Booking failed');
			// Bubble up to parent (BusBookingWorkspace) so the workflow/store reflects failure
			if (onAction) {
				onAction({
					message: 'Booking failed. Please try again.',
					booking_stage: 'booking_failed',
				}, { syncOnly: true });
			}
		} finally {
			setLoading(false);
			setPaymentProcessing(false);
		}
	};

	const handlePreferenceChosen = async (preferenceLabel) => {
		if (!sessionId || !selectedBus) return;
		setLoading(true);
		try {
			const prefs = getBookingPreferences();
			const response = await bookingService.runBookingAgent(query || 'seat preference', sessionId, {
				action: 'seat',
				selectedBusId: getBusId(selectedBus),
				selectedRecommendationId: selectedBus?.recommendation_id || null,
				bookingPreferences: {
					...prefs,
					seat_preference: preferenceLabel,
					window_seat: preferenceLabel === 'window',
					sleeper: preferenceLabel === 'sleeper',
					front: preferenceLabel === 'front',
					lower_berth: preferenceLabel === 'lower',
				},
				passengerDetails: null,
			});
			setSeatStage(response);
			if (onAction) onAction(response, { syncOnly: true });
		} catch (error) {
			console.error('Seat preference follow-up failed', error);
		} finally {
			setLoading(false);
		}
	};

	return (
		<div className="glass-panel" style={{ padding: '18px', marginTop: '12px', maxWidth: '980px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
			<div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '16px', flexWrap: 'wrap' }}>
				<div style={{ maxWidth: '680px' }}>
					<div style={{ display: 'flex', alignItems: 'center', gap: '10px', color: 'var(--accent-orange)', fontWeight: 700, letterSpacing: '0.02em' }}>
						<Sparkles size={16} /> AI booking shortlist
					</div>
					<div style={{ marginTop: '8px', fontSize: '16px', fontWeight: 700, color: 'white' }}>{message || 'Here are the strongest bus options for your trip.'}</div>
					<div style={{ marginTop: '8px', color: 'var(--text-muted)', fontSize: '13px', lineHeight: 1.6 }}>Pick one of the top buses, review the AI seat suggestion, then confirm only when you are ready.</div>
				</div>
				<div style={{ minWidth: '220px', padding: '14px 16px', borderRadius: '16px', background: 'rgba(255,106,0,0.08)', border: '1px solid rgba(255,106,0,0.18)' }}>
					<div style={{ fontSize: '12px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.12em' }}>Live session</div>
					<div style={{ marginTop: '6px', fontSize: '14px', color: 'white', fontWeight: 700 }}>{sessionId ? sessionId.slice(0, 8) : 'No session'}</div>
					<div style={{ marginTop: '6px', fontSize: '12px', color: 'var(--text-muted)' }}>{status.replaceAll('_', ' ')}</div>
				</div>
			</div>

			{/* Passenger profile status badge */}
			{!profileLoading && missingFields.length > 0 && (
				<div style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 14px', borderRadius: '12px', background: 'rgba(251,191,36,0.08)', border: '1px solid rgba(251,191,36,0.22)', color: '#fbbf24', fontSize: '13px' }}>
					<AlertCircle size={14} />
					<span>
						Your profile is missing <strong>{missingFields.join(', ')}</strong>. Please complete your{' '}
						<a href="/profile" style={{ color: '#fbbf24', textDecoration: 'underline' }}>Profile</a>{' '}
						before booking.
					</span>
				</div>
			)}

			{/* Booking error badge */}
			{bookingError && (
				<div style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 14px', borderRadius: '12px', background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.22)', color: '#ef4444', fontSize: '13px' }}>
					<AlertCircle size={14} />
					<span>
						<strong>Booking Failed:</strong> {bookingError}
					</span>
				</div>
			)}

			{!selectedBus && (
				<AIRecommendations recommendations={recommendedBuses} allBuses={allBuses} loading={loading} onSelectBus={handleSelectBus} onViewAll={() => setViewAllOpen(true)} />
			)}

			{selectedBus && (
				<div style={{ padding: '16px', borderRadius: '18px', background: 'linear-gradient(180deg, rgba(10,10,10,0.6), rgba(0,0,0,0.6))', border: '1px solid rgba(255,106,0,0.12)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '12px' }}>
					<div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
						<div style={{ width: '64px', height: '64px', borderRadius: '10px', background: 'rgba(255,255,255,0.04)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'white', fontWeight: 800 }}>
							{selectedBus.operator ? selectedBus.operator[0] : 'B'}
						</div>
						<div>
							<div style={{ fontSize: '16px', fontWeight: 900, color: 'white' }}>{selectedBus.operator || selectedBus.operator_name || selectedBus.name || 'Selected bus'}</div>
							<div style={{ marginTop: '6px', color: 'var(--text-muted)', fontSize: '13px' }}>{selectedBus.source || selectedBus.origin || '--'} • {selectedBus.destination || selectedBus.to || '--'}</div>
							<div style={{ marginTop: '6px', color: 'var(--text-muted)', fontSize: '13px' }}>{selectedBus.departure_time || '--:--'} {' → '} {selectedBus.arrival_time || '--:--'}</div>
						</div>
					</div>
					<div style={{ textAlign: 'right' }}>
						<div style={{ color: 'var(--text-muted)', fontSize: '12px' }}>Price</div>
						<div style={{ color: 'white', fontSize: '20px', fontWeight: 900 }}>₹{selectedBus.price || selectedBus.price_min || '--'}</div>
						<div style={{ marginTop: '6px', color: 'var(--text-muted)', fontSize: '12px' }}>{seatRecommendation?.reason || seatStage?.message || 'Continue with seat preference and confirmation.'}</div>
					</div>
				</div>
			)}

			{!ticketResult && selectedBus && (seatStage || status === 'need_seat_preference') && (
				<SeatRecommendation
					bus={selectedBus}
					data={seatStage || recommendationBundle}
					seatLayout={seatLayout}
					seatRecommendation={seatRecommendation}
					loading={loading}
					selectedSeatNo={selectedSeatNo}
					passengerName={passenger.name}
					missingFields={missingFields}
					onSeatSelect={handleChooseSeat}
					onPreferenceChosen={handlePreferenceChosen}
					needsPreference={status === 'need_seat_preference' || seatStage?.status === 'need_seat_preference'}
				/>
			)}

			{ticketResult && <TicketReveal ticket={ticketResult} />}

			{Array.isArray(workflow) && workflow.length > 0 && (
				<div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', color: 'var(--text-muted)', fontSize: '12px' }}>
					{workflow.map((step) => (
						<span key={step.step || step.label} style={{ padding: '6px 10px', borderRadius: '999px', border: '1px solid rgba(255,255,255,0.06)', background: 'rgba(255,255,255,0.03)' }}>
							{step.label || step.step}
						</span>
					))}
				</div>
			)}

			<AllBusesModal open={viewAllOpen} buses={allBuses} loading={loading} onClose={() => setViewAllOpen(false)} onSelectBus={handleSelectBus} />
			
			<AnimatePresence>
				{paymentProcessing && (
					<motion.div
						initial={{ opacity: 0 }}
						animate={{ opacity: 1 }}
						exit={{ opacity: 0 }}
						style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, zIndex: 9999, background: 'rgba(0,0,0,0.8)', backdropFilter: 'blur(10px)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
					>
						<motion.div
							initial={{ scale: 0.9, opacity: 0, y: 20 }}
							animate={{ scale: 1, opacity: 1, y: 0 }}
							style={{ padding: '32px 40px', borderRadius: '24px', background: 'linear-gradient(135deg, #181818, #2a2a2a)', border: '1px solid rgba(255,255,255,0.1)', textAlign: 'center', minWidth: '320px', boxShadow: '0 20px 40px rgba(0,0,0,0.4)' }}
						>
							<div style={{ height: '70px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
								{paymentStep === 0 && <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}><Loader2 size={48} color="#ff9a3c" /></motion.div>}
								{paymentStep === 1 && <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}><Loader2 size={48} color="#ff9a3c" /></motion.div>}
								{paymentStep === 2 && <motion.div initial={{ scale: 0 }} animate={{ scale: 1, transition: { type: 'spring', bounce: 0.5 } }}><CheckCircle2 size={56} color="#10B981" /></motion.div>}
							</div>
							
							<h3 style={{ marginTop: '24px', color: 'white', fontSize: '20px', fontWeight: 800 }}>
								{paymentStep === 0 && 'Verifying Seat...'}
								{paymentStep === 1 && 'Processing Payment...'}
								{paymentStep === 2 && 'Payment Successful!'}
							</h3>
							<p style={{ marginTop: '8px', color: 'var(--text-muted)', fontSize: '14px' }}>
								{paymentStep === 0 && 'Securing your selected seat'}
								{paymentStep === 1 && 'Securely processing via gateway'}
								{paymentStep === 2 && 'Generating your ticket'}
							</p>
						</motion.div>
					</motion.div>
				)}
			</AnimatePresence>
		</div>
	);
}
