# app/state/global_state.py
# GlobalTravelState — the shared memory object passed through the agent pipeline.
#
# Design:
#   - Wraps TravelStateModel (Pydantic schema)
#   - Every agent receives a reference to THIS object, reads what it needs,
#     writes its results back, and passes it forward.
#   - One GlobalTravelState instance exists per user session (managed by SessionManager).

from __future__ import annotations
from datetime import datetime, timezone
from typing import Any, Dict, Optional
import json
import sys

from app.core.logger import get_logger
from app.models.state_models import TravelStateModel, BudgetBreakdown, HotelPreferences

log = get_logger(__name__)

# ── Pretty-print helpers ───────────────────────────────────────────────────────

def _fmt(value: Any) -> str:
    """Compact, readable representation of any value for log lines."""
    if value is None:
        return "None"
    if isinstance(value, (dict, list)):
        try:
            return json.dumps(value, ensure_ascii=False, default=str)
        except Exception:
            return repr(value)
    return repr(value)


def _section(title: str, sid: str) -> str:
    """Return a clearly visible section header for log output."""
    bar = "─" * 60
    return f"\n{bar}\n  {title}  │  session={sid}\n{bar}"


class GlobalTravelState:
    """
    Stateful memory object for one travel planning session.

    Usage:
        state = GlobalTravelState(session_id="abc-123")
        state.destination = "Goa"
        state.duration_days = 4
        print(state.destination)   # → "Goa"
        print(state.snapshot())    # → full dict of current state
    """

    def __init__(self, session_id: str) -> None:
        self._data = TravelStateModel(
            session_id=session_id,
            created_at=datetime.now(timezone.utc).isoformat(),
        )
        log.info(_section("NEW SESSION INITIALISED", session_id))
        log.info(
            f"[State] Session created\n"
            f"  session_id  : {session_id}\n"
            f"  created_at  : {self._data.created_at}\n"
            f"  All fields  : empty (awaiting agent pipeline)"
        )

    # ── Transparent attribute access ──────────────────────────────────────────

    def __getattr__(self, name: str) -> Any:
        """Read any field directly: state.destination"""
        try:
            value = getattr(self._data, name)
            log.debug(
                f"[State:{self._data.session_id}] READ  {name} → {_fmt(value)}"
            )
            return value
        except AttributeError:
            extra = getattr(self._data, "__pydantic_extra__", None) or {}
            if name in extra:
                value = extra[name]
                log.debug(
                    f"[State:{self._data.session_id}] READ  extra.{name} → {_fmt(value)}"
                )
                return value
            raise AttributeError(f"GlobalTravelState has no field '{name}'")

    def __setattr__(self, name: str, value: Any) -> None:
        """Write any field directly: state.destination = 'Goa'"""
        if name.startswith("_"):          # Internal attributes go on self
            super().__setattr__(name, value)
        elif name in TravelStateModel.model_fields or name in self._data.model_fields_set:
            if name == "budget" and isinstance(value, dict):
                value = BudgetBreakdown(**value)
            if name == "hotel_preferences" and isinstance(value, dict):
                value = HotelPreferences(**value)
            old = getattr(self._data, name, "<unset>")
            setattr(self._data, name, value)
            log.debug(
                f"[State:{self._data.session_id}] WRITE {name}\n"
                f"    before : {_fmt(old)}\n"
                f"    after  : {_fmt(value)}"
            )
        else:
            # Unknown field — store via pydantic extra
            if self._data.__pydantic_extra__ is None:
                self._data.__pydantic_extra__ = {}
            old = self._data.__pydantic_extra__.get(name, "<unset>")  # type: ignore[index]
            self._data.__pydantic_extra__[name] = value               # type: ignore[index]
            log.debug(
                f"[State:{self._data.session_id}] WRITE extra.{name}\n"
                f"    before : {_fmt(old)}\n"
                f"    after  : {_fmt(value)}"
            )

    # ── Convenience helpers ───────────────────────────────────────────────────

    def update(self, data: Dict[str, Any]) -> None:
        """Bulk-update state from a dict (e.g. LLM JSON output)."""
        sid = self._data.session_id
        log.info(
            f"[State:{sid}] BULK UPDATE — {len(data)} field(s): {list(data.keys())}"
        )
        for key, value in data.items():
            setattr(self, key, value)
        log.info(f"[State:{sid}] Bulk update complete ✓")

    def record_llm_response(self, agent_name: str, raw: Dict[str, Any]) -> None:
        """Append an LLM response to the audit log."""
        sid = self._data.session_id
        self._data.llm_responses.append({"agent": agent_name, "response": raw})
        log.info(
            f"[State:{sid}] LLM RESPONSE STORED\n"
            f"  agent       : {agent_name}\n"
            f"  total_logs  : {len(self._data.llm_responses)}\n"
            f"  keys        : {list(raw.keys())}"
        )

    def mark_done(self, stage: str) -> None:
        """Mark a pipeline stage as complete. stage = 'extraction' | 'budget' | 'hotel' | 'explore'"""
        sid = self._data.session_id
        flag = f"{stage}_done"
        if hasattr(self._data, flag):
            setattr(self._data, flag, True)
            log.info(
                f"[State:{sid}] STAGE COMPLETE ✓\n"
                f"  stage : {stage}\n"
                f"  flag  : {flag} = True\n"
                f"  pipeline status → {self._pipeline_status()}"
            )
        else:
            log.warning(f"[State:{sid}] Unknown stage flag: {flag}")

    def snapshot(self) -> Dict[str, Any]:
        """Return the full current state as a plain dict (for logging / API response)."""
        sid = self._data.session_id
        data = self._data.model_dump()
        # Defensive: `budget` may be a dict, None, or a primitive number
        # (LLM might return a simple integer). Normalise to a mapping-like
        # view for logging below.
        raw_budget = data.get("budget")
        if isinstance(raw_budget, dict):
            budget = raw_budget
        elif raw_budget is None:
            budget = {}
        else:
            # treat numeric or other scalar budget as total_budget
            budget = {"total_budget": raw_budget}
        log.info(_section("STATE SNAPSHOT", sid))
        log.info(
            f"[State:{sid}] ── Core Trip ──────────────────────────────────\n"
            f"  raw_query        : {_fmt(data.get('raw_query'))}\n"
            f"  destination      : {_fmt(data.get('destination'))}\n"
            f"  origin           : {_fmt(data.get('origin'))}\n"
            f"  duration_days    : {_fmt(data.get('duration_days'))}\n"
            f"  num_travelers    : {_fmt(data.get('num_travelers'))}\n"
            f"  travel_dates     : {_fmt(data.get('travel_dates'))}\n"
            f"  travel_style     : {_fmt(data.get('travel_style'))}"
        )
        log.info(
            f"[State:{sid}] ── Budget ─────────────────────────────────────\n"
            f"  total_budget     : {_fmt(budget.get('total_budget'))}\n"
            f"  transport_budget : {_fmt(budget.get('transport_budget'))}\n"
            f"  hotel_budget     : {_fmt(budget.get('hotel_budget'))}\n"
            f"  food_budget      : {_fmt(budget.get('food_budget'))}\n"
            f"  activities_budget: {_fmt(budget.get('activities_budget'))}\n"
            f"  misc_budget      : {_fmt(budget.get('misc_budget'))}"
        )
        log.info(
            f"[State:{sid}] ── Hotel ──────────────────────────────────────\n"
            f"  star_rating      : {_fmt(data.get('hotel_preferences', {}).get('star_rating'))}\n"
            f"  max_price/night  : {_fmt(data.get('hotel_preferences', {}).get('max_price_per_night'))}\n"
            f"  amenities        : {_fmt(data.get('hotel_preferences', {}).get('amenities'))}\n"
            f"  preferred_area   : {_fmt(data.get('hotel_preferences', {}).get('preferred_area'))}\n"
            f"  selected_hotel   : {_fmt(data.get('selected_hotel'))}"
        )
        log.info(
            f"[State:{sid}] ── Explore ────────────────────────────────────\n"
            f"  interests        : {_fmt(data.get('interests'))}\n"
            f"  activities       : {len(data.get('suggested_activities', []))} item(s)"
        )
        log.info(
            f"[State:{sid}] ── Itinerary ──────────────────────────────────\n"
            f"  itinerary days   : {len(data.get('itinerary', []))}\n"
            f"  schedule entries : {len(data.get('daily_schedule', {}))}\n"
            f"  summary          : {_fmt(data.get('itinerary_summary'))}"
        )
        log.info(
            f"[State:{sid}] ── Pipeline Flags ────────────────────────────\n"
            f"  {self._pipeline_status()}\n"
            f"  llm_responses    : {len(data.get('llm_responses', []))} stored"
        )
        return data

    def reset(self, keep_session_id: bool = True) -> None:
        """Wipe all data and start fresh (keeps session_id by default)."""
        sid = self._data.session_id if keep_session_id else ""
        log.info(
            f"[State:{sid}] RESET\n"
            f"  keep_session_id : {keep_session_id}\n"
            f"  wiping all fields and restarting..."
        )
        self._data = TravelStateModel(
            session_id=sid,
            created_at=datetime.now(timezone.utc).isoformat(),
        )
        log.info(f"[State:{sid}] Reset complete ✓ — all fields cleared")

    # ── Internal helpers ──────────────────────────────────────────────────────

    def _pipeline_status(self) -> str:
        """Return a one-liner showing all pipeline flags."""
        d = self._data
        flags = {
            "extraction": d.extraction_done,
            "budget":     d.budget_done,
            "hotel":      d.hotel_done,
            "booking":    d.booking_done,
            "explore":    d.explore_done,
            "plan_ready": d.plan_ready,
            "plan":       d.plan_done,
        }
        parts = [f"{k}={'✓' if v else '✗'}" for k, v in flags.items()]
        return "  ".join(parts)

    def print_state(self) -> None:
        """
        Print the full GlobalTravelState to the terminal in a clean,
        human-readable block.  Uses print() directly so it always appears
        on stdout regardless of log-level configuration.
        """
        d = self._data
        W  = "\033[0m"   # reset
        B  = "\033[1m"   # bold
        C  = "\033[96m"  # cyan
        G  = "\033[92m"  # green
        Y  = "\033[93m"  # yellow
        R  = "\033[91m"  # red
        DIM = "\033[2m"  # dim

        def val(v: Any) -> str:
            if v is None or v == [] or v == {}:
                return f"{DIM}—{W}"
            if isinstance(v, bool):
                return f"{G}✓{W}" if v else f"{R}✗{W}"
            if isinstance(v, (dict, list)):
                return json.dumps(v, ensure_ascii=False, default=str)
            return str(v)

        sep  = f"{C}{'─' * 62}{W}"
        sep2 = f"{C}{'═' * 62}{W}"

        # Helper to safely read budget fields from possibly-non-object d.budget
        def _budget_field(field: str):
            b = d.budget
            # If pydantic model with attribute
            try:
                if hasattr(b, field):
                    return getattr(b, field)
            except Exception:
                pass
            # If dict-like
            try:
                return b.get(field) if isinstance(b, dict) else None
            except Exception:
                return None

        lines = [
            "",
            sep2,
            f"{B}{C}  STATE SNAPSHOT  │  session={d.session_id}{W}",
            sep2,
            f"{B}  CORE TRIP{W}",
            sep,
            f"  {'raw_query':<20} {val(d.raw_query)}",
            f"  {'destination':<20} {Y}{val(d.destination)}{W}",
            f"  {'origin':<20} {val(d.origin)}",
            f"  {'duration_days':<20} {val(d.duration_days)}",
            f"  {'num_travelers':<20} {val(d.num_travelers)}",
            f"  {'travel_dates':<20} {val(d.travel_dates)}",
            f"  {'travel_style':<20} {val(d.travel_style)}",
            "",
            f"{B}  BUDGET{W}",
            sep,
            f"  {'total_budget':<20} {val(_budget_field('total_budget'))}",
            f"  {'transport':<20} {val(_budget_field('transport_budget'))}",
            f"  {'hotel':<20} {val(_budget_field('hotel_budget'))}",
            f"  {'food':<20} {val(_budget_field('food_budget'))}",
            f"  {'activities':<20} {val(_budget_field('activities_budget'))}",
            f"  {'misc':<20} {val(_budget_field('misc_budget'))}",
            "",
            f"{B}  HOTEL{W}",
            sep,
            f"  {'star_rating':<20} {val(d.hotel_preferences.star_rating if d.hotel_preferences else None)}",
            f"  {'max_price/night':<20} {val(d.hotel_preferences.max_price_per_night if d.hotel_preferences else None)}",
            f"  {'amenities':<20} {val(d.hotel_preferences.amenities if d.hotel_preferences else None)}",
            f"  {'preferred_area':<20} {val(d.hotel_preferences.preferred_area if d.hotel_preferences else None)}",
            f"  {'selected_hotel':<20} {val(d.selected_hotel)}",
            "",
            f"{B}  EXPLORE{W}",
            sep,
            f"  {'interests':<20} {val(d.interests)}",
            f"  {'activities':<20} {len(d.suggested_activities)} item(s)",
            f"  {'itinerary':<20} {len(d.itinerary)} day(s)",
            f"  {'daily_schedule':<20} {len(d.daily_schedule)} item(s)",
            f"  {'summary':<20} {val(d.itinerary_summary)}",
            "",
            f"{B}  PIPELINE FLAGS{W}",
            sep,
            f"  extraction   {val(d.extraction_done)}    "
            f"budget   {val(d.budget_done)}    "
            f"hotel   {val(d.hotel_done)}    "
            f"explore   {val(d.explore_done)}    "
            f"plan       {val(d.plan_done)}",
            f"  llm_responses stored : {len(d.llm_responses)}",
            sep2,
            "",
        ]
        try:
            print("\n".join(lines), file=sys.stdout, flush=True)
        except Exception:
            # Some consoles (Windows CP1252) cannot print box-drawing Unicode
            # characters. Fall back to a safe ASCII/json dump so we don't crash
            # the caller when attempting to print state.
            try:
                safe = json.dumps(self._data.model_dump(), ensure_ascii=True, default=str)
                print(safe, file=sys.stdout, flush=True)
            except Exception:
                # Last resort: silent fail to avoid raising from a diagnostic helper
                pass

    def __repr__(self) -> str:
        return (
            f"<GlobalTravelState session={self._data.session_id!r} "
            f"destination={self._data.destination!r} "
            f"duration={self._data.duration_days}d>"
        )
