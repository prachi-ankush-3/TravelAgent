from __future__ import annotations

from typing import Any, Dict, Optional

from fastapi import APIRouter, HTTPException, Header
from pydantic import BaseModel, ConfigDict, Field

from app.core.logger import get_logger
from app.database.db import SupabaseError, create_user, get_profile, get_user, sign_in, upsert_profile

router = APIRouter(prefix="/auth", tags=["auth"])
log = get_logger(__name__)


class SignupRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    username: Optional[str] = None
    email: str
    password: str


class LoginRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    email: str
    password: str


def _normalize_user(user: Dict[str, Any]) -> Dict[str, Any]:
    metadata = user.get("user_metadata") or {}
    return {
        "id": user.get("id"),
        "email": user.get("email"),
        "username": metadata.get("username") or metadata.get("user_name") or user.get("username"),
        "email_confirmed_at": user.get("email_confirmed_at"),
        "created_at": user.get("created_at"),
    }


def _normalize_profile(profile: Dict[str, Any]) -> Dict[str, Any]:
    resolved_username = profile.get("full_name")
    return {
        "id": profile.get("id"),
        "email": profile.get("email"),
        "username": resolved_username,
        "full_name": profile.get("full_name"),
        "age": profile.get("age"),
        "mobile": profile.get("mobile"),
        "gender": profile.get("gender"),
        "booking_preferences": profile.get("booking_preferences"),
        "updated_at": profile.get("updated_at"),
    }


@router.post("/signup")
async def signup(body: SignupRequest) -> Dict[str, Any]:
    email = body.email.strip()
    password = body.password.strip()
    username = body.username.strip() if isinstance(body.username, str) else None

    if not email:
        raise HTTPException(status_code=400, detail="Email is required.")
    if not password:
        raise HTTPException(status_code=400, detail="Password is required.")
    if len(password) < 8:
        raise HTTPException(status_code=400, detail="Password must be at least 8 characters long.")
    if username is not None and len(username) < 2:
        raise HTTPException(status_code=400, detail="Username must be at least 2 characters long.")

    try:
        created_user = await create_user(
            email=email,
            password=password,
            username=username,
        )
        created_user_record = created_user.get("user") if isinstance(created_user, dict) and isinstance(created_user.get("user"), dict) else created_user
        if isinstance(created_user_record, dict):
            await upsert_profile(
                user_id=str(created_user_record.get("id", "")),
                email=email,
                username=username,
            )
        session = await sign_in(email=email, password=password)
    except SupabaseError as exc:
        message = str(exc)
        if "already registered" in message.lower() or "email already" in message.lower():
            raise HTTPException(status_code=409, detail="An account with this email already exists.") from exc
        log.error("Signup failed: %s", exc)
        raise HTTPException(status_code=502, detail=message) from exc

    created_user_record = created_user.get("user") if isinstance(created_user, dict) and isinstance(created_user.get("user"), dict) else created_user

    return {
        "message": "Account created successfully.",
        "user": _normalize_user(created_user_record) if isinstance(created_user_record, dict) else created_user_record,
        "session": session,
    }


@router.post("/login")
async def login(body: LoginRequest) -> Dict[str, Any]:
    email = body.email.strip()
    password = body.password.strip()

    if not email:
        raise HTTPException(status_code=400, detail="Email is required.")
    if not password:
        raise HTTPException(status_code=400, detail="Password is required.")

    try:
        session = await sign_in(email=email, password=password)
    except SupabaseError as exc:
        message = str(exc)
        if "invalid login credentials" in message.lower() or "invalid" in message.lower():
            raise HTTPException(status_code=401, detail="Invalid email or password.") from exc
        log.error("Login failed: %s", exc)
        raise HTTPException(status_code=502, detail=message) from exc

    user = session.get("user") or {}
    return {
        "message": "Login successful.",
        "user": _normalize_user(user) if isinstance(user, dict) else user,
        "session": session,
    }


@router.get("/me")
async def me(authorization: Optional[str] = Header(default=None)) -> Dict[str, Any]:
    if not authorization:
        raise HTTPException(status_code=401, detail="Missing authorization token.")

    token = authorization.removeprefix("Bearer ").strip()
    if not token:
        raise HTTPException(status_code=401, detail="Missing authorization token.")

    try:
        user = await get_user(token)
        profile = await get_profile(str(user.get("id", "")))
    except SupabaseError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    return {
        "user": _normalize_user(user) if isinstance(user, dict) else user,
        "profile": _normalize_profile(profile) if isinstance(profile, dict) else profile,
    }


class ProfileUpdateRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    username: Optional[str] = None
    full_name: Optional[str] = None
    age: Optional[int] = None
    mobile: Optional[str] = None
    gender: Optional[str] = None
    booking_preferences: Optional[Dict[str, Any]] = None


@router.put("/me/profile")
async def update_my_profile(
    body: ProfileUpdateRequest,
    authorization: Optional[str] = Header(default=None),
) -> Dict[str, Any]:
    if not authorization:
        raise HTTPException(status_code=401, detail="Missing authorization token.")

    token = authorization.removeprefix("Bearer ").strip()
    if not token:
        raise HTTPException(status_code=401, detail="Missing authorization token.")

    try:
        user = await get_user(token)
        resolved_name = body.full_name or body.username
        profile = await upsert_profile(
            user_id=str(user.get("id", "")),
            email=str(user.get("email", "")),
            username=body.username,
            full_name=resolved_name,
            age=body.age,
            mobile=body.mobile,
            gender=body.gender,
            booking_preferences=body.booking_preferences,
        )
    except SupabaseError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    return {
        "message": "Profile updated successfully.",
        "profile": _normalize_profile(profile) if isinstance(profile, dict) else profile,
    }