import React, { useRef, useState } from 'react';
import { BrainCircuit } from 'lucide-react';
import { motion } from 'framer-motion';
import BusCard from '../recommendations/BusCard';
import SeatSelection from '../booking/SeatSelection';
import SeatRecommendation from '../recommendations/SeatRecommendation';
import TicketReveal from '../recommendations/TicketReveal';
import { bookingService } from '../../services/bookingService';
import { getCurrentProfile } from '../../services/authService';
import { getBookingPreferences, saveBookingMemory } from '../../services/bookingMemory';

function formatTime(timestamp) {
  if (!timestamp) return '';
  const d = new Date(timestamp);
  if (isNaN(d.getTime())) return '';
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }).toUpperCase();
}

function getBusId(bus) {
  return bus?.bus_id || bus?.id || bus?.vehicle_id || '';
}

function getSeatPreferencesList(prefs = {}) {
  const list = [];
  if (prefs.window_seat) list.push('window');
  if (prefs.sleeper) list.push('sleeper');
  if (prefs.front) list.push('front');
  if (prefs.lower_berth) list.push('lower_berth');
  return list;
}

/**
 * ChatMessage — renders both user and AI messages.
 *
 * For seat_preference_prompt / seat_recommendation cards rendered directly
 * from message history (not inside a BusCard), this component handles
 * the booking by fetching the passenger profile itself.
 */
export default function ChatMessage({ message, onMessageAction }) {
  const isAI = message.type === 'ai';
  const [seatBookingLoading, setSeatBookingLoading] = useState(false);
  const [passengerName, setPassengerName] = useState('');
  const [missingFields, setMissingFields] = useState([]);
  const profileFetchedRef = useRef(false);

  /**
   * Called when a seat is selected inside a seat_recommendation card
   * that lives directly in the message history (not inside a BusCard).
   * Fetches profile from DB and calls POST /book-ticket directly.
   */
  const handleSeatSelect = async (card, seatNo) => {
    if (!message.sessionId || !seatNo) return;
    setSeatBookingLoading(true);

    try {
      const selectedBus = card?.data?.selected_bus || {};
      const prefs = getBookingPreferences();
      const prefList = getSeatPreferencesList(prefs);

      // Fetch passenger details from DB profile
      let passenger = { name: '', age: null, gender: '', phone: '' };
      try {
        const me = await getCurrentProfile();
        const profile = me?.profile || me || {};
        passenger = {
          name: (profile.full_name || profile.username || '').trim(),
          age: profile.age != null ? parseInt(String(profile.age), 10) : null,
          gender: (profile.gender || '').trim(),
          phone: (profile.mobile || '').trim(),
        };
        setPassengerName(passenger.name);
        const missing = [];
        if (!passenger.name) missing.push('name');
        if (!passenger.age || isNaN(passenger.age)) missing.push('age');
        if (!passenger.gender) missing.push('gender');
        if (!passenger.phone) missing.push('phone');
        if (missing.length > 0) {
          setMissingFields(missing);
          return; // Cannot book without complete profile
        }
      } catch {
        setMissingFields(['name', 'age', 'gender', 'phone']);
        return;
      }

      // POST /book-ticket directly
      const payload = {
        bus_id: getBusId(selectedBus),
        seat_no: seatNo,
        passenger_name: passenger.name,
        passenger_age: passenger.age,
        passenger_gender: passenger.gender,
        phone_number: passenger.phone,
        source: selectedBus.source || selectedBus.origin || '',
        destination: selectedBus.destination || '',
        travel_date: selectedBus.travel_date || '',
        operator: selectedBus.operator || selectedBus.operator_name || '',
        price: selectedBus.price || selectedBus.price_min || '',
        departure_time: selectedBus.departure_time || '',
        arrival_time: selectedBus.arrival_time || '',
        seat_preferences: prefList,
      };

      const ticketData = await bookingService.bookTicket(payload);

      if (message.sessionId) {
        try {
          await bookingService.confirmTicket(message.sessionId, ticketData, selectedBus);
        } catch (confirmError) {
          console.error('[ChatMessage] Failed to confirm ticket with backend:', confirmError);
        }
      }

      saveBookingMemory({
        seat_preference: prefs.window_seat ? 'window' : prefs.sleeper ? 'sleeper' : prefs.front ? 'front' : prefs.lower_berth ? 'lower' : '',
        preferred_bus_type: selectedBus?.bus_type || '',
        preferred_operator: selectedBus?.operator || selectedBus?.operator_name || '',
      });

      onMessageAction?.({
        message: 'Your ticket has been booked successfully!',
        workflow: [
          { step: 'Understanding Request', status: 'completed' },
          { step: 'Searching Buses', status: 'completed' },
          { step: 'Recommendations', status: 'completed' },
          { step: 'Bus Selection', status: 'completed' },
          { step: 'Seat Confirmation', status: 'completed' },
          { step: 'Payment', status: 'completed' },
        ],
        cards: [{ type: 'ticket_reveal', data: ticketData }],
        ticket: ticketData,
        booking_stage: 'booking_complete',
      });
    } catch (error) {
      console.error('Seat booking failed', error);
      onMessageAction?.({
        message: 'I could not complete the booking for that seat. Please try again.',
        cards: [],
        workflow: [],
      });
    } finally {
      setSeatBookingLoading(false);
    }
  };

  // USER message — right-aligned bubble
  if (!isAI) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: '4px' }}
      >
        <div className="user-chat-bubble">
          {message.text}
        </div>
        {message.timestamp && (
          <div style={{ fontSize: '10px', color: 'var(--text-muted)', letterSpacing: '0.06em' }}>
            SENT {formatTime(message.timestamp)}
          </div>
        )}
      </motion.div>
    );
  }

  // AI message
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      style={{ display: 'flex', gap: '14px', alignItems: 'flex-start' }}
    >
      {/* AI Avatar */}
      <div style={{
        width: '36px', height: '36px', borderRadius: '50%', flexShrink: 0,
        background: 'rgba(255,106,0,0.12)',
        border: '1px solid rgba(255,154,60,0.4)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <BrainCircuit size={18} color="var(--accent-orange)" />
      </div>

      <div style={{ flex: 1, minWidth: 0 }}>
        {/* Label */}
        <div style={{ fontSize: '13px', fontWeight: 600, color: 'var(--text-muted)', marginBottom: '8px' }}>
          TravAgent AI
        </div>

        {/* Text */}
        {message.text && (
          <div style={{
            fontSize: '14px',
            lineHeight: '1.6',
            color: 'var(--text-main)',
            marginBottom: message.cards?.length ? '12px' : '0',
            whiteSpace: 'pre-wrap',
          }}>
            {message.text}
          </div>
        )}

        {/* Cards */}
        {message.cards && message.cards.map((card, idx) => {
          if (card.type === 'bus_recommendation_bundle') {
            return <BusCard key={idx} data={card.data} sessionId={message.sessionId} query={message.query} onAction={onMessageAction} />;
          }
          if (card.type === 'seat_preference_prompt' || card.type === 'seat_recommendation') {
            return (
              <SeatRecommendation
                key={idx}
                data={card.data}
                bus={card.data?.selected_bus}
                seatLayout={card.data?.seat_layout}
                seatRecommendation={card.data?.seat_recommendation}
                loading={seatBookingLoading}
                passengerName={passengerName}
                missingFields={missingFields}
                needsPreference={card.type === 'seat_preference_prompt' || card.data?.status === 'need_seat_preference'}
                onSeatSelect={(seatNo) => handleSeatSelect(card, seatNo)}
              />
            );
          }
          if (card.type === 'ticket_reveal') {
            return <TicketReveal key={idx} ticket={card.data} />;
          }
          if (card.type === 'seat_layout') {
            return <SeatSelection key={idx} data={card.data} />;
          }
          return null;
        })}
      </div>
    </motion.div>
  );
}
