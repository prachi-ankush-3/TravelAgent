from __future__ import annotations

from datetime import datetime, timezone
import uuid
from typing import Any, Dict, Optional

import httpx

from app.agents.booking.booking_stage import BookingStage, build_workflow, normalize_stage
from app.agents.booking.booking_state import BookingConversationState
from app.core.config import SUPABASE_SERVICE_KEY, SUPABASE_URL
from app.core.logger import get_logger

log = get_logger(__name__)


class BookingSessionManager:
	def __init__(self) -> None:
		self._sessions: Dict[str, BookingConversationState] = {}
		log.info("[BookingSessionManager] Initialised")

	def create_session(self, user_id: Optional[str] = None) -> str:
		return self.create_booking(user_id=user_id)["booking_id"]

	def create_booking(self, user_id: Optional[str] = None, booking_title: str = "New Booking") -> Dict[str, Any]:
		booking_id = str(uuid.uuid4())
		state = BookingConversationState(
			session_id=booking_id,
			booking_id=booking_id,
			booking_title=booking_title,
			user_id=user_id,
		)
		state.set_stage(BookingStage.idle)
		self._sessions[booking_id] = state
		self.save_session(state)
		return {"booking_id": booking_id, "booking_title": booking_title}

	def list_bookings(self, user_id: Optional[str] = None) -> list[Dict[str, Any]]:
		if not self._supabase_enabled():
			return [state.snapshot() for state in self._sessions.values() if not user_id or state.user_id == user_id]
		if not user_id:
			return []

		try:
			rows = self._request(
				"GET",
				"/rest/v1/bookings",
				params={
					"select": "id,user_id,booking_title,origin,destination,travel_date,booking_stage,booking_status,selected_bus,selected_seat,booking_preferences,ticket_data,updated_at",
					"order": "updated_at.desc",
					"user_id": f"eq.{user_id}",
				},
			)
			bookings = rows if isinstance(rows, list) else []
			if bookings:
				return bookings
		except Exception as exc:
			log.debug("[BookingSessionManager] Direct booking lookup failed for %s: %s", user_id, exc)

		try:
			message_rows = self._request(
				"GET",
				"/rest/v1/booking_messages",
				params={
					"select": "booking_id,session_id,created_at",
					"user_id": f"eq.{user_id}",
					"order": "created_at.desc",
					"limit": "100",
				},
			)
			booking_keys: list[str] = []
			seen_keys: set[str] = set()
			if isinstance(message_rows, list):
				for row in message_rows:
					if not isinstance(row, dict):
						continue
					booking_key = str(row.get("booking_id") or row.get("session_id") or "").strip()
					if booking_key and booking_key not in seen_keys:
						seen_keys.add(booking_key)
						booking_keys.append(booking_key)
			if not booking_keys:
				return []

			conditions = ",".join(f"id.eq.{booking_id},session_id.eq.{booking_id}" for booking_id in booking_keys)
			rows = self._request(
				"GET",
				"/rest/v1/bookings",
				params={
					"select": "id,user_id,booking_title,origin,destination,travel_date,booking_stage,booking_status,selected_bus,selected_seat,booking_preferences,ticket_data,updated_at,created_at",
					"or": f"({conditions})",
					"order": "updated_at.desc",
					"limit": str(len(booking_keys)),
				},
			)
			return rows if isinstance(rows, list) else []
		except Exception as exc:
			log.debug("[BookingSessionManager] Could not list bookings for %s: %s", user_id, exc)
			return []

	def load_session(self, session_id: str, user_id: Optional[str] = None) -> BookingConversationState:
		if session_id in self._sessions:
			state = self._sessions[session_id]
			if user_id and not state.user_id:
				state.user_id = user_id
			return state

		state = self._load_from_supabase(session_id)
		if state is None:
			state = BookingConversationState(session_id=session_id, booking_id=session_id, booking_title="New Booking", user_id=user_id)
			state.set_stage(BookingStage.idle)
		else:
			if user_id and not state.user_id:
				state.user_id = user_id
			state.set_stage(state.booking_stage)

		self._sessions[session_id] = state
		return state

	def save_session(self, state: BookingConversationState) -> BookingConversationState:
		state.touch()
		self._sessions[state.session_id] = state
		self._persist_state(state)
		return state

	def append_message(self, session_id: str, role: str, message: str) -> BookingConversationState:
		state = self.load_session(session_id)
		state.append_message(role, message)
		self._persist_message(state, role, message)
		self._persist_state(state)
		return state

	def update_state(self, session_id: str, data: Dict[str, Any]) -> BookingConversationState:
		state = self.load_session(session_id)
		state.apply_updates(data)
		self._persist_state(state)
		return state

	def get_state(self, session_id: str) -> BookingConversationState:
		return self.load_session(session_id)

	def restore_booking_session(self, session_id: str) -> Dict[str, Any]:
		if not self._supabase_enabled():
			state = self.load_session(session_id)
			return self._build_restore_payload(state, messages=[])

		booking_rows = self._request("GET", "/rest/v1/bookings", params={"select": "*", "id": f"eq.{session_id}", "limit": "1"})
		booking = booking_rows[0] if isinstance(booking_rows, list) and booking_rows else None
		if not isinstance(booking, dict):
			booking_rows = self._request("GET", "/rest/v1/bookings", params={"select": "*", "session_id": f"eq.{session_id}", "limit": "1"})
			booking = booking_rows[0] if isinstance(booking_rows, list) and booking_rows else None
		if not isinstance(booking, dict):
			return {"session_id": session_id, "status": "expired"}

		messages = self._request(
			"GET",
			"/rest/v1/booking_messages",
			params={"select": "*", "session_id": f"eq.{session_id}", "order": "created_at.asc"},
		)
		preferences = None
		user_id = booking.get("user_id")
		if user_id:
			prefs_rows = self._request("GET", "/rest/v1/user_preferences", params={"select": "*", "user_id": f"eq.{user_id}", "limit": "1"})
			preferences = prefs_rows[0] if isinstance(prefs_rows, list) and prefs_rows else None

		state = BookingConversationState(
			session_id=str(booking.get("id") or booking.get("session_id") or session_id),
			booking_id=str(booking.get("id") or booking.get("session_id") or session_id),
			booking_title=booking.get("booking_title") or "New Booking",
			user_id=user_id,
			booking_stage=normalize_stage(booking.get("booking_stage")),
			origin=booking.get("origin"),
			destination=booking.get("destination"),
			travel_date=booking.get("travel_date"),
			travel_dates=booking.get("travel_dates"),
			recommended_buses=booking.get("recommended_buses") or [],
			selected_bus=booking.get("selected_bus"),
			recommended_seat=booking.get("recommended_seat") or booking.get("seat_recommendation"),
			selected_seat=booking.get("selected_seat"),
			ticket_data=booking.get("ticket_data"),
			booking_preferences=self._merge_booking_preferences(booking.get("booking_preferences"), preferences),
			booking_status=booking.get("booking_status"),
		)
		if isinstance(messages, list):
			for entry in messages:
				if isinstance(entry, dict):
					state.append_message(str(entry.get("role") or "assistant"), str(entry.get("message") or ""))

		payload = self._build_restore_payload(state, messages=messages if isinstance(messages, list) else [], preferences=preferences)
		payload["session_id"] = session_id
		return payload

	def _merge_booking_preferences(self, booking_preferences: Optional[Dict[str, Any]], user_preferences: Optional[Dict[str, Any]]) -> Dict[str, Any]:
		merged: Dict[str, Any] = dict(booking_preferences or {})
		if not isinstance(user_preferences, dict):
			return merged

		for key in ("window_seat", "sleeper", "lower_berth", "preferred_operator", "preferred_bus_type"):
			if user_preferences.get(key) not in (None, ""):
				merged[key] = user_preferences.get(key)

		seat_preference = str(user_preferences.get("seat_preference") or "").strip().lower()
		if seat_preference:
			merged["seat_preference"] = seat_preference
			merged.setdefault("window_seat", seat_preference == "window")
			merged.setdefault("sleeper", seat_preference == "sleeper")
			merged.setdefault("lower_berth", seat_preference in {"lower", "lower berth", "lower_berth"})

		return merged

	def _fetch_seat_layout(self, selected_bus: Optional[Dict[str, Any]]) -> Dict[str, Any]:
		if not isinstance(selected_bus, dict):
			return {}
		bus_id = str(selected_bus.get("bus_id") or selected_bus.get("id") or selected_bus.get("vehicle_id") or "")
		if not bus_id:
			return {}
		try:
			from app.agents.booking.booking_executor import BookingExecutor
			from app.integrations.booking.bus_provider import create_bus_provider

			provider = create_bus_provider()
			return BookingExecutor(provider).get_seat_layout(bus_id) or {}
		except Exception as exc:
			log.debug("[BookingSessionManager] Could not load seat layout for restore: %s", exc)
			return {}

	def _build_restore_payload(self, state: BookingConversationState, *, messages: list[Any], preferences: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
		seat_layout = self._fetch_seat_layout(state.selected_bus)
		booking_state = {
			"booking_id": state.booking_id or state.session_id,
			"booking_title": state.booking_title or state._default_title(),
			"origin": state.origin,
			"destination": state.destination,
			"travel_date": state.travel_date,
			"booking_intent": state.booking_intent,
			"booking_preferences": state.booking_preferences,
			"passenger_details": state.passenger_details,
			"selected_bus": state.selected_bus,
			"selected_seat": state.selected_seat,
			"recommended_seat": state.recommended_seat,
			"booking_id": state.booking_id,
			"ticket_data": state.ticket_data,
		}
		return {
			"session_id": state.session_id,
			"booking_stage": state.booking_stage.value if isinstance(state.booking_stage, BookingStage) else str(state.booking_stage),
			"messages": messages,
			"booking_state": booking_state,
			"recommended_buses": state.recommended_buses,
			"user_preferences": preferences or state.booking_preferences or {},
			"workflow": getattr(state, "workflow_steps", None) or build_workflow(state.booking_stage),
			"selected_journey": state.selected_bus or {},
			"seat_layout": seat_layout,
			"seat_recommendation": state.recommended_seat or {},
			"ticket_info": state.ticket_data or {},
			"status": "active",
		}

	def _persist_state(self, state: BookingConversationState) -> None:
		if not self._supabase_enabled():
			return
		booking_title = state.booking_title or self._build_booking_title(state)
		payload = {
			"id": state.booking_id or state.session_id,
			"session_id": state.booking_id or state.session_id,
			"user_id": state.user_id,
			"booking_title": booking_title,
			"origin": state.origin,
			"destination": state.destination,
			"travel_date": state.travel_date,
			"travel_dates": state.travel_dates,
			"booking_intent": state.booking_intent,
			"booking_preferences": state.booking_preferences,
			"passenger_details": state.passenger_details,
			"booking_stage": state.booking_stage.value if isinstance(state.booking_stage, BookingStage) else str(state.booking_stage),
			"selected_bus": state.selected_bus,
			"recommended_buses": state.recommended_buses,
			"recommended_seat": state.recommended_seat,
			"selected_seat": state.selected_seat,
			"ticket_data": state.ticket_data,
			"booking_status": state.booking_status,
			"raw_query": state.raw_query,
			"updated_at": datetime.now(timezone.utc).isoformat(),
		}
		try:
			rows = self._request("GET", "/rest/v1/bookings", params={"select": "id", "id": f"eq.{state.booking_id or state.session_id}", "limit": "1"})
			exists = isinstance(rows, list) and bool(rows)
			if exists:
				self._request("PATCH", "/rest/v1/bookings", params={"id": f"eq.{state.booking_id or state.session_id}"}, json=payload)
			else:
				self._request("POST", "/rest/v1/bookings", json=payload, headers={"Prefer": "return=representation"})
			self._persist_user_preferences(state)
		except Exception as exc:
			log.debug("[BookingSessionManager] Could not persist booking state for %s: %s", state.session_id, exc)

	def _persist_message(self, state: BookingConversationState, role: str, message: str) -> None:
		if not self._supabase_enabled():
			return
		payload = {
			"session_id": state.booking_id or state.session_id,
			"user_id": state.user_id,
			"role": role,
			"message": message,
			"metadata": {"booking_stage": state.booking_stage.value if isinstance(state.booking_stage, BookingStage) else str(state.booking_stage)},
		}
		try:
			self._request("POST", "/rest/v1/booking_messages", json=payload, headers={"Prefer": "return=representation"})
		except Exception as exc:
			log.debug("[BookingSessionManager] Could not persist booking message for %s: %s", state.session_id, exc)

	def _load_from_supabase(self, session_id: str) -> Optional[BookingConversationState]:
		if not self._supabase_enabled():
			return None
		try:
			rows = self._request(
				"GET",
				"/rest/v1/bookings",
				params={
					"select": "session_id,user_id,origin,destination,travel_date,travel_dates,booking_intent,booking_preferences,passenger_details,booking_stage,selected_bus,recommended_buses,all_buses,recommended_seat,selected_seat,booking_id,ticket_data,booking_status,raw_query,updated_at",
					"or": f"(id.eq.{session_id},session_id.eq.{session_id})",
					"limit": "1",
				},
			)
			row = rows[0] if isinstance(rows, list) and rows else None
			if not isinstance(row, dict):
				return None
			preferences = None
			user_id = row.get("user_id")
			if user_id:
				prefs_rows = self._request("GET", "/rest/v1/user_preferences", params={"select": "*", "user_id": f"eq.{user_id}", "limit": "1"})
				preferences = prefs_rows[0] if isinstance(prefs_rows, list) and prefs_rows else None
			state = BookingConversationState(
				session_id=str(row.get("id") or row.get("session_id") or session_id),
				booking_id=str(row.get("id") or row.get("session_id") or session_id),
				booking_title=row.get("booking_title") or "New Booking",
				user_id=user_id,
				booking_stage=normalize_stage(row.get("booking_stage")),
				origin=row.get("origin"),
				destination=row.get("destination"),
				travel_date=row.get("travel_date"),
				travel_dates=row.get("travel_dates"),
				booking_intent=row.get("booking_intent"),
				booking_preferences=self._merge_booking_preferences(row.get("booking_preferences"), preferences),
				passenger_details=row.get("passenger_details"),
				selected_bus=row.get("selected_bus"),
				recommended_buses=row.get("recommended_buses") or [],
				all_buses=row.get("all_buses") or [],
				recommended_seat=row.get("recommended_seat") or row.get("seat_recommendation"),
				selected_seat=row.get("selected_seat"),
				ticket_data=row.get("ticket_data"),
				booking_status=row.get("booking_status"),
				raw_query=row.get("raw_query"),
			)
			messages = self._request(
				"GET",
				"/rest/v1/booking_messages",
				params={"select": "role,message,created_at", "session_id": f"eq.{session_id}", "order": "created_at.asc", "limit": "50"},
			)
			if isinstance(messages, list):
				for entry in messages:
					if isinstance(entry, dict):
						state.append_message(str(entry.get("role") or "assistant"), str(entry.get("message") or ""))
			return state
		except Exception as exc:
			log.debug("[BookingSessionManager] Could not load booking state for %s: %s", session_id, exc)
			return None

	def _supabase_enabled(self) -> bool:
		return bool(SUPABASE_URL and SUPABASE_SERVICE_KEY)

	def _build_booking_title(self, state: BookingConversationState) -> str:
		if state.origin and state.destination:
			return f"{state.origin} → {state.destination}"
		return state.booking_title or "New Booking"

	def _persist_user_preferences(self, state: BookingConversationState) -> None:
		if not self._supabase_enabled() or not state.user_id:
			return
		preferences = dict(state.booking_preferences or {})
		seat_preference = str(preferences.get("seat_preference") or "").lower()
		payload = {
			"user_id": state.user_id,
			"window_seat": bool(preferences.get("window_seat") or seat_preference == "window"),
			"sleeper": bool(preferences.get("sleeper") or seat_preference == "sleeper"),
			"lower_berth": bool(preferences.get("lower_berth") or seat_preference == "lower"),
			"preferred_operator": preferences.get("preferred_operator") or "",
			"preferred_bus_type": preferences.get("preferred_bus_type") or "",
			"seat_preference": seat_preference or None,
			"updated_at": datetime.now(timezone.utc).isoformat(),
		}
		try:
			self._request(
				"POST",
				"/rest/v1/user_preferences",
				json=[payload],
				params={"on_conflict": "user_id"},
				headers={"Prefer": "resolution=merge-duplicates,return=representation"},
			)
		except Exception as exc:
			log.debug("[BookingSessionManager] Could not persist user preferences for %s: %s", state.session_id, exc)

	def _request(self, method: str, path: str, *, json: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None) -> Any:
		if not self._supabase_enabled():
			raise RuntimeError("Supabase is not configured")
		url = f"{SUPABASE_URL.rstrip('/')}/{path.lstrip('/')}"
		request_headers = {
			"apikey": SUPABASE_SERVICE_KEY,
			"Authorization": f"Bearer {SUPABASE_SERVICE_KEY}",
			"Content-Type": "application/json",
		}
		if headers:
			request_headers.update(headers)
		with httpx.Client(timeout=20) as client:
			response = client.request(method=method, url=url, headers=request_headers, json=json, params=params)
		if response.status_code >= 400:
			try:
				detail: Any = response.json()
			except Exception:
				detail = response.text
			raise RuntimeError(f"Supabase request failed ({response.status_code}): {detail}")
		if response.content:
			return response.json()
		return {}


booking_session_manager = BookingSessionManager()