# core/constants.py
# Shared constant values used across the TravelAgent app

# ─── Currency ─────────────────────────────────────────────────────────────────
DEFAULT_CURRENCY: str = "INR"

# ─── Defaults ─────────────────────────────────────────────────────────────────
DEFAULT_NUM_TRAVELERS: int = 1
DEFAULT_TRAVEL_STYLE: str = "leisure"

# ─── Travel Styles ───────────────────────────────────────────────────────────
TRAVEL_STYLES: list[str] = ["leisure", "adventure", "religious", "business", "honeymoon", "luxury", "backpacking"]

# ─── Supported Preferences ────────────────────────────────────────────────────
PREFERENCES: list[str] = [
    "beach", "mountains", "sightseeing", "food", "shopping",
    "nightlife", "wildlife", "heritage", "relaxation", "trekking",
]
