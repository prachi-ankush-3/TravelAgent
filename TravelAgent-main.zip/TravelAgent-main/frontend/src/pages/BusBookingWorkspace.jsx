import React, { useEffect, useRef, useState } from 'react';
import { bookingService } from '../services/bookingService';
import ChatWindow from '../components/chat/ChatWindow';
import ChatInput from '../components/chat/ChatInput';
import BookingSidebar from '../components/booking/BookingSidebar';
import { getBookingPreferences } from '../services/bookingMemory';
import { useBookingStore } from '../store/bookingStore';

export default function BusBookingWorkspace() {
	const [isTyping, setIsTyping] = useState(false);
	const currentBookingId = useBookingStore((state) => state.currentBookingId);
	const messages = useBookingStore((state) => state.messages);
	const bookingHistory = useBookingStore((state) => state.bookingHistory);
	const loading = useBookingStore((state) => state.loading);
	const refreshBookingHistory = useBookingStore((state) => state.refreshBookingHistory);
	const createBooking = useBookingStore((state) => state.createBooking);
	const loadBooking = useBookingStore((state) => state.loadBooking);
	const initializeWorkspace = useBookingStore((state) => state.initializeWorkspace);
	const appendMessage = useBookingStore((state) => state.appendMessage);
	const setWorkflow = useBookingStore((state) => state.setWorkflow);
	const setSelectedBus = useBookingStore((state) => state.setSelectedBus);
	const setSelectedSeat = useBookingStore((state) => state.setSelectedSeat);
	const setUserPreferences = useBookingStore((state) => state.setUserPreferences);
	const setBookingStage = useBookingStore((state) => state.setBookingStage);
	const setCurrentBookingId = useBookingStore((state) => state.setCurrentBookingId);

	const applyResponseState = (response) => {
		if (!response) return;
		const nextCurrentBookingId = response.booking_id || response.session_id || currentBookingId || '';
		if (nextCurrentBookingId) {
			setCurrentBookingId(nextCurrentBookingId);
		}
		setWorkflow(response.workflow || []);
		setSelectedBus(response.selected_bus || response.state?.selected_bus || null);
		setSelectedSeat(response.state?.selected_seat || response.selected_seat || response.ticket?.seat_no || '');
		setBookingStage(String(response.booking_stage || response.state?.booking_stage || 'idle').toLowerCase());
		if (response.user_preferences) {
			setUserPreferences(response.user_preferences);
		}
		if (response.ticket || response.booking) {
			useBookingStore.setState({ ticketData: response.ticket || response.booking });
		}
	};

	const syncResponseToStore = (response, query, options = {}) => {
		if (!response) return;
		applyResponseState(response);
		if (!options.syncOnly) {
			appendMessage({
				type: 'ai',
				text: response.message || 'Here is what I found for you.',
				cards: response.cards || [],
				sessionId: useBookingStore.getState().currentBookingId,
				bookingId: useBookingStore.getState().currentBookingId,
				query: query || '',
				timestamp: Date.now(),
			});
		}
	};

	const bootstrapRef = useRef(false);

	useEffect(() => {
		if (bootstrapRef.current) return;
		bootstrapRef.current = true;
		initializeWorkspace().catch((error) => {
			console.error('Booking workspace bootstrap failed', error);
			bootstrapRef.current = false;
		});
	}, [initializeWorkspace]);

	const handleNewBooking = async () => {
		await createBooking();
		await refreshBookingHistory();
		setWorkflow([{ label: 'Understanding request', step: 'Understanding request', status: 'completed' }]);
	};

	const handleSelectBooking = async (bookingId) => {
		if (!bookingId) return;
		await loadBooking(bookingId);
	};

	const handleSend = async (userText) => {
		let bookingId = useBookingStore.getState().currentBookingId;
		if (!bookingId) {
			console.warn('[BusBooking] No booking id — creating session before chat');
			const created = await createBooking();
			bookingId = created?.booking_id || useBookingStore.getState().currentBookingId;
		}
		if (!bookingId) {
			console.error('[BusBooking] Cannot send message: booking session missing');
			return;
		}
		appendMessage({ type: 'user', text: userText, sessionId: bookingId, bookingId, timestamp: Date.now() });
		setIsTyping(true);
		const bookingPreferences = getBookingPreferences();

		setWorkflow([{ step: 'Understanding request', status: 'processing' }]);

		try {
			const response = await bookingService.chat(bookingId, userText, { bookingPreferences });
			syncResponseToStore(response, userText);
			await refreshBookingHistory();
		} catch (error) {
			console.error('Booking chat failed', error);
			appendMessage({
				type: 'ai',
				text: 'Sorry, I had trouble connecting to the booking engine.',
				sessionId: bookingId,
				bookingId,
				cards: [],
				timestamp: Date.now(),
			});
			setWorkflow([{ step: 'Error', status: 'completed' }]);
		} finally {
			setIsTyping(false);
		}
	};

	const handleCardAction = async (aiResponse, options = {}) => {
		if (!aiResponse) return;
		syncResponseToStore(aiResponse, aiResponse.query || '', options);
		await refreshBookingHistory();
	};

	return (
		<div className="booking-workspace">
			<BookingSidebar
				bookings={bookingHistory}
				currentBookingId={currentBookingId}
				onNewBooking={handleNewBooking}
				onSelectBooking={handleSelectBooking}
				loading={loading}
			/>

			<div className="booking-chat-column">
				{/* Chat header */}
				<div className="booking-chat-header">
					<h2 className="booking-chat-title gradient-text">AI Travel Assistant</h2>
					<p className="booking-chat-subtitle">Plan and book journeys conversationally.</p>
				</div>

				{/* Chat messages panel */}
				<div className="booking-chat-panel">
					<ChatWindow messages={messages} isTyping={isTyping} onMessageAction={handleCardAction} />
				</div>

				{/* Input */}
				<ChatInput onSend={handleSend} disabled={isTyping || loading} />
			</div>
		</div>
	);
}
