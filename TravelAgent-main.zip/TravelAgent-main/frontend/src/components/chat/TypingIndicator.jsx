import React from 'react';
import { BrainCircuit } from 'lucide-react';
import { motion } from 'framer-motion';

export default function TypingIndicator() {
  return (
    <div style={{ display: 'flex', gap: '16px', alignItems: 'flex-start' }}>
      <div style={{
        width: '40px', height: '40px', borderRadius: '50%', flexShrink: 0,
        background: 'rgba(255,106,0,0.1)',
        border: '1px solid var(--accent-orange)',
        display: 'flex', alignItems: 'center', justifyContent: 'center'
      }}>
        <BrainCircuit size={20} color="var(--accent-orange)" />
      </div>
      <div style={{ display: 'flex', gap: '4px', padding: '12px 0' }}>
        {[0, 1, 2].map((i) => (
          <motion.div
            key={i}
            animate={{ y: [0, -5, 0] }}
            transition={{ duration: 0.6, repeat: Infinity, delay: i * 0.2 }}
            style={{ width: '8px', height: '8px', borderRadius: '50%', background: 'var(--accent-orange)' }}
          />
        ))}
      </div>
    </div>
  );
}
