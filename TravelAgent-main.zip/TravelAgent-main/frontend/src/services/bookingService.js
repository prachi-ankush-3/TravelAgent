import api from './api';

/**
 * bookingService — all API calls for the booking workspace.
 *
 * Key method: bookTicketDirect()
 *   Sends POST /book-ticket with the exact schema required:
 *     bus_id, seat_no, passenger_name, passenger_age (int), passenger_gender,
 *     phone_number, source, destination, travel_date, seat_preferences[]
 */
export const bookingService = {
  createBooking: async () => {
    const response = await api.post('/booking/new');
    return response.data;
  },
  listBookings: async () => {
    const response = await api.get('/booking/list');
    return response.data;
  },
  loadBooking: async (bookingId) => {
    const response = await api.get(`/booking/session/${bookingId}`);
    return response.data;
  },
  chat: async (bookingId, message, options = {}) => {
    try {
      const response = await api.post('/booking/chat', {
        booking_id: bookingId,
        message,
        action: options.action || null,
        auto_book: options.autoBook || false,
        fetch_booking_details: options.fetchBookingDetails || false,
        selected_bus_id: options.selectedBusId || null,
        selected_recommendation_id: options.selectedRecommendationId || null,
        selected_seat_no: options.selectedSeatNo || null,
        booking_preferences: options.bookingPreferences || null,
        passenger_details: options.passengerDetails || null,
      });
      return response.data;
    } catch (error) {
      console.error('Booking agent API Error:', error);
      throw error;
    }
  },
  runBookingAgent: async (query, bookingId = null, options = {}) => bookingService.chat(bookingId, query, options),
  getState: async (sessionId) => {
    try {
      const response = await api.get(`/booking/session/${sessionId}`);
      const data = response.data || {};
      return {
        session_id: sessionId,
        state: data.booking_state || data,
      };
    } catch (error) {
      console.error('Get state API Error:', error);
      throw error;
    }
  },
  restoreBookingSession: async (bookingId) => bookingService.loadBooking(bookingId),

  /**
   * POST /book-ticket — direct ticket booking.
   * Payload must match the exact schema:
   * {
   *   bus_id, seat_no,
   *   passenger_name, passenger_age (integer), passenger_gender, phone_number,
   *   source, destination, travel_date,
   *   seat_preferences: string[]
   * }
   */
  bookTicket: async (payload) => {
    const body = {
      booking_id: payload.booking_id || '',
      bus_id: payload.bus_id || '',
      seat_no: payload.seat_no || '',
      passenger_name: payload.passenger_name || '',
      passenger_age: parseInt(String(payload.passenger_age || 0), 10),
      passenger_gender: payload.passenger_gender || 'Male',
      phone_number: payload.phone_number || '',
      source: payload.source || '',
      destination: payload.destination || '',
      travel_date: payload.travel_date || '',
      operator: payload.operator || '',
      price: payload.price || '',
      departure_time: payload.departure_time || '',
      arrival_time: payload.arrival_time || '',
      seat_preferences: Array.isArray(payload.seat_preferences) ? payload.seat_preferences : [],
    };

    if (!body.bus_id) throw new Error('bookTicket: bus_id is required');
    if (!body.seat_no) throw new Error('bookTicket: seat_no is required');
    if (!body.passenger_name) throw new Error('bookTicket: passenger_name is required');
    if (!body.passenger_age || isNaN(body.passenger_age)) throw new Error('bookTicket: passenger_age must be a valid integer');
    if (!body.phone_number) throw new Error('bookTicket: phone_number is required');

    const response = await api.post('/book-ticket', body);
    return response.data;
  },

  /** Alias for bookTicket — same payload, same endpoint */
  bookTicketDirect: async (payload) => bookingService.bookTicket(payload),

  /**
   * POST /booking/confirm-ticket
   * Called immediately after bookTicket succeeds to persist the ticket in the session.
   */
  confirmTicket: async (sessionId, ticketData, busData) => {
    const body = {
      session_id: sessionId,
      ticket: ticketData,
      bus: busData,
    };
    const response = await api.post('/booking/confirm-ticket', body);
    return response.data;
  },

  getBooking: async (bookingId) => {
    const response = await api.get(`/booking/${bookingId}`);
    return response.data;
  },
  cancelBooking: async (bookingId) => {
    const response = await api.post(`/cancel-booking/${bookingId}`);
    return response.data;
  },
};
