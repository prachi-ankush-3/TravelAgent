"""Ranking utilities for ExploreAgent.

Provides a simple scoring function combining rating, budget match and interest match.
"""
from typing import List, Dict, Any


def _budget_score(place_budget_type: str, user_budget_level: str) -> float:
    if not user_budget_level:
        return 0.5
    pb = (place_budget_type or "").lower()
    ub = user_budget_level.lower()
    if pb == ub:
        return 1.0
    # adjacent mapping: low<->medium<->high
    order = ["low", "medium", "high"]
    try:
        pi = order.index(pb)
        ui = order.index(ub)
        return 1.0 - (abs(pi - ui) * 0.3)
    except Exception:
        return 0.5


def _interest_score(place_category: str, interests: List[str]) -> float:
    if not interests:
        return 0.0
    pc = (place_category or "").lower()
    lowered = [i.lower() for i in interests]
    for i in lowered:
        if i in pc or pc in i or i.rstrip("s") in pc:
            return 1.0
    return 0.0


def calculate_score(place: Dict[str, Any], user_budget_level: str, interests: List[str]) -> float:
    rating = float(place.get("rating") or 0)
    bscore = _budget_score(place.get("budget_type"), user_budget_level)
    iscore = _interest_score(place.get("category"), interests)
    # weights: rating 0.5 (normalized to 0-1 by dividing by 5), budget 0.2, interest 0.3
    score = (rating / 5.0) * 0.5 + bscore * 0.2 + iscore * 0.3
    return round(score, 4)


def rank_places(places: List[Dict[str, Any]], user_budget_level: str, interests: List[str]) -> List[Dict[str, Any]]:
    scored = []
    for p in places:
        s = calculate_score(p, user_budget_level, interests)
        item = dict(p)
        item["score"] = s
        scored.append(item)
    scored.sort(key=lambda x: x["score"], reverse=True)
    return scored
