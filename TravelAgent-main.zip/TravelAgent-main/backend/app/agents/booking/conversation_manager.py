from __future__ import annotations

from typing import Any, Dict, Optional

from app.agents.booking.booking_agent import BookingAgent
from app.agents.booking.booking_stage import BookingStage, build_workflow, cancellation_intent, confirmation_intent, normalize_stage
from app.agents.booking.booking_state import BookingConversationState
from app.agents.booking.bus_selection_resolver import resolve_selected_bus
from app.agents.booking.run_booking_agent import _extract_llm_json, _first_present, _parse_date_from_query, _resolve_natural_date
from app.agents.booking.trip_extractor import extract_trip_details_from_message, parse_route_from_message, parse_travel_date_from_message
from app.agents.booking.seat_preference import extract_seat_preference_from_message, merge_seat_preference
from app.agents.booking.stage_router import route_stage_action
from app.core.config import ENABLE_BOOKING_LLM_EXTRACTION
from app.core.logger import get_logger
from app.llm.json_cleaner import normalize_llm_keys
from app.state.booking_session_manager import booking_session_manager

log = get_logger(__name__)


class BookingConversationManager:
	def __init__(self) -> None:
		self.agent = BookingAgent()

	def handle_turn(
		self,
		*,
		session_id: str,
		message: str,
		action: Optional[str] = None,
		auto_book: bool = False,
		selected_bus_id: Optional[str] = None,
		selected_seat_no: Optional[str] = None,
		booking_preferences: Optional[Dict[str, Any]] = None,
		passenger_details: Optional[Dict[str, Any]] = None,
		fetch_booking_details: bool = False,
		user_id: Optional[str] = None,
		selected_recommendation_id: Optional[str] = None,
	) -> Dict[str, Any]:
		state = booking_session_manager.load_session(session_id, user_id=user_id)
		state.raw_query = message
		if booking_preferences:
			merged_preferences = dict(state.booking_preferences or {})
			merged_preferences.update(booking_preferences)
			state.booking_preferences = merged_preferences
		preference_patch = extract_seat_preference_from_message(message)
		if preference_patch:
			state.booking_preferences = merge_seat_preference(state.booking_preferences, message)
		if passenger_details:
			state.passenger_details = passenger_details
		booking_session_manager.append_message(session_id, "user", message)

		requested_action = str(action or "").strip().lower() or None
		log.info(
			"[BookingTurn] UI message received session=%s requested_action=%s stage=%s message=%r",
			session_id,
			requested_action,
			state.booking_stage,
			message,
		)
		resolved_action, resolved_bus_id, resolved_seat_no = self._resolve_action(
			state,
			message,
			requested_action=requested_action,
			selected_bus_id=selected_bus_id,
			selected_seat_no=selected_seat_no,
			selected_recommendation_id=selected_recommendation_id,
		)
		log.info(
			"[BookingTurn] Resolved action=%s bus_id=%s seat=%s origin=%r destination=%r",
			resolved_action,
			resolved_bus_id,
			resolved_seat_no,
			state.origin,
			state.destination,
		)

		# If the user sent a route in natural language, treat it as a search even when stage routing returned "question".
		route_source, route_destination = parse_route_from_message(message)
		if resolved_action == "question" and route_source and route_destination:
			log.info("[BookingTurn] Route detected in message - upgrading action question to search")
			resolved_action = "search"

		if resolved_action == "search":
			self._seed_trip_details(state, message)
			state.set_stage(BookingStage.searching_buses)
			result = self.agent.run(
				state,
				action="search",
				auto_book=False,
				passenger_details=passenger_details or state.passenger_details,
				fetch_booking_details=fetch_booking_details,
				booking_preferences=state.booking_preferences,
				user_message=message,
			)
			state.set_stage(self._stage_from_status(result.get("status"), BookingStage.awaiting_bus_selection))
		elif resolved_action == "seat":
			selected_bus = resolve_selected_bus(
				user_message=message,
				recommended_buses=state.recommended_buses,
				all_buses=state.all_buses,
				booking_stage=str(state.booking_stage),
				selected_recommendation_id=selected_recommendation_id,
				selected_bus_id=selected_bus_id,
			) or state.selected_bus
			if isinstance(selected_bus, dict):
				state.selected_bus = selected_bus
			resolved_bus_id = resolved_bus_id or (selected_bus.get("bus_id") or selected_bus.get("id") if isinstance(selected_bus, dict) else None)
			result = self.agent.run(
				state,
				action="seat",
				auto_book=False,
				passenger_details=passenger_details or state.passenger_details,
				selected_bus_id=resolved_bus_id,
				booking_preferences=state.booking_preferences,
				fetch_booking_details=fetch_booking_details,
				user_message=message,
			)
			state.set_stage(self._stage_from_status(result.get("status"), BookingStage.awaiting_seat_preference))
		elif resolved_action == "book":
			state.set_stage(BookingStage.booking_in_progress)
			result = self.agent.run(
				state,
				action="book",
				auto_book=True if auto_book or confirmation_intent(message) else auto_book,
				passenger_details=passenger_details or state.passenger_details,
				selected_bus_id=resolved_bus_id or self._selected_bus_id(state),
				selected_seat_no=resolved_seat_no,
				booking_preferences=state.booking_preferences,
				fetch_booking_details=fetch_booking_details,
				user_message=message,
			)
			state.set_stage(
				BookingStage.booking_complete
				if result.get("status") == "booked"
				else BookingStage.awaiting_seat_confirmation
			)
		else:
			result = self._clarify(state)

		self._sync_state(state, result)
		booking_session_manager.save_session(state)
		booking_session_manager.append_message(session_id, "assistant", result.get("message", ""))
		response = dict(result)
		response.setdefault("workflow", list(state.workflow_steps or build_workflow(state.booking_stage)))
		response["session_id"] = session_id
		response["booking_id"] = session_id
		response["booking_stage"] = state.booking_stage.value if isinstance(state.booking_stage, BookingStage) else str(state.booking_stage)
		response["conversation_history"] = state.recent_messages(20)
		response["state"] = state.snapshot()
		return response

	def _resolve_action(
		self,
		state: BookingConversationState,
		message: str,
		*,
		requested_action: Optional[str],
		selected_bus_id: Optional[str],
		selected_seat_no: Optional[str],
		selected_recommendation_id: Optional[str] = None,
	) -> tuple[str, Optional[str], Optional[str]]:
		stage = normalize_stage(state.booking_stage)
		route_decision = route_stage_action(stage, requested_action or "")
		if not route_decision.allowed:
			return "question", selected_bus_id, selected_seat_no
		if requested_action in {"search", "seat", "book"}:
			return requested_action, selected_bus_id, selected_seat_no

		if stage == BookingStage.booking_complete:
			return "question", selected_bus_id, selected_seat_no

		if stage == BookingStage.awaiting_seat_confirmation:
			if confirmation_intent(message):
				return "book", selected_bus_id or self._selected_bus_id(state), selected_seat_no or state.selected_seat
			if cancellation_intent(message):
				return "search", selected_bus_id, selected_seat_no
			if selected_seat_no:
				return "book", selected_bus_id or self._selected_bus_id(state), selected_seat_no
			return "book", selected_bus_id or self._selected_bus_id(state), state.selected_seat

		if stage == BookingStage.awaiting_seat_preference:
			if extract_seat_preference_from_message(message) or selected_seat_no:
				return "seat", selected_bus_id or self._selected_bus_id(state), selected_seat_no
			return "seat", selected_bus_id or self._selected_bus_id(state), selected_seat_no

		if stage in {BookingStage.recommendations_shown, BookingStage.awaiting_bus_selection}:
			selected_bus = resolve_selected_bus(
				user_message=message,
				recommended_buses=state.recommended_buses,
				all_buses=state.all_buses,
				booking_stage=str(state.booking_stage),
				selected_recommendation_id=selected_recommendation_id,
				selected_bus_id=selected_bus_id,
			)
			if selected_bus:
				return "seat", str(selected_bus.get("bus_id") or selected_bus.get("id") or selected_bus_id or "") or None, selected_seat_no
			if confirmation_intent(message):
				return "seat", selected_bus_id or self._selected_bus_id(state), selected_seat_no
			if selected_bus_id:
				return "seat", selected_bus_id, selected_seat_no
			if state.selected_bus:
				return "seat", self._selected_bus_id(state), selected_seat_no
			return "question", selected_bus_id, selected_seat_no

		return "search", selected_bus_id, selected_seat_no

	def _seed_trip_details(self, state: BookingConversationState, message: str) -> None:
		if not str(message or "").strip():
			return

		log.info("[BookingTurn] Seeding trip details (llm_enabled=%s)", ENABLE_BOOKING_LLM_EXTRACTION)
		extracted: Dict[str, Any] = {}
		if ENABLE_BOOKING_LLM_EXTRACTION:
			try:
				extracted = normalize_llm_keys(_extract_llm_json(message))
			except Exception as exc:
				log.warning("[BookingTurn] LLM trip extraction failed, using rule fallback: %s", exc)
		else:
			log.info("[BookingTurn] LLM extraction disabled via ENABLE_BOOKING_LLM_EXTRACTION")

		rule_based = extract_trip_details_from_message(message)
		log.info("[BookingTurn] Rule-based extraction: %s", rule_based)

		def _first_alias(*keys: str) -> Any:
			for key in keys:
				value = extracted.get(key)
				if value not in (None, ""):
					return value
			return None

		date_candidate = _first_present(
			(extracted.get("travel_dates") or {}).get("start") if isinstance(extracted.get("travel_dates"), dict) else None,
			extracted.get("travel_date"),
			extracted.get("date_of_departure"),
			extracted.get("departure_date"),
			rule_based.get("travel_date"),
			parse_travel_date_from_message(message),
			_parse_date_from_query(message),
		)
		source = _first_present(
			_first_alias("source", "origin", "departure_location", "departure_city", "from_city", "start_city"),
			rule_based.get("source"),
			parse_route_from_message(message)[0],
		) or ""
		destination = _first_present(
			_first_alias("destination", "arrival_location", "arrival_city", "to_city", "end_city"),
			rule_based.get("destination"),
			parse_route_from_message(message)[1],
		) or ""

		intent = {
			"source": source,
			"destination": destination,
			"travel_date": _resolve_natural_date(date_candidate) or parse_travel_date_from_message(message),
			"budget": extracted.get("budget"),
			"preferences": extracted.get("preferences") if isinstance(extracted.get("preferences"), dict) else {},
		}
		route_source, route_destination = parse_route_from_message(message)
		if intent.get("source") and (route_source or not state.origin):
			state.origin = intent["source"]
		if intent.get("destination") and (route_destination or not state.destination):
			state.destination = intent["destination"]
		if intent.get("travel_date") and not state.travel_date:
			state.travel_date = intent["travel_date"]
			state.travel_dates = {"start": intent["travel_date"]}
		elif not state.travel_date and state.origin and state.destination:
			from datetime import date, timedelta

			default_date = (date.today() + timedelta(days=1)).isoformat()
			state.travel_date = default_date
			state.travel_dates = {"start": default_date}
		if intent.get("budget") is not None and not state.budget:
			state.budget = {"transport_budget": intent["budget"]}
		if intent.get("preferences"):
			state.booking_preferences = dict(state.booking_preferences or {}) | dict(intent.get("preferences") or {})

		log.info(
			"[BookingTurn] Trip seeded origin=%r destination=%r travel_date=%r",
			state.origin,
			state.destination,
			state.travel_date,
		)

	def _sync_state(self, state: BookingConversationState, result: Dict[str, Any]) -> None:
		if result.get("recommended_buses") is not None:
			state.recommended_buses = result.get("recommended_buses") or []
		if result.get("all_buses") is not None:
			state.all_buses = result.get("all_buses") or []
		if result.get("selected_bus") is not None:
			state.selected_bus = result.get("selected_bus")
		if result.get("seat_recommendation") is not None:
			state.recommended_seat = result.get("seat_recommendation")
		if result.get("ticket") is not None:
			state.ticket_data = result.get("ticket")
		if result.get("booking") is not None and isinstance(result.get("booking"), dict):
			state.booking_id = result["booking"].get("booking_id") or result["booking"].get("id") or state.booking_id
		if result.get("status"):
			state.booking_status = result.get("status")
		if result.get("workflow"):
			state.workflow_steps = list(result.get("workflow") or [])
		if result.get("selected_seat"):
			state.selected_seat = result.get("selected_seat")
		elif state.recommended_seat and isinstance(state.recommended_seat, dict):
			state.selected_seat = str(state.recommended_seat.get("seat_no") or state.selected_seat or "") or None

	def _clarify(self, state: BookingConversationState) -> Dict[str, Any]:
		stage = normalize_stage(state.booking_stage)
		if stage == BookingStage.awaiting_bus_selection:
			message = "Pick one of the recommended buses, or tell me which operator you prefer."
		elif stage == BookingStage.awaiting_seat_preference:
			message = "Tell me your seating preference — window, front, sleeper, or lower berth — and I will pick the best seat."
		elif stage == BookingStage.awaiting_seat_confirmation:
			message = "Reply yes to confirm the recommended seat, or tell me another seat number."
		else:
			message = "Tell me the route first, for example: Book bus from Pune to Mumbai tomorrow."
		workflow = build_workflow(state.booking_stage)
		return {
			"message": message,
			"status": "need_more_info",
			"recommended_buses": state.recommended_buses,
			"all_buses": state.all_buses or state.recommended_buses,
			"selected_bus": state.selected_bus,
			"workflow": workflow,
			"cards": [],
		}

	def _selected_bus_id(self, state: BookingConversationState) -> Optional[str]:
		bus = state.selected_bus or {}
		if not isinstance(bus, dict):
			return None
		return str(bus.get("bus_id") or bus.get("id") or bus.get("vehicle_id") or "") or None

	def _stage_from_status(self, status: Optional[str], fallback: BookingStage) -> BookingStage:
		text = str(status or "").lower()
		if text == "booked":
			return BookingStage.booking_complete
		if text in {"seat_recommended", "seat_selection_ready"}:
			return BookingStage.awaiting_seat_confirmation
		if text == "need_seat_preference":
			return BookingStage.awaiting_seat_preference
		if text == "recommendations_ready":
			return BookingStage.awaiting_bus_selection
		if text == "need_more_info":
			return BookingStage.idle
		return fallback


conversation_manager = BookingConversationManager()
