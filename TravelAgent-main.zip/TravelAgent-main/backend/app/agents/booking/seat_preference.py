"""Seat preference detection from user messages and stored booking preferences."""
from __future__ import annotations

import re
from typing import Any, Dict, Optional


_PREFERENCE_PATTERNS = {
	"window": re.compile(r"\b(window|window seat)\b", re.I),
	"sleeper": re.compile(r"\b(sleeper|sleeper berth)\b", re.I),
	"front": re.compile(r"\b(front|front row|near front)\b", re.I),
	"lower": re.compile(r"\b(lower berth|lower)\b", re.I),
}


def has_seat_preference(preferences: Optional[Dict[str, Any]] = None) -> bool:
	prefs = preferences or {}
	if str(prefs.get("seat_preference") or "").strip():
		return True
	for key in ("window_seat", "sleeper", "front", "lower_berth"):
		if prefs.get(key):
			return True
	return False


def extract_seat_preference_from_message(message: str) -> Dict[str, Any]:
	text = str(message or "").strip()
	if not text:
		return {}
	for label, pattern in _PREFERENCE_PATTERNS.items():
		if pattern.search(text):
			patch: Dict[str, Any] = {"seat_preference": label}
			if label == "window":
				patch["window_seat"] = True
			elif label == "sleeper":
				patch["sleeper"] = True
			elif label == "front":
				patch["front"] = True
			elif label == "lower":
				patch["lower_berth"] = True
			return patch
	return {}


def merge_seat_preference(preferences: Optional[Dict[str, Any]], message: str) -> Dict[str, Any]:
	merged = dict(preferences or {})
	extracted = extract_seat_preference_from_message(message)
	if extracted:
		merged.update(extracted)
	return merged
