"""Orchestrator agent — decides which downstream agents to run based on state.

This first version implements a deterministic, rule-based decision:
- Read the provided state dict
- Check pipeline flags for completion
- Return a JSON-able plan listing agent names to run

Agent naming is human-readable (e.g. "ExploreAgent").
"""
from typing import Dict, List, Any


class OrchestratorAgent:
    """Simple orchestrator that inspects a state dict and returns agents to run."""

    # Map required pipeline flags to agent names and ordering.
    # Correct dependency order: Explore → Budget → Hotel → Itinerary
    # BudgetAgent must run before HotelAgent so hotels can respect budget constraints.
    _AGENT_FLAG_MAP = [
        ("explore_done", "ExploreAgent"),
        ("budget_done", "BudgetAgent"),
        ("hotel_done", "HotelAgent"),
        ("plan_done", "ItineraryAgent"),
    ]

    def decide(self, state: Dict[str, Any]) -> Dict[str, List[str]]:
        """Return an execution plan given a `state` mapping.

        The returned dict has the shape:
            { "agents_to_run": ["ExploreAgent", "HotelAgent"] }

        Rules:
        - If a flag (e.g. `explore_done`) is present and truthy, the agent is skipped.
        - If the flag is missing or falsy, the corresponding agent is scheduled.
        - Preserves ordering defined in `_AGENT_FLAG_MAP`.
        """
        agents: List[str] = []

        # defensive: accept either nested snapshot structure or flat dict
        data = state if isinstance(state, dict) else {}

        for flag, agent_name in self._AGENT_FLAG_MAP:
            val = data.get(flag)
            if not val:
                agents.append(agent_name)

        return {"agents_to_run": agents}


def decide_from_snapshot(snapshot: Dict[str, Any]) -> Dict[str, List[str]]:
    """Convenience function used by other modules/tests."""
    return OrchestratorAgent().decide(snapshot)
