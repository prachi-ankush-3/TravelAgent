"""BookingAgent orchestrates intelligent bus booking end-to-end."""
from __future__ import annotations

from typing import Any, Dict

from app.agents.booking.booking_executor import BookingExecutor
from app.agents.booking.booking_validator import validate_intent, validate_passenger_details
from app.agents.booking.bus_ranker import build_bus_rankings, pick_bus_by_id
from app.agents.booking.preference_parser import parse_booking_intent
from app.agents.booking.seat_preference import extract_seat_preference_from_message, has_seat_preference, merge_seat_preference
from app.agents.booking.seat_selection_service import select_best_seat
from app.agents.booking.recommendation_builder import build_recommendation_response, build_workflow
from app.core.config import BOOKING_PROVIDER_BASE_URL
from app.integrations.booking.bus_provider import create_bus_provider
from app.state.booking_session_manager import booking_session_manager


class BookingAgent:
	"""Intelligent bus booking orchestration with human-in-the-loop support."""

	def __init__(self, base_url: str | None = None) -> None:
		provider = create_bus_provider(base_url=base_url or BOOKING_PROVIDER_BASE_URL)
		self.executor = BookingExecutor(provider)

	def run(
		self,
		state: Any,
		action: str = "search",
		auto_book: bool = False,
		passenger_details: Dict[str, Any] | None = None,
		fetch_booking_details: bool = False,
		selected_bus_id: str | None = None,
		selected_seat_no: str | None = None,
		booking_preferences: Dict[str, Any] | None = None,
		user_message: str = "",
	) -> Dict[str, Any]:
		action = str(action or "search").lower()
		intent = parse_booking_intent(state).as_dict()
		if booking_preferences:
			merged_preferences = dict(intent.get("preferences") or {})
			merged_preferences.update(booking_preferences)
			intent["preferences"] = merged_preferences
			self._sync_state(state, {"booking_preferences": merged_preferences})

		message_text = str(user_message or getattr(state, "raw_query", "") or "")
		if message_text:
			merged = merge_seat_preference(intent.get("preferences") or {}, message_text)
			if merged:
				intent["preferences"] = merged
				self._sync_state(state, {"booking_preferences": merged})

		if selected_bus_id:
			intent["selected_bus_id"] = selected_bus_id
		if selected_seat_no:
			intent["selected_seat_no"] = selected_seat_no

		is_valid, error = validate_intent(intent)
		if not is_valid:
			return build_recommendation_response(
				message="I need both the origin and destination before I can rank buses.",
				recommended_buses=[],
				all_buses=[],
				workflow=build_workflow("intent_validation"),
				status="need_more_info",
			)

		buses = self.executor.search_buses(intent)
		if not buses:
			self._sync_state(state, {"recommended_buses": [], "booking_status": "NO_BUSES_FOUND"})
			return build_recommendation_response(
				message="I could not find any buses for that route on the selected date.",
				recommended_buses=[],
				all_buses=[],
				workflow=build_workflow("search", has_results=False),
				status="no_buses_found",
			)

		ranking = build_bus_rankings(buses, intent)
		ranked_buses = ranking["ranked_buses"]
		recommended_buses = ranking["recommended_buses"]
		bus_count = len(ranked_buses)

		selected_bus = pick_bus_by_id(ranked_buses, selected_bus_id or intent.get("selected_bus_id"))
		if action == "search":
			self._sync_state(
				state,
				{
					"booking_intent": intent,
					"recommended_buses": recommended_buses,
					"all_buses": ranked_buses,
					"selected_bus": None,
					"recommended_seat": None,
					"selected_seat": None,
					"booking_status": "RECOMMENDATIONS_READY",
				},
			)
			return build_recommendation_response(
				message=self._search_message(bus_count),
				recommended_buses=recommended_buses,
				all_buses=ranked_buses,
				workflow=build_workflow("search", has_results=True),
				status="recommendations_ready",
				selected_bus=None,
			)

		if not selected_bus:
			stored_bus = getattr(state, "selected_bus", None)
			if isinstance(stored_bus, dict):
				selected_bus = pick_bus_by_id(ranked_buses, stored_bus.get("bus_id") or stored_bus.get("id"))
		if not selected_bus:
			return build_recommendation_response(
				message="Please pick one of the recommended buses first.",
				recommended_buses=recommended_buses,
				all_buses=ranked_buses,
				workflow=build_workflow("search", has_results=True),
				status="missing_selected_bus",
			)

		selected_bus_id_value = str(selected_bus.get("bus_id") or selected_bus.get("id") or "")
		if not selected_bus_id_value:
			return build_recommendation_response(
				message="I found buses, but the selected option is missing an internal id.",
				recommended_buses=recommended_buses,
				all_buses=ranked_buses,
				workflow=build_workflow("search", has_results=True),
				status="invalid_result",
			)

		self._sync_state(
			state,
			{
				"booking_intent": intent,
				"recommended_buses": recommended_buses,
				"all_buses": ranked_buses,
				"selected_bus": selected_bus,
				"booking_status": "BUS_SELECTED",
			},
		)

		if action == "seat":
			preferences = intent.get("preferences") or {}
			if not has_seat_preference(preferences) and not extract_seat_preference_from_message(message_text):
				return build_recommendation_response(
					message=(
						"Do you have any seating preference like window, front, sleeper, or lower berth? "
						"Tell me what you prefer and I will optimize the seat for you."
					),
					recommended_buses=recommended_buses,
					all_buses=ranked_buses,
					workflow=build_workflow("search", has_results=True),
					status="need_seat_preference",
					selected_bus=selected_bus,
				)

			layout = self.executor.get_seat_layout(selected_bus_id_value)
			best_seat = select_best_seat(layout, preferences=intent.get("preferences") or {})
			seat_recommendation = self._build_seat_recommendation(selected_bus, best_seat, layout)
			seat_no = str((best_seat or {}).get("seat_no") or "")
			self._sync_state(
				state,
				{
					"selected_bus": selected_bus,
					"recommended_seat": seat_recommendation,
					"selected_seat": seat_no or None,
					"booking_status": "SEAT_RECOMMENDED",
				},
			)
			return build_recommendation_response(
				message=self._seat_message(seat_recommendation),
				recommended_buses=recommended_buses,
				all_buses=ranked_buses,
				workflow=build_workflow("search", has_results=True),
				status="seat_recommended",
				selected_bus=selected_bus,
				seat_recommendation=seat_recommendation,
				seat_layout=layout,
			)

		details = passenger_details or getattr(state, "passenger_details", None)
		ok, err = validate_passenger_details(details or {})
		layout = self.executor.get_seat_layout(selected_bus_id_value)
		best_seat = select_best_seat(layout, preferences=intent.get("preferences") or {})
		seat_recommendation = self._build_seat_recommendation(selected_bus, best_seat, layout)

		if not ok:
			return build_recommendation_response(
				message="Passenger details are required to complete the booking.",
				recommended_buses=recommended_buses,
				all_buses=ranked_buses,
				workflow=build_workflow("search", has_results=True),
				status="passenger_validation",
				selected_bus=selected_bus,
				seat_recommendation=seat_recommendation,
				seat_layout=layout,
			)

		seat_no = str(selected_seat_no or (best_seat or {}).get("seat_no") or getattr(state, "selected_seat", "") or "").strip()
		if not seat_no:
			seat_no = str((best_seat or {}).get("seat_no") or "")
		if not seat_no:
			return build_recommendation_response(
				message="I need a seat selection before booking.",
				recommended_buses=recommended_buses,
				all_buses=ranked_buses,
				workflow=build_workflow("search", has_results=True),
				status="missing_seat",
				selected_bus=selected_bus,
				seat_recommendation=seat_recommendation,
				seat_layout=layout,
			)

		booking = self.executor.book_ticket(
			bus_id=selected_bus_id_value,
			seat_no=seat_no,
			passenger=details,
			intent=intent,
			seat_preferences=list((intent.get("preferences") or {}).keys()),
		)
		booking_id = str(booking.get("booking_id") or "")

		updates = {
			"booking_status": str(booking.get("status") or "CONFIRMED"),
			"ticket_data": booking,
			"selected_seat": seat_no,
			"selected_bus": selected_bus,
			"booking_id": booking_id or state.booking_id,
		}

		if fetch_booking_details and booking_id:
			updates["booking_details"] = self.executor.get_booking(booking_id)

		self._sync_state(state, updates)
		return build_recommendation_response(
			message=self._booking_message(booking, selected_bus, seat_no),
			recommended_buses=recommended_buses,
			all_buses=ranked_buses,
			workflow=build_workflow("search", has_results=True, booking_done=True),
			status="booked",
			selected_bus=selected_bus,
			seat_recommendation=seat_recommendation,
			seat_layout=layout,
			ticket=booking,
			booking=booking,
		)

	def _sync_state(self, state: Any, updates: Dict[str, Any]) -> None:
		if hasattr(state, "apply_updates"):
			state.apply_updates(updates)
			return
		for key, value in updates.items():
			setattr(state, key, value)

	def _search_message(self, bus_count: int) -> str:
		count_text = f"{bus_count} bus{'es' if bus_count != 1 else ''}"
		return f"I analyzed {count_text} and shortlisted the strongest options for your journey."

	def _build_seat_recommendation(self, bus: Dict[str, Any], seat: Dict[str, Any] | None, layout: Dict[str, Any]) -> Dict[str, Any]:
		seat = seat or {}
		seat_no = seat.get("seat_no") or ""
		return {
			"bus_id": bus.get("bus_id") or bus.get("id"),
			"operator": self._bus_operator(bus),
			"seat_no": seat_no,
			"seat_meta": {
				"window": bool(seat.get("is_window")),
				"sleeper": bool(seat.get("is_sleeper")),
				"back": bool(seat.get("is_back")),
				"lower": bool(seat.get("is_lower")),
			},
			"reason": self._seat_reason(seat, layout),
			"layout": layout,
		}

	def _bus_operator(self, bus: Dict[str, Any]) -> str:
		raw_operator = (
			bus.get("operator")
			or bus.get("operator_name")
			or bus.get("travels")
			or bus.get("agency")
			or bus.get("provider")
			or bus.get("name")
		)
		operator = str(raw_operator).strip() if raw_operator else "Unknown Operator"
		return operator.upper() if operator and operator.lower() not in ("unknown operator", "") else "Unknown Operator"

	def _seat_reason(self, seat: Dict[str, Any], layout: Dict[str, Any]) -> str:
		if not seat:
			return "I will recommend the best available seat after you share your seating preference."
		bits: list[str] = []
		if seat.get("is_window"):
			bits.append("near the front window")
		if seat.get("is_sleeper"):
			bits.append("sleeper berth")
		if seat.get("is_lower"):
			bits.append("lower berth")
		if not bits:
			bits.append("best available seat")
		seat_no = seat.get("seat_no") or "your seat"
		return f"I found seat {seat_no} available with {', '.join(bits)} for a more comfortable ride."

	def _booking_message(self, booking: Dict[str, Any], bus: Dict[str, Any], seat_no: str) -> str:
		operator = self._bus_operator(bus)
		booking_id = booking.get("booking_id") or booking.get("id") or ""
		seat_part = f" Seat {seat_no}." if seat_no else ""
		booking_part = f" Booking ID: {booking_id}." if booking_id else ""
		return f"Your ticket is confirmed on {operator}.{seat_part}{booking_part}".strip()

	def _seat_message(self, seat_recommendation: Dict[str, Any]) -> str:
		if not seat_recommendation:
			return "I could not determine a seat recommendation yet."
		seat_no = seat_recommendation.get("seat_no") or "the best open seat"
		reason = seat_recommendation.get("reason") or "It fits your route and comfort preferences."
		return f"I found seat {seat_no} available. {reason} Should I continue with that?"


def run_for_session(
	session_id: str,
	auto_book: bool = False,
	passenger_details: Dict[str, Any] | None = None,
	fetch_booking_details: bool = False,
) -> Dict[str, Any]:
	state = booking_session_manager.load_session(session_id)
	return BookingAgent().run(
		state,
		auto_book=auto_book,
		passenger_details=passenger_details,
		fetch_booking_details=fetch_booking_details,
	)
