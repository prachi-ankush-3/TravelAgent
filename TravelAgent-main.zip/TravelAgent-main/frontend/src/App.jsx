import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Splash from './pages/Splash';
import Login from './pages/Login';
import Signup from './pages/Signup';
import MainDashboard from './pages/MainDashboard';
import TicketPage from './pages/TicketPage';
import Profile from './pages/Profile';
import Settings from './pages/Settings';
import TripDetails from './pages/TripDetails';
import './index.css'; // Global styles

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Splash />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/dashboard/*" element={<MainDashboard />} />
        <Route path="/ticket/:id" element={<TicketPage />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="/trip/:id" element={<TripDetails />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
}

export default App;
