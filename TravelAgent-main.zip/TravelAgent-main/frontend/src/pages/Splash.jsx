import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Sparkles, BrainCircuit, BusFront, Map, Calendar, ArrowRight, Play, CheckCircle2, ChevronRight } from 'lucide-react';

import Navbar from '../components/Navbar';
import { getDashboardPath } from '../services/uiStorage';


export default function Splash() {
  const navigate = useNavigate();
  const { scrollYProgress } = useScroll();
  const y = useTransform(scrollYProgress, [0, 1], [0, -100]);

  return (
    <div style={{ background: 'var(--bg-dark)', minHeight: '100vh', overflowX: 'hidden' }}>
      <Navbar />

      {/* Hero Section */}
      <section id="home" className="splash-bg-image" style={{ position: 'relative', minHeight: '100vh', display: 'flex', alignItems: 'center', padding: '0 5%', paddingTop: '80px' }}>
        <div className="orb orb-blue" style={{ top: '20%', left: '10%', width: '500px', height: '500px' }} />
        <div className="orb orb-orange" style={{ bottom: '10%', right: '10%', width: '400px', height: '400px' }} />
        
        {/* Particles */}
        {[...Array(15)].map((_, i) => (
          <motion.div
            key={i}
            className="orb orb-orange"
            style={{ width: Math.random() * 6 + 2 + 'px', height: Math.random() * 6 + 2 + 'px', top: Math.random() * 100 + '%', left: Math.random() * 100 + '%', opacity: 0.4 }}
            animate={{ y: [0, -50], opacity: [0.6, 0] }}
            transition={{ duration: Math.random() * 3 + 2, repeat: Infinity }}
          />
        ))}

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%', maxWidth: '1400px', margin: '0 auto', gap: '40px', zIndex: 10 }}>
          <motion.div style={{ flex: 1 }} initial={{ opacity: 0, x: -50 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.8 }}>
            <h1 className="gradient-text" style={{ fontSize: 'clamp(48px, 8vw, 100px)', fontWeight: 900, lineHeight: 0.95, letterSpacing: '-3px', marginBottom: '24px' }}>
              Travel Smarter <br /> with AI
            </h1>
            <p style={{ fontSize: '18px', color: 'var(--text-muted)', marginBottom: '40px', maxWidth: '500px', lineHeight: 1.6 }}>
              Your intelligent travel companion that plans, optimizes, and books journeys conversationally.
            </p>
            <div style={{ display: 'flex', gap: '16px' }}>
              <button onClick={() => navigate('/signup')} className="ai-btn" style={{ padding: '16px 32px', fontSize: '16px' }}>
                Start Journey <ArrowRight size={18} />
              </button>
              <button className="ai-btn secondary" style={{ padding: '16px 32px', fontSize: '16px' }}>
                <Play size={18} /> Watch AI Demo
              </button>
            </div>
          </motion.div>

          <motion.div style={{ flex: 1, display: 'flex', justifyContent: 'flex-end' }} initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.8, delay: 0.2 }}>
            <div className="glass-panel" style={{ padding: '32px', width: '350px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '24px' }}>
                <BrainCircuit color="var(--accent-orange)" size={24} />
                <h3 style={{ fontSize: '18px', fontWeight: 600 }}>AI Workflow</h3>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                {['Understanding preferences', 'Searching journeys', 'Optimizing comfort', 'Booking intelligently'].map((step, i) => (
                  <motion.div key={step} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.5 + i * 0.2 }} style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                    <CheckCircle2 color="#10B981" size={20} />
                    <span style={{ color: 'white', fontSize: '14px' }}>{step}</span>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" style={{ padding: '120px 5%', position: 'relative' }}>
        <div style={{ textAlign: 'center', marginBottom: '80px' }}>
          <h2 style={{ fontSize: '40px', fontWeight: 700, color: 'white' }}>Travel Without Decision Fatigue</h2>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '32px', maxWidth: '1200px', margin: '0 auto' }}>
          <div className="glass-panel" style={{ padding: '40px', textAlign: 'center' }}>
            <BusFront size={48} color="var(--accent-orange)" style={{ margin: '0 auto 24px auto' }} />
            <h3 style={{ fontSize: '20px', color: 'white', marginBottom: '16px' }}>Conversational Booking</h3>
            <p style={{ color: 'var(--text-muted)', lineHeight: 1.6 }}>Just describe your journey naturally. TravAgent handles the rest.</p>
          </div>
          <div className="glass-panel" style={{ padding: '40px', textAlign: 'center', background: 'rgba(255,106,0,0.05)', border: '1px solid rgba(255,106,0,0.2)' }}>
            <Map size={48} color="var(--accent-orange)" style={{ margin: '0 auto 24px auto' }} />
            <h3 style={{ fontSize: '20px', color: 'white', marginBottom: '16px' }}>Adaptive AI Memory</h3>
            <p style={{ color: 'var(--text-muted)', lineHeight: 1.6 }}>TravAgent learns your travel style over time without requiring manual setup.</p>
          </div>
          <div className="glass-panel" style={{ padding: '40px', textAlign: 'center' }}>
            <BrainCircuit size={48} color="var(--accent-orange)" style={{ margin: '0 auto 24px auto' }} />
            <h3 style={{ fontSize: '20px', color: 'white', marginBottom: '16px' }}>Intelligent Recommendations</h3>
            <p style={{ color: 'var(--text-muted)', lineHeight: 1.6 }}>AI compares buses, selects optimal seats, and plans smarter journeys automatically.</p>
          </div>
        </div>
      </section>

      {/* How AI Works */}
      <section style={{ padding: '120px 5%', background: 'rgba(0,0,0,0.3)', borderTop: '1px solid var(--glass-border)' }}>
        <div style={{ textAlign: 'center', marginBottom: '80px' }}>
          <h2 style={{ fontSize: '40px', fontWeight: 700, color: 'white' }}>How TravAgent Thinks</h2>
        </div>
        <div style={{ maxWidth: '800px', margin: '0 auto', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          {[
            'You describe your journey', 
            'AI understands intent', 
            'TravAgent analyzes providers', 
            'Ranks best options', 
            'Selects optimal seat', 
            'Books intelligently'
          ].map((step, i) => (
            <React.Fragment key={step}>
              <motion.div
                whileInView={{ opacity: 1, scale: 1 }}
                initial={{ opacity: 0, scale: 0.8 }}
                transition={{ duration: 0.5 }}
                className="glass-panel"
                style={{ padding: '16px 32px', background: i === 0 || i === 5 ? 'var(--accent-orange)' : 'var(--glass-bg)', color: 'white', fontSize: '18px', fontWeight: 600, width: '300px', textAlign: 'center', borderRadius: '30px' }}
              >
                {step}
              </motion.div>
              {i < 5 && (
                <motion.div
                  initial={{ height: 0 }}
                  whileInView={{ height: 40 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                  style={{ width: '2px', background: 'var(--accent-orange)', margin: '8px 0' }}
                />
              )}
            </React.Fragment>
          ))}
        </div>
      </section>

      {/* AI Chat Demo */}
      <section style={{ padding: '120px 5%' }}>
         <div style={{ maxWidth: '800px', margin: '0 auto' }}>
            <div className="glass-panel" style={{ padding: '40px', display: 'flex', flexDirection: 'column', gap: '24px' }}>
               <div style={{ display: 'flex', gap: '16px', flexDirection: 'row-reverse' }}>
                  <div style={{ padding: '16px', background: 'var(--glass-bg)', borderRadius: '16px 4px 16px 16px', color: 'white', border: '1px solid var(--glass-border)' }}>
                    Book a comfortable sleeper bus from Pune to Mumbai tomorrow.
                  </div>
               </div>
               <div style={{ display: 'flex', gap: '16px' }}>
                  <div style={{ width: '36px', height: '36px', borderRadius: '50%', background: 'rgba(255,106,0,0.1)', border: '1px solid var(--accent-orange-glow)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <BrainCircuit size={18} color="var(--accent-orange)" />
                  </div>
                  <div>
                    <div style={{ padding: '12px 0', color: 'white', lineHeight: 1.6 }}>
                      I found 3 highly rated sleeper buses and selected a lower window berth for comfort.
                    </div>
                    <div className="glass-panel" style={{ padding: '20px', marginTop: '16px', maxWidth: '350px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '16px' }}>
                        <div>
                          <div style={{ fontWeight: 600, color: 'white' }}>VRL Travels</div>
                          <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>AC Sleeper</div>
                        </div>
                        <div style={{ textAlign: 'right' }}>
                          <div style={{ fontWeight: 700, color: 'var(--accent-orange)' }}>₹1200</div>
                          <div style={{ fontSize: '12px', color: '#10B981' }}>⭐ 4.6</div>
                        </div>
                      </div>
                      <div style={{ background: 'rgba(255,106,0,0.1)', padding: '12px', borderRadius: '8px' }}>
                        <div style={{ fontSize: '12px', color: 'var(--accent-orange)', fontWeight: 600, marginBottom: '8px' }}>Why Recommended?</div>
                        <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>✓ matches your budget<br/>✓ sleeper available<br/>✓ window seat available</div>
                      </div>
                    </div>
                  </div>
               </div>
               {/* Second Interaction */}
               <div style={{ display: 'flex', gap: '16px', flexDirection: 'row-reverse', marginTop: '16px' }}>
                  <div style={{ padding: '16px', background: 'var(--glass-bg)', borderRadius: '16px 4px 16px 16px', color: 'white', border: '1px solid var(--glass-border)' }}>
                    I usually prefer VRL Travels.
                  </div>
               </div>
               <div style={{ display: 'flex', gap: '16px' }}>
                  <div style={{ width: '36px', height: '36px', borderRadius: '50%', background: 'rgba(255,106,0,0.1)', border: '1px solid var(--accent-orange-glow)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <BrainCircuit size={18} color="var(--accent-orange)" />
                  </div>
                  <div style={{ padding: '12px 0', color: 'white', lineHeight: 1.6 }}>
                    Got it. I’ll prioritize VRL for future journeys.
                  </div>
               </div>
            </div>
         </div>
      </section>

      {/* Popular Destinations */}
      <section style={{ padding: '120px 5%', background: 'rgba(0,0,0,0.3)' }}>
        <div style={{ textAlign: 'center', marginBottom: '80px' }}>
          <h2 style={{ fontSize: '40px', fontWeight: 700, color: 'white' }}>Journeys Curated by AI</h2>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '32px', maxWidth: '1000px', margin: '0 auto' }}>
          {[
            { title: 'Weekend Goa Escape', details: 'Budget optimized • Beach stays • Sunset spots' },
            { title: 'Bangalore Work Trip', details: 'Fastest routes • Business hotels • Smart scheduling' }
          ].map((dest, i) => (
            <div key={i} className="glass-panel" style={{ height: '250px', position: 'relative', overflow: 'hidden', display: 'flex', alignItems: 'flex-end', padding: '32px' }}>
               <div style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, background: 'linear-gradient(to bottom, transparent, rgba(0,0,0,0.8))', zIndex: 1 }} />
               <div style={{ position: 'relative', zIndex: 2 }}>
                  <h3 style={{ fontSize: '24px', fontWeight: 600, color: 'white', marginBottom: '8px' }}>{dest.title}</h3>
                  <div style={{ color: 'var(--accent-orange)', display: 'flex', alignItems: 'center', gap: '8px', fontSize: '14px' }}>
                    {dest.details}
                  </div>
               </div>
            </div>
          ))}
        </div>
      </section>

      {/* Future of Travel */}
      <section style={{ padding: '120px 5%', textAlign: 'center' }}>
        <h2 style={{ fontSize: '40px', fontWeight: 700, color: 'white', marginBottom: '24px' }}>The Future of Autonomous Travel</h2>
        <div style={{ maxWidth: '800px', margin: '0 auto', fontSize: '18px', color: 'var(--text-muted)', lineHeight: 1.8, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <div style={{ marginBottom: '24px' }}>TravAgent represents the next generation of travel platforms.</div>
          <ul style={{ listStyle: 'none', padding: 0, margin: 0, textAlign: 'left', display: 'inline-block' }}>
            <li style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '12px' }}><CheckCircle2 color="#10B981" size={20} /> <span style={{ color: 'white' }}>conversational AI</span></li>
            <li style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '12px' }}><CheckCircle2 color="#10B981" size={20} /> <span style={{ color: 'white' }}>adaptive memory</span></li>
            <li style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '12px' }}><CheckCircle2 color="#10B981" size={20} /> <span style={{ color: 'white' }}>autonomous planning</span></li>
            <li style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '12px' }}><CheckCircle2 color="#10B981" size={20} /> <span style={{ color: 'white' }}>intelligent booking</span></li>
            <li style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '12px' }}><CheckCircle2 color="#10B981" size={20} /> <span style={{ color: 'white' }}>personalized recommendations</span></li>
          </ul>
        </div>
      </section>

      {/* Final CTA */}
      <section style={{ padding: '160px 5%', textAlign: 'center', position: 'relative' }}>
         <div className="orb orb-orange" style={{ top: '50%', left: '50%', transform: 'translate(-50%, -50%)', width: '600px', height: '600px', opacity: 0.3 }} />
         <div style={{ position: 'relative', zIndex: 10 }}>
           <h2 style={{ fontSize: '48px', fontWeight: 700, color: 'white', marginBottom: '40px' }}>Ready to Travel Smarter?</h2>
           <button onClick={() => navigate(getDashboardPath())} className="ai-btn" style={{ padding: '20px 40px', fontSize: '20px', margin: '0 auto', boxShadow: '0 0 30px rgba(255, 106, 0, 0.4)' }}>
             Launch TravAgent
           </button>
         </div>
      </section>
    </div>
  );
}
