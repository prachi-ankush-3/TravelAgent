import React from 'react';
import { NavLink } from 'react-router-dom';
import { Plus, Bus, Map, Clock, User, Settings, LogOut, Sparkles } from 'lucide-react';

export default function Sidebar() {
  const navStyle = ({ isActive }) => ({
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
    padding: '12px 16px',
    borderRadius: '12px',
    textDecoration: 'none',
    color: isActive ? 'white' : 'var(--text-muted)',
    background: isActive ? 'var(--glass-glow)' : 'transparent',
    border: `1px solid ${isActive ? 'var(--glass-border)' : 'transparent'}`,
    transition: 'all 0.2s',
    marginBottom: '4px'
  });

  return (
    <div style={{
      width: '260px',
      height: '100vh',
      background: 'var(--bg-sidebar)',
      borderRight: '1px solid var(--glass-border)',
      display: 'flex',
      flexDirection: 'column',
      padding: '24px 16px'
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '0 8px 32px 8px' }}>
        <Sparkles color="var(--accent-orange)" size={24} />
        <h1 style={{ fontSize: '20px', fontWeight: 600, letterSpacing: '-0.5px' }} className="glow-text">TravAgent</h1>
      </div>

      <button className="ai-btn" style={{ marginBottom: '24px', width: '100%', fontSize: '14px' }}>
        <Plus size={18} /> New Journey
      </button>

      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: '8px', overflowY: 'auto' }}>
        <NavLink to="/dashboard/bus" style={navStyle}>
          <Bus size={18} /> Bus Booking
        </NavLink>
        <NavLink to="/dashboard/planner" style={navStyle}>
          <Map size={18} /> Trip Planner
        </NavLink>

        <div style={{ marginTop: '24px', padding: '0 16px' }}>
          <div style={{ fontSize: '12px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '1px', marginBottom: '12px', display: 'flex', alignItems: 'center', gap: '6px' }}>
            <Clock size={12} /> Recent Trips
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', fontSize: '14px', color: 'var(--text-muted)' }}>
            <div style={{ cursor: 'pointer', transition: 'color 0.2s' }} onMouseOver={(e) => e.target.style.color = 'white'} onMouseOut={(e) => e.target.style.color = 'var(--text-muted)'}>Mumbai → Pune</div>
            <div style={{ cursor: 'pointer', transition: 'color 0.2s' }} onMouseOver={(e) => e.target.style.color = 'white'} onMouseOut={(e) => e.target.style.color = 'var(--text-muted)'}>Goa Vacation</div>
            <div style={{ cursor: 'pointer', transition: 'color 0.2s' }} onMouseOver={(e) => e.target.style.color = 'white'} onMouseOut={(e) => e.target.style.color = 'var(--text-muted)'}>Bangalore Work Trip</div>
          </div>
        </div>
      </div>

      <div style={{ marginTop: 'auto', borderTop: '1px solid var(--glass-border)', paddingTop: '16px', display: 'flex', flexDirection: 'column', gap: '4px' }}>
        <NavLink to="/profile" style={navStyle}>
          <User size={18} /> Profile
        </NavLink>
        <NavLink to="/settings" style={navStyle}>
          <Settings size={18} /> Settings
        </NavLink>
        <NavLink to="/login" style={{ ...navStyle({isActive:false}), color: '#F87171' }}>
          <LogOut size={18} /> Logout
        </NavLink>
      </div>
    </div>
  );
}
