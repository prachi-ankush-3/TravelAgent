"""Core itinerary generation logic."""
from __future__ import annotations

from math import ceil
from typing import Any, Dict, List

from app.agents.itinerary.itinerary_rules import (
    MAX_ACTIVITIES_PER_DAY,
    DEFAULT_SLOT_ORDER,
    NEARBY_CLUSTER_THRESHOLD_KM,
    estimated_cost,
    category_family,
    hotel_nearby_tokens,
    normalize_category,
)
from app.agents.itinerary.schedule_optimizer import (
    choose_time_slot,
    optimize_day_schedule,
    prioritize_places,
    rebalance_days,
)
from app.agents.budget.budget_optimizer import extract_numeric_budget


class ItineraryBuilder:
    """Build a structured itinerary from deterministic rules."""

    def build_itinerary(
        self,
        *,
        destination: str,
        duration_days: int,
        places: List[Dict[str, Any]],
        selected_hotel: Dict[str, Any] | None = None,
        budget: Any = None,
        budget_daily: Dict[str, Any] | None = None,
        travel_style: str | None = None,
        interests: List[str] | None = None,
    ) -> Dict[str, Any]:
        """Return a structured itinerary plus a day-keyed schedule."""
        duration_days = max(1, int(duration_days or 1))
        total_budget = extract_numeric_budget(budget)
        daily_budget = self._daily_budget(total_budget, budget_daily, duration_days)

        prioritized_places = prioritize_places(
            list(places or []),
            selected_hotel=selected_hotel,
            interests=interests,
        )

        clusters = self._cluster_nearby_places(
            prioritized_places,
            threshold_km=NEARBY_CLUSTER_THRESHOLD_KM,
        )
        clusters = self._sort_clusters_by_hotel_context(clusters, selected_hotel)

        activities_per_day = max(
            1,
            min(
                MAX_ACTIVITIES_PER_DAY,
                ceil(len(prioritized_places) / duration_days) if prioritized_places else 1,
            ),
        )

        days: List[Dict[str, Any]] = []
        cluster_cursor = 0
        used_names: set[str] = set()

        for day_number in range(1, duration_days + 1):
            day_activities: List[Dict[str, Any]] = []
            slot_usage: set[str] = set()
            day_capacity = activities_per_day

            if day_number == 1 and selected_hotel:
                day_activities.append(
                    {
                        "name": f"Check-in at {selected_hotel.get('name')}",
                        "category": "hotel",
                        "slot": "Morning",
                        "estimated_cost": 0.0,
                        "source": "selected_hotel",
                    }
                )
                slot_usage.add("Morning")
                day_capacity += 1

            while cluster_cursor < len(clusters) and len(day_activities) < day_capacity:
                cluster = clusters[cluster_cursor]
                remaining_capacity = day_capacity - len(day_activities)
                cluster_slice = cluster[:remaining_capacity]

                for place in cluster_slice:
                    name = str(place.get("name", "")).strip()
                    if not name or name in used_names:
                        continue

                    cost = estimated_cost(place)
                    if daily_budget and cost > daily_budget * 1.1:
                        # Skip expensive activities for a budget-aware MVP plan.
                        continue

                    slot = choose_time_slot(place, slot_usage)
                    slot_usage.add(slot)
                    used_names.add(name)

                    day_activities.append(
                        {
                            "name": name,
                            "category": normalize_category(place),
                            "rating": place.get("rating"),
                            "slot": slot,
                            "estimated_cost": cost,
                            "location": place.get("location"),
                            "coordinates": place.get("coordinates"),
                            "description": self._describe_activity(place),
                        }
                    )

                if len(cluster) > len(cluster_slice):
                    clusters[cluster_cursor] = cluster[len(cluster_slice):]
                else:
                    cluster_cursor += 1

            day_plan = self._build_day_plan(
                day_number=day_number,
                destination=destination,
                selected_hotel=selected_hotel,
                day_activities=day_activities,
                daily_budget=daily_budget,
                travel_style=travel_style,
            )
            days.append(optimize_day_schedule(day_plan))

        days = rebalance_days(days, activities_per_day + 1)

        daily_schedule = {f"Day {item['day']}": item for item in days}
        return {
            "itinerary": days,
            "daily_schedule": daily_schedule,
            "itinerary_summary": self._build_itinerary_summary(
                destination=destination,
                days=days,
                selected_hotel=selected_hotel,
                total_budget=total_budget,
            ),
            "days_planned": len(days),
            "activities_per_day": activities_per_day,
        }

    def _cluster_nearby_places(
        self,
        places: List[Dict[str, Any]],
        *,
        threshold_km: float,
    ) -> List[List[Dict[str, Any]]]:
        """Group nearby places greedily so the same-day plan stays geographically compact."""
        remaining = list(places)
        clusters: List[List[Dict[str, Any]]] = []

        while remaining:
            seed = remaining.pop(0)
            cluster = [seed]
            changed = True

            while changed:
                changed = False
                for candidate in list(remaining):
                    if self._is_near_cluster(candidate, cluster, threshold_km):
                        cluster.append(candidate)
                        remaining.remove(candidate)
                        changed = True

            clusters.append(cluster)

        return clusters

    def _is_near_cluster(
        self,
        candidate: Dict[str, Any],
        cluster: List[Dict[str, Any]],
        threshold_km: float,
    ) -> bool:
        from app.utils.distance_utils import calculate_distance

        candidate_family = category_family(candidate)
        cluster_family = category_family(cluster[0])

        # Avoid merging clearly different trip themes just because they are vaguely nearby.
        if candidate_family != cluster_family:
            if "default" not in {candidate_family, cluster_family}:
                return False

        for place in cluster:
            distance = calculate_distance(candidate, place)
            if distance <= threshold_km:
                return True
        return False

    def _sort_clusters_by_hotel_context(
        self,
        clusters: List[List[Dict[str, Any]]],
        selected_hotel: Dict[str, Any] | None,
    ) -> List[List[Dict[str, Any]]]:
        """Put the hotel-adjacent cluster first so day 1 feels anchored to the stay."""
        if not selected_hotel:
            return clusters

        hotel_tokens = hotel_nearby_tokens(selected_hotel)

        def score(cluster: List[Dict[str, Any]]) -> tuple[float, float, str]:
            names_blob = " ".join(
                str(place.get("name", "")).lower() + " " + str(place.get("location", "")).lower()
                for place in cluster
            )
            nearby_hits = sum(1 for token in hotel_tokens if token and token in names_blob)
            avg_rating = sum(float(place.get("rating") or 0) for place in cluster) / max(1, len(cluster))
            return (float(nearby_hits), avg_rating, str(cluster[0].get("name", "")))

        return sorted(clusters, key=score, reverse=True)

    def _build_itinerary_summary(
        self,
        *,
        destination: str,
        days: List[Dict[str, Any]],
        selected_hotel: Dict[str, Any] | None,
        total_budget: float | None,
    ) -> Dict[str, Any]:
        total_activities = sum(len(day.get("activities", [])) for day in days)
        total_estimated = sum(float(day.get("estimated_spend", {}).get("estimated_total") or 0.0) for day in days)
        primary_hotel = self._summarize_hotel(selected_hotel) if selected_hotel else None

        return {
            "destination": destination,
            "days": len(days),
            "total_activities": total_activities,
            "estimated_total_spend": total_estimated,
            "budget": total_budget,
            "hotel": primary_hotel,
        }

    def _daily_budget(
        self,
        total_budget: float | None,
        budget_daily: Dict[str, Any] | None,
        duration_days: int,
    ) -> float:
        if isinstance(budget_daily, dict):
            per_day = budget_daily.get("per_day_total")
            if isinstance(per_day, (int, float)):
                return float(per_day)

        if total_budget is None:
            return 0.0

        return float(total_budget) / max(1, duration_days)

    def _build_day_plan(
        self,
        *,
        day_number: int,
        destination: str,
        selected_hotel: Dict[str, Any] | None,
        day_activities: List[Dict[str, Any]],
        daily_budget: float,
        travel_style: str | None,
    ) -> Dict[str, Any]:
        slot_bucket = {slot: [] for slot in DEFAULT_SLOT_ORDER}
        structured_activities = []
        estimated_spend = 0.0

        for activity in day_activities:
            slot = activity.get("slot", "Afternoon")
            slot_bucket.setdefault(slot, []).append(activity["name"])
            structured_activities.append(activity)
            estimated_spend += float(activity.get("estimated_cost") or 0.0)

        hotel_spend = 0.0
        if day_number == 1 and selected_hotel:
            hotel_spend = float(selected_hotel.get("price_per_night") or 0.0)

        day_plan = {
            "day": day_number,
            "title": f"Day {day_number}",
            "destination": destination,
            "travel_style": travel_style,
            "hotel": self._summarize_hotel(selected_hotel) if selected_hotel else None,
            "activities": structured_activities,
            "Morning": slot_bucket.get("Morning", []),
            "Afternoon": slot_bucket.get("Afternoon", []),
            "Evening": slot_bucket.get("Evening", []),
            "estimated_spend": {
                "activities": estimated_spend,
                "accommodation": hotel_spend,
                "daily_budget": daily_budget,
                "estimated_total": estimated_spend + hotel_spend,
            },
        }
        return day_plan

    def _summarize_hotel(self, hotel: Dict[str, Any] | None) -> Dict[str, Any] | None:
        if not hotel:
            return None

        return {
            "name": hotel.get("name"),
            "location": hotel.get("location"),
            "price_per_night": hotel.get("price_per_night"),
            "star_rating": hotel.get("star_rating"),
            "rating": hotel.get("rating"),
        }

    def _describe_activity(self, place: Dict[str, Any]) -> str:
        category = normalize_category(place)
        name = place.get("name", "this place")
        return f"Visit {name} ({category})"