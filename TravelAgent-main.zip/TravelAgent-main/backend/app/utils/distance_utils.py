"""Geospatial helpers used by itinerary planning."""
from __future__ import annotations

from math import asin, cos, radians, sin, sqrt
from typing import Any, Dict


def _extract_coordinates(place: Dict[str, Any]) -> tuple[float | None, float | None]:
    coordinates = place.get("coordinates") or {}
    if not isinstance(coordinates, dict):
        return None, None

    lat = coordinates.get("lat")
    lng = coordinates.get("lng")
    if isinstance(lat, (int, float)) and isinstance(lng, (int, float)):
        return float(lat), float(lng)
    return None, None


def calculate_distance(place1: Dict[str, Any], place2: Dict[str, Any]) -> float:
    """Calculate the haversine distance in kilometers between two places."""
    lat1, lng1 = _extract_coordinates(place1)
    lat2, lng2 = _extract_coordinates(place2)

    if lat1 is None or lng1 is None or lat2 is None or lng2 is None:
        return float("inf")

    radius_km = 6371.0
    delta_lat = radians(lat2 - lat1)
    delta_lng = radians(lng2 - lng1)

    a = (
        sin(delta_lat / 2) ** 2
        + cos(radians(lat1)) * cos(radians(lat2)) * sin(delta_lng / 2) ** 2
    )
    c = 2 * asin(sqrt(a))
    return radius_km * c