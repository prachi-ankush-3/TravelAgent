from __future__ import annotations

from app.state.booking_session_manager import BookingSessionManager


def test_restore_booking_session_builds_full_payload() -> None:
	manager = BookingSessionManager()

	def fake_request(method, path, *, json=None, params=None, headers=None):
		if path.endswith('/bookings'):
			return [{
				'session_id': 'abc123',
				'user_id': 'user-1',
				'booking_stage': 'awaiting_seat_confirmation',
				'origin': 'Pune',
				'destination': 'Mumbai',
				'travel_date': '2026-05-21',
				'selected_bus': {'bus_id': 'bus-1'},
				'recommended_buses': [{'bus_id': 'bus-1'}],
				'selected_seat': 'L1',
				'booking_id': 'BK-123',
				'ticket_data': {'booking_id': 'BK-123'},
				'booking_status': 'RECOMMENDATIONS_READY',
			}]
		if path.endswith('/booking_messages'):
			return [
				{'role': 'user', 'message': 'book pune to mumbai', 'created_at': '2026-05-21T10:00:00Z'},
				{'role': 'assistant', 'message': 'Seat L1 is available. Continue with that?', 'created_at': '2026-05-21T10:00:01Z'},
			]
		if path.endswith('/user_preferences'):
			return [{'user_id': 'user-1', 'seat_preference': 'window'}]
		return []

	manager._supabase_enabled = lambda: True
	manager._request = fake_request
	payload = manager.restore_booking_session('abc123')

	assert payload['session_id'] == 'abc123'
	assert payload['booking_stage'] == 'awaiting_seat_confirmation'
	assert payload['booking_state']['origin'] == 'Pune'
	assert payload['booking_state']['destination'] == 'Mumbai'
	assert payload['booking_state']['booking_preferences']['seat_preference'] == 'window'
	assert payload['booking_state']['passenger_details'] is None
	assert payload['booking_state']['selected_seat'] == 'L1'
	assert payload['messages'][-1]['message'] == 'Seat L1 is available. Continue with that?'
	assert payload['user_preferences']['seat_preference'] == 'window'
	assert payload['workflow']


def test_restore_booking_session_marks_missing_session_expired() -> None:
	manager = BookingSessionManager()
	manager._supabase_enabled = lambda: True
	manager._request = lambda *args, **kwargs: []

	payload = manager.restore_booking_session('missing-session')

	assert payload['status'] == 'expired'
	assert payload['session_id'] == 'missing-session'
