import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Settings as SettingsIcon, BrainCircuit, Bell, Globe, Moon, Shield } from 'lucide-react';
import Sidebar from '../components/Sidebar';

export default function Settings() {
  const [verbosity, setVerbosity] = useState('Concise');

  const SettingRow = ({ icon: Icon, title, desc, action }) => (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '24px 0', borderBottom: '1px solid var(--glass-border)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
         <div style={{ padding: '12px', background: 'var(--glass-bg)', borderRadius: '12px', border: '1px solid var(--glass-border)' }}>
            <Icon size={20} color="var(--accent-orange)" />
         </div>
         <div>
            <div style={{ fontSize: '16px', fontWeight: 500, color: 'white', marginBottom: '4px' }}>{title}</div>
            <div style={{ fontSize: '14px', color: 'var(--text-muted)' }}>{desc}</div>
         </div>
      </div>
      <div>{action}</div>
    </div>
  );

  return (
    <div className="layout-container">
      <Sidebar />
      <div style={{ flex: 1, padding: '40px', overflowY: 'auto' }}>
        <div style={{ maxWidth: '800px', margin: '0 auto' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '16px', marginBottom: '40px' }}>
            <SettingsIcon size={32} color="white" />
            <h2 style={{ fontSize: '32px', fontWeight: 600, color: 'white' }}>Settings</h2>
          </div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass-panel" style={{ padding: '0 32px' }}>
            <SettingRow 
              icon={BrainCircuit}
              title="AI Verbosity"
              desc="How detailed should the AI's responses be?"
              action={
                <div style={{ display: 'flex', background: 'var(--glass-bg)', borderRadius: '8px', padding: '4px', border: '1px solid var(--glass-border)' }}>
                  {['Concise', 'Detailed'].map(v => (
                    <div 
                      key={v}
                      onClick={() => setVerbosity(v)}
                      style={{ padding: '8px 16px', borderRadius: '4px', background: verbosity === v ? 'var(--accent-orange)' : 'transparent', color: verbosity === v ? 'white' : 'var(--text-muted)', cursor: 'pointer', fontSize: '14px', fontWeight: 500 }}
                    >
                      {v}
                    </div>
                  ))}
                </div>
              }
            />
            <SettingRow 
              icon={Moon}
              title="Appearance"
              desc="Currently locked to Dark Mode for premium aesthetics."
              action={
                 <div style={{ width: '40px', height: '24px', background: 'var(--accent-orange)', borderRadius: '12px', position: 'relative' }}>
                    <div style={{ position: 'absolute', top: '2px', right: '2px', width: '20px', height: '20px', background: 'white', borderRadius: '50%' }} />
                 </div>
              }
            />
            <SettingRow 
              icon={Globe}
              title="Preferred Language"
              desc="Language for AI interactions."
              action={
                 <select className="ai-input" style={{ width: '150px', background: 'var(--glass-bg)' }}>
                   <option>English</option>
                   <option>Hindi</option>
                   <option>Marathi</option>
                 </select>
              }
            />
            <SettingRow 
              icon={Bell}
              title="Notifications"
              desc="Booking confirmations and trip updates."
              action={
                 <div style={{ width: '40px', height: '24px', background: 'var(--accent-orange)', borderRadius: '12px', position: 'relative' }}>
                    <div style={{ position: 'absolute', top: '2px', right: '2px', width: '20px', height: '20px', background: 'white', borderRadius: '50%' }} />
                 </div>
              }
            />
            <SettingRow 
              icon={Shield}
              title="Privacy & Memory"
              desc="Manage what the AI remembers about you."
              action={
                 <button className="ai-btn secondary" style={{ fontSize: '12px', padding: '8px 16px' }}>Clear Memory</button>
              }
            />
          </motion.div>
        </div>
      </div>
    </div>
  );
}
