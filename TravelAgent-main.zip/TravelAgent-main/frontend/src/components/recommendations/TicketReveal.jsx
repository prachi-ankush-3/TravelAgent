import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
	Ticket, CheckCircle2, MapPin, Clock, User, Phone,
	Hash, CreditCard, Trash2, ChevronDown, ChevronUp, Bus
} from 'lucide-react';
import { bookingService } from '../../services/bookingService';

/** Resolve a value from multiple possible key aliases */
function val(obj, keys, fallback = '') {
	if (!obj || typeof obj !== 'object') return fallback;
	for (const key of keys) {
		const v = obj[key];
		if (v !== undefined && v !== null && v !== '') return v;
	}
	return fallback;
}

/**
 * Normalise the ticket payload.
 * The API returns { booking_id, booking: {...}, ticket: {...} }
 * All three shapes may have the actual fields — we flatten them.
 */
function normalise(raw) {
	if (!raw) return {};
	// If the raw object itself has operator/seat_no it's already flat
	if (raw.operator || raw.seat_no) return raw;
	// Otherwise try nested keys
	return raw.booking || raw.ticket || raw;
}

function formatBookingId(id = '') {
	if (!id) return '—';
	// Show first 8 chars + ellipsis if long
	return id.length > 12 ? `${id.slice(0, 8)}…` : id;
}

function formatDate(iso = '') {
	if (!iso) return '';
	try {
		return new Date(iso).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
	} catch {
		return iso;
	}
}

function StatusBadge({ status }) {
	const isConfirmed = String(status || '').toLowerCase() === 'confirmed';
	return (
		<span style={{
			display: 'inline-flex', alignItems: 'center', gap: '5px',
			padding: '4px 10px', borderRadius: '999px', fontSize: '11px', fontWeight: 700,
			background: isConfirmed ? 'rgba(16,185,129,0.18)' : 'rgba(251,191,36,0.15)',
			color: isConfirmed ? '#34d399' : '#fbbf24',
			border: `1px solid ${isConfirmed ? 'rgba(16,185,129,0.35)' : 'rgba(251,191,36,0.3)'}`,
			letterSpacing: '0.06em', textTransform: 'uppercase',
		}}>
			<CheckCircle2 size={10} />
			{isConfirmed ? 'Confirmed' : String(status || 'Pending')}
		</span>
	);
}

function InfoRow({ icon: Icon, label, value }) {
	if (!value || value === '—') return null;
	return (
		<div style={{ display: 'flex', alignItems: 'flex-start', gap: '10px' }}>
			<div style={{
				width: '30px', height: '30px', borderRadius: '8px', flexShrink: 0,
				background: 'rgba(255,154,60,0.1)', border: '1px solid rgba(255,154,60,0.18)',
				display: 'flex', alignItems: 'center', justifyContent: 'center',
			}}>
				<Icon size={14} color="var(--accent-orange)" />
			</div>
			<div>
				<div style={{ fontSize: '11px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>{label}</div>
				<div style={{ marginTop: '2px', fontSize: '14px', fontWeight: 600, color: 'white' }}>{value}</div>
			</div>
		</div>
	);
}

export default function TicketReveal({ ticket: rawTicket }) {
	const [expanded, setExpanded] = useState(false);
	const [cancelling, setCancelling] = useState(false);
	const [cancelResult, setCancelResult] = useState(null);

	if (!rawTicket) return null;

	// Flatten nested ticket shapes
	const t = normalise(rawTicket);
	const bookingId = val(rawTicket, ['booking_id', 'id']) || val(t, ['booking_id', 'id'], '');

	const operator = val(t, ['operator', 'operator_name', 'travels', 'name'], 'Bus Operator');
	const source = val(t, ['source', 'origin', 'from'], '');
	const destination = val(t, ['destination', 'to'], '');
	const seat = val(t, ['seat_no', 'seat'], '');
	const departure = val(t, ['departure_time', 'departure'], '');
	const arrival = val(t, ['arrival_time', 'arrival'], '');
	const passengerName = val(t, ['passenger_name', 'name'], '');
	const passengerAge = val(t, ['passenger_age', 'age'], '');
	const passengerGender = val(t, ['passenger_gender', 'gender'], '');
	const phone = val(t, ['phone_number', 'phone', 'mobile'], '');
	const price = val(t, ['price', 'amount', 'fare'], '');
	const status = val(t, ['status', 'booking_status'], 'confirmed');
	const createdAt = val(t, ['created_at', 'booked_at'], '');

	const handleCancel = async () => {
		if (!bookingId || cancelling) return;
		setCancelling(true);
		try {
			const res = await bookingService.cancelBooking(bookingId);
			setCancelResult(res);
		} catch (err) {
			setCancelResult({ error: err?.message || 'Cancellation failed' });
		} finally {
			setCancelling(false);
		}
	};

	return (
		<motion.div
			initial={{ opacity: 0, y: 20, scale: 0.97 }}
			animate={{ opacity: 1, y: 0, scale: 1 }}
			transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
			style={{ marginTop: '14px', maxWidth: '640px' }}
		>
			{/* ── Boarding-pass card ── */}
			<div style={{
				borderRadius: '24px',
				background: 'linear-gradient(145deg, rgba(18, 20, 36, 0.98), rgba(10, 13, 26, 0.98))',
				border: '1px solid rgba(255, 154, 60, 0.25)',
				boxShadow: '0 24px 60px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.04) inset',
				overflow: 'hidden',
			}}>

				{/* Top stripe */}
				<div style={{
					height: '4px',
					background: 'linear-gradient(90deg, #ff6a00, #ff9a3c, #ffcc70)',
				}} />

				{/* Header section */}
				<div style={{ padding: '20px 24px 18px' }}>
					<div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '12px', flexWrap: 'wrap' }}>
						<div>
							<div style={{ display: 'flex', alignItems: 'center', gap: '7px', marginBottom: '6px' }}>
								<Ticket size={12} color="var(--accent-orange)" />
								<span style={{ fontSize: '10px', fontWeight: 700, color: 'var(--accent-orange)', textTransform: 'uppercase', letterSpacing: '0.14em' }}>
									Booking Confirmed
								</span>
							</div>
							<div style={{ fontSize: '22px', fontWeight: 800, color: 'white', lineHeight: 1.2 }}>{operator}</div>
						</div>
						<StatusBadge status={status} />
					</div>

					{/* Route display — big visual */}
					<div style={{
						display: 'flex', alignItems: 'center', gap: '12px', marginTop: '20px',
						padding: '16px 20px', borderRadius: '16px',
						background: 'rgba(255, 154, 60, 0.07)',
						border: '1px solid rgba(255, 154, 60, 0.14)',
					}}>
						{/* Source */}
						<div style={{ flex: 1 }}>
							<div style={{ fontSize: '11px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.1em' }}>From</div>
							<div style={{ fontSize: '20px', fontWeight: 800, color: 'white', marginTop: '2px' }}>{source || '—'}</div>
							<div style={{ fontSize: '16px', fontWeight: 600, color: 'var(--accent-orange)', marginTop: '2px' }}>{departure}</div>
						</div>

						{/* Arrow & bus icon */}
						<div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px', flexShrink: 0 }}>
							<Bus size={18} color="var(--accent-orange)" />
							<div style={{ width: '60px', height: '2px', background: 'linear-gradient(90deg, rgba(255,154,60,0.4), rgba(255,154,60,0.9), rgba(255,154,60,0.4))', borderRadius: '2px' }} />
						</div>

						{/* Destination */}
						<div style={{ flex: 1, textAlign: 'right' }}>
							<div style={{ fontSize: '11px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.1em' }}>To</div>
							<div style={{ fontSize: '20px', fontWeight: 800, color: 'white', marginTop: '2px' }}>{destination || '—'}</div>
							<div style={{ fontSize: '16px', fontWeight: 600, color: 'var(--accent-orange)', marginTop: '2px' }}>{arrival}</div>
						</div>
					</div>
				</div>

				{/* Dashed separator — boarding pass style */}
				<div style={{ position: 'relative', margin: '0 24px' }}>
					<div style={{
						borderTop: '2px dashed rgba(255,255,255,0.08)',
					}} />
					{/* Left notch */}
					<div style={{
						position: 'absolute', left: '-36px', top: '50%', transform: 'translateY(-50%)',
						width: '20px', height: '20px', borderRadius: '50%',
						background: 'rgba(10, 13, 26, 1)',
						border: '1px solid rgba(255,154,60,0.22)',
					}} />
					{/* Right notch */}
					<div style={{
						position: 'absolute', right: '-36px', top: '50%', transform: 'translateY(-50%)',
						width: '20px', height: '20px', borderRadius: '50%',
						background: 'rgba(10, 13, 26, 1)',
						border: '1px solid rgba(255,154,60,0.22)',
					}} />
				</div>

				{/* Details grid */}
				<div style={{
					padding: '18px 24px',
					display: 'grid',
					gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))',
					gap: '14px',
				}}>
					{seat && (
						<div style={{ padding: '12px 14px', borderRadius: '14px', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)' }}>
							<div style={{ fontSize: '10px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Seat</div>
							<div style={{ fontSize: '22px', fontWeight: 900, color: 'var(--accent-orange)', marginTop: '4px' }}>{seat}</div>
						</div>
					)}
					{passengerName && (
						<div style={{ padding: '12px 14px', borderRadius: '14px', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)' }}>
							<div style={{ fontSize: '10px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Passenger</div>
							<div style={{ fontSize: '15px', fontWeight: 700, color: 'white', marginTop: '4px' }}>{passengerName}</div>
							{(passengerAge || passengerGender) && (
								<div style={{ fontSize: '12px', color: 'var(--text-muted)', marginTop: '2px', textTransform: 'capitalize' }}>
									{[passengerAge ? `${passengerAge} yrs` : '', passengerGender].filter(Boolean).join(' · ')}
								</div>
							)}
						</div>
					)}
					{price && (
						<div style={{ padding: '12px 14px', borderRadius: '14px', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)' }}>
							<div style={{ fontSize: '10px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Fare</div>
							<div style={{ fontSize: '20px', fontWeight: 800, color: 'white', marginTop: '4px' }}>₹{price}</div>
						</div>
					)}
					{phone && (
						<div style={{ padding: '12px 14px', borderRadius: '14px', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)' }}>
							<div style={{ fontSize: '10px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Phone</div>
							<div style={{ fontSize: '14px', fontWeight: 600, color: 'white', marginTop: '4px' }}>{phone}</div>
						</div>
					)}
				</div>

				{/* Booking ID bar */}
				<div style={{
					margin: '0 24px 18px',
					padding: '10px 14px',
					borderRadius: '12px',
					background: 'rgba(255,255,255,0.03)',
					border: '1px solid rgba(255,255,255,0.06)',
					display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '8px',
					flexWrap: 'wrap',
				}}>
					<div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
						<Hash size={12} color="var(--text-muted)" />
						<span style={{ fontSize: '11px', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Booking ID</span>
					</div>
					<span style={{ fontFamily: 'monospace', fontSize: '12px', color: 'rgba(255,255,255,0.7)', letterSpacing: '0.05em', wordBreak: 'break-all' }}>
						{bookingId}
					</span>
				</div>

				{/* Cancel result message */}
				<AnimatePresence>
					{cancelResult && (
						<motion.div
							initial={{ opacity: 0, height: 0 }}
							animate={{ opacity: 1, height: 'auto' }}
							exit={{ opacity: 0, height: 0 }}
							style={{
								margin: '0 24px 14px',
								padding: '10px 14px',
								borderRadius: '12px',
								background: cancelResult.error ? 'rgba(239,68,68,0.1)' : 'rgba(16,185,129,0.1)',
								border: `1px solid ${cancelResult.error ? 'rgba(239,68,68,0.25)' : 'rgba(16,185,129,0.25)'}`,
								color: cancelResult.error ? '#fca5a5' : '#6ee7b7',
								fontSize: '13px',
							}}
						>
							{cancelResult.error ? `❌ ${String(cancelResult.error)}` : '✅ Booking cancelled successfully'}
						</motion.div>
					)}
				</AnimatePresence>

				{/* Action buttons */}
				<div style={{
					padding: '0 24px 20px',
					display: 'flex', gap: '10px', flexWrap: 'wrap',
				}}>
					<button
						onClick={() => setExpanded((p) => !p)}
						style={{
							display: 'inline-flex', alignItems: 'center', gap: '6px',
							padding: '10px 16px', borderRadius: '10px',
							border: '1px solid rgba(255,255,255,0.1)',
							background: 'rgba(255,255,255,0.05)',
							color: 'var(--text-main)', cursor: 'pointer',
							fontSize: '13px', fontWeight: 600, fontFamily: 'inherit',
							transition: 'background 0.2s',
						}}
						onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(255,255,255,0.09)'}
						onMouseLeave={(e) => e.currentTarget.style.background = 'rgba(255,255,255,0.05)'}
					>
						{expanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
						{expanded ? 'Hide details' : 'View full details'}
					</button>

					{bookingId && !cancelResult && (
						<button
							onClick={handleCancel}
							disabled={cancelling}
							style={{
								display: 'inline-flex', alignItems: 'center', gap: '6px',
								padding: '10px 16px', borderRadius: '10px',
								border: '1px solid rgba(239,68,68,0.28)',
								background: 'rgba(239,68,68,0.08)',
								color: '#f87171', cursor: cancelling ? 'wait' : 'pointer',
								fontSize: '13px', fontWeight: 600, fontFamily: 'inherit',
								transition: 'background 0.2s', opacity: cancelling ? 0.7 : 1,
							}}
							onMouseEnter={(e) => { if (!cancelling) e.currentTarget.style.background = 'rgba(239,68,68,0.16)'; }}
							onMouseLeave={(e) => { e.currentTarget.style.background = 'rgba(239,68,68,0.08)'; }}
						>
							<Trash2 size={13} />
							{cancelling ? 'Cancelling…' : 'Cancel booking'}
						</button>
					)}
				</div>

				{/* Expanded full-details panel */}
				<AnimatePresence>
					{expanded && (
						<motion.div
							initial={{ opacity: 0, height: 0 }}
							animate={{ opacity: 1, height: 'auto' }}
							exit={{ opacity: 0, height: 0 }}
							style={{ overflow: 'hidden' }}
						>
							<div style={{
								margin: '0 24px 24px',
								padding: '16px',
								borderRadius: '16px',
								background: 'rgba(0,0,0,0.3)',
								border: '1px solid rgba(255,255,255,0.06)',
								display: 'flex', flexDirection: 'column', gap: '14px',
							}}>
								<div style={{ fontSize: '11px', color: 'var(--accent-orange)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.12em', marginBottom: '2px' }}>
									Ticket Details
								</div>

								<InfoRow icon={Bus} label="Operator" value={operator} />
								<InfoRow icon={MapPin} label="Route" value={source && destination ? `${source} → ${destination}` : ''} />
								<InfoRow icon={Clock} label="Departure" value={departure} />
								<InfoRow icon={Clock} label="Arrival" value={arrival} />
								<InfoRow icon={User} label="Passenger" value={passengerName ? `${passengerName}${passengerAge ? `, ${passengerAge} yrs` : ''}${passengerGender ? ` · ${passengerGender}` : ''}` : ''} />
								<InfoRow icon={Phone} label="Contact" value={phone} />
								<InfoRow icon={CreditCard} label="Fare Paid" value={price ? `₹${price}` : ''} />
								{createdAt && (
									<div style={{ fontSize: '12px', color: 'var(--text-muted)', paddingTop: '6px', borderTop: '1px solid rgba(255,255,255,0.06)' }}>
										Booked on {formatDate(createdAt)}
									</div>
								)}
							</div>
						</motion.div>
					)}
				</AnimatePresence>
			</div>

			{/* Success footer note */}
			<div style={{
				marginTop: '10px',
				padding: '10px 16px',
				borderRadius: '12px',
				background: 'rgba(16,185,129,0.08)',
				border: '1px solid rgba(16,185,129,0.18)',
				color: '#6ee7b7',
				fontSize: '12px',
				display: 'flex', alignItems: 'center', gap: '7px',
			}}>
				<CheckCircle2 size={13} />
				Ticket confirmed · A confirmation would be sent to your registered contact
			</div>
		</motion.div>
	);
}
