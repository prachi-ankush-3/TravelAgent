import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Map, Calendar, Navigation, MapPin } from 'lucide-react';
import { plannerService } from '../../services/plannerService';

export default function PlannerSidebar({ onSelectPlan, onNewTrip }) {
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchPlans();
  }, []);

  const fetchPlans = async () => {
    try {
      setLoading(true);
      const data = await plannerService.getPlans();
      if (Array.isArray(data)) {
        setPlans(data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="planner-sidebar" style={{ width: '280px', flexShrink: 0, borderRight: '1px solid var(--glass-border)', background: 'rgba(10, 13, 26, 0.97)', display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div style={{ padding: '24px', borderBottom: '1px solid var(--glass-border)', display: 'flex', flexDirection: 'column', gap: '16px' }}>
        <h3 style={{ fontSize: '18px', fontWeight: 800, color: 'white', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Map size={20} color="var(--accent-orange)" />
          My Trips
        </h3>
        <button
          onClick={onNewTrip}
          style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '8px',
            width: '100%',
            padding: '10px 14px',
            borderRadius: '10px',
            border: 'none',
            background: 'linear-gradient(135deg, #ff9a3c, #ff6a00)',
            color: '#0b0f1a',
            fontWeight: 700,
            fontSize: '13px',
            cursor: 'pointer',
            transition: 'opacity 0.2s, transform 0.15s',
            boxShadow: '0 4px 16px rgba(255, 106, 0, 0.28)'
          }}
          onMouseOver={(e) => { e.currentTarget.style.transform = 'translateY(-1px)'; e.currentTarget.style.opacity = '0.95'; }}
          onMouseOut={(e) => { e.currentTarget.style.transform = 'none'; e.currentTarget.style.opacity = '1'; }}
        >
          <span style={{ fontSize: '16px', fontWeight: 900 }}>+</span> NEW TRIP
        </button>
      </div>
      <div style={{ flex: 1, overflowY: 'auto', padding: '16px' }}>
        {loading ? (
          <div style={{ color: 'var(--text-muted)', fontSize: '14px', textAlign: 'center', marginTop: '24px' }}>Loading...</div>
        ) : plans.length === 0 ? (
          <div style={{ color: 'var(--text-muted)', fontSize: '14px', textAlign: 'center', marginTop: '24px' }}>No past trips found.</div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {plans.map((plan) => (
              <motion.div
                key={plan.id}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => onSelectPlan(plan)}
                style={{
                  background: 'rgba(255,255,255,0.03)',
                  border: '1px solid rgba(255,255,255,0.08)',
                  borderRadius: '12px',
                  padding: '16px',
                  cursor: 'pointer',
                  transition: 'background 0.2s'
                }}
                onMouseOver={(e) => e.currentTarget.style.background = 'rgba(255,255,255,0.06)'}
                onMouseOut={(e) => e.currentTarget.style.background = 'rgba(255,255,255,0.03)'}
              >
                <div style={{ fontSize: '15px', fontWeight: 700, color: 'white', marginBottom: '4px', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {plan.title || 'Untitled Trip'}
                </div>
                {plan.destination && (
                  <div style={{ fontSize: '12px', color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '4px', marginBottom: '4px' }}>
                    <MapPin size={12} /> {plan.destination}
                  </div>
                )}
                <div style={{ fontSize: '11px', color: 'rgba(255,255,255,0.3)' }}>
                  {new Date(plan.created_at).toLocaleDateString()}
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
