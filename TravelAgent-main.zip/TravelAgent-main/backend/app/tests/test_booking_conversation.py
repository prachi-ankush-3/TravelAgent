from __future__ import annotations

from app.agents.booking.conversation_manager import BookingConversationManager


def test_booking_conversation_continues_across_follow_up_confirmation() -> None:
	manager = BookingConversationManager()

	def fake_run(state, **kwargs):
		action = kwargs.get("action")
		if action == "book":
			return {
				"message": "Your ticket is confirmed on Fast Travels. Seat L1. Booking ID: BK-123.",
				"status": "booked",
				"recommended_buses": [{"bus_id": "bus-1"}],
				"all_buses": [{"bus_id": "bus-1"}],
				"selected_bus": {"bus_id": "bus-1"},
				"seat_recommendation": {"seat_no": "L1"},
				"ticket": {"booking_id": "BK-123"},
				"booking": {"booking_id": "BK-123"},
				"workflow": [{"label": "Booking complete", "step": "Booking complete", "status": "completed"}],
				"cards": [],
			}
		return {
			"message": "Seat L1 is available. Continue with that?",
			"status": "seat_recommended",
			"recommended_buses": [{"bus_id": "bus-1"}],
			"all_buses": [{"bus_id": "bus-1"}],
			"selected_bus": {"bus_id": "bus-1"},
			"seat_recommendation": {"seat_no": "L1"},
			"workflow": [{"label": "Awaiting seat confirmation", "step": "Awaiting seat confirmation", "status": "active"}],
			"cards": [],
		}

	manager.agent.run = fake_run

	first = manager.handle_turn(session_id="test-session-123", message="book pune to mumbai tomorrow", action="search")
	second = manager.handle_turn(session_id="test-session-123", message="yes choose that")

	assert first["booking_stage"] == "awaiting_seat_confirmation"
	assert second["booking_stage"] == "booking_complete"
	assert second["state"]["booking_id"] == "BK-123"
	assert second["state"]["conversation_history"][-1]["role"] == "assistant"
	assert "BK-123" in second["state"]["conversation_history"][-1]["message"]
