from __future__ import annotations

from app.agents.booking.bus_selection_resolver import resolve_selected_bus


def test_resolve_selected_bus_matches_operator_name() -> None:
	recommended_buses = [
		{"recommendation_id": "rec_1", "bus_id": "bus-1", "operator": "Purple Bus - Metrolink", "rank_label": "Best Overall"},
		{"recommendation_id": "rec_2", "bus_id": "bus-2", "operator": "Blue Bus", "rank_label": "Budget Friendly"},
	]

	selected = resolve_selected_bus(
		user_message="Go with Purple Bus",
		recommended_buses=recommended_buses,
		all_buses=recommended_buses,
		booking_stage="awaiting_bus_selection",
	)

	assert selected is not None
	assert selected["bus_id"] == "bus-1"


def test_resolve_selected_bus_matches_recommendation_id() -> None:
	recommended_buses = [
		{"recommendation_id": "rec_1", "bus_id": "bus-1", "operator": "Purple Bus - Metrolink", "rank_label": "Best Overall"},
		{"recommendation_id": "rec_2", "bus_id": "bus-2", "operator": "Blue Bus", "rank_label": "Budget Friendly"},
	]

	selected = resolve_selected_bus(
		user_message="choose that",
		recommended_buses=recommended_buses,
		all_buses=recommended_buses,
		booking_stage="awaiting_bus_selection",
		selected_recommendation_id="rec_2",
	)

	assert selected is not None
	assert selected["bus_id"] == "bus-2"
