"""Rule-based trip detail extraction when LLM is unavailable or returns empty fields."""
from __future__ import annotations

import re
from datetime import date, timedelta
from typing import Any, Dict, Optional, Tuple

_SKIP_WORDS = {
	"book",
	"bus",
	"a",
	"an",
	"the",
	"my",
	"please",
	"want",
	"need",
	"travel",
	"ticket",
	"from",
	"to",
}


def _title_city(value: str) -> str:
	text = re.sub(r"\s+", " ", str(value or "").strip())
	if not text:
		return ""
	return " ".join(part.capitalize() for part in text.split())


def parse_route_from_message(message: str) -> Tuple[str, str]:
	"""Extract origin and destination from phrases like 'from Pune to Nashik' or 'Pune to Mumbai'."""
	text = str(message or "").strip()
	if not text:
		return "", ""

	patterns = [
		re.compile(
			r"\bfrom\s+([a-zA-Z][a-zA-Z\s]{0,24}?)\s+to\s+([a-zA-Z][a-zA-Z\s]{0,24}?)(?=\s+(?:on|for|tomorrow|today|tmrw)|[,.!?]|$)",
			re.IGNORECASE,
		),
		re.compile(
			r"\b([a-zA-Z][a-zA-Z\s]{0,24}?)\s+to\s+([a-zA-Z][a-zA-Z\s]{0,24}?)(?=\s+(?:on|for|tomorrow|today|tmrw)|[,.!?]|$)",
			re.IGNORECASE,
		),
	]

	for pattern in patterns:
		match = pattern.search(text)
		if not match:
			continue
		source = _title_city(match.group(1))
		destination = _title_city(match.group(2))
		if source.lower() in _SKIP_WORDS or destination.lower() in _SKIP_WORDS:
			continue
		if source and destination and source.lower() != destination.lower():
			return source, destination

	return "", ""


def parse_travel_date_from_message(message: str) -> Optional[str]:
	text = str(message or "").strip().lower()
	if not text:
		return None

	iso_match = re.search(r"\b(\d{4}-\d{2}-\d{2})\b", text)
	if iso_match:
		return iso_match.group(1)

	if re.search(r"\bday after tomorrow\b", text):
		return (date.today() + timedelta(days=2)).isoformat()
	if re.search(r"\b(tomorrow|tmrw|tommorrow)\b", text):
		return (date.today() + timedelta(days=1)).isoformat()
	if re.search(r"\btoday\b", text):
		return date.today().isoformat()

	return None


def extract_trip_details_from_message(message: str) -> Dict[str, Any]:
	"""Best-effort structured trip fields from plain user text."""
	source, destination = parse_route_from_message(message)
	travel_date = parse_travel_date_from_message(message)
	payload: Dict[str, Any] = {}
	if source:
		payload["source"] = source
		payload["origin"] = source
	if destination:
		payload["destination"] = destination
	if travel_date:
		payload["travel_date"] = travel_date
		payload["travel_dates"] = {"start": travel_date}
	return payload
